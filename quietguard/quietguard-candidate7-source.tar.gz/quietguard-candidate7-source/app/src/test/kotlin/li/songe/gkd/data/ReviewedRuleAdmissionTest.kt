// Private-fork addition, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.data

import org.junit.Assert.*
import org.junit.Test

/** Exercises the real RawSubscription parser/serializers and resolved-group adapter. */
class ReviewedRuleAdmissionTest {
    @Test fun actualParsedRuleAndInheritedGroupContentCanBeReviewedExactly() {
        val group = ReviewedRuleFixture.group()
        val candidate = ReviewedRuleContent.candidate(group.group.rules.single(), group)!!
        val entry = ReviewedRuleFixture.entry(candidate)
        assertSame(entry, ReviewedRulePolicy.admit(candidate, listOf(entry)))
        assertTrue(candidate.serializedRule.contains("\"position\":null"))
        assertTrue(candidate.serializedGroup.contains("\"rules\":["))
        assertEquals(listOf("example.reviewfixture.AdActivity"), candidate.activityNames)
        assertNull(ReviewedRuleCatalog.admit(candidate))
    }

    @Test fun inheritedTimingAndSiblingChangesInvalidateTheFullGroupHash() {
        val group = ReviewedRuleFixture.group()
        val rule = group.group.rules.single()
        val original = ReviewedRuleContent.candidate(rule, group)!!
        val entry = ReviewedRuleFixture.entry(original)
        val changes = listOf(
            group.group.copy(actionDelay = 123),
            group.group.copy(name = "Reward claimed to be reviewed"),
            group.group.copy(rules = listOf(rule, rule.copy(key = 8))),
        )
        for (rawGroup in changes) {
            val changedGroup = ReviewedRuleFixture.replaceGroup(group, rawGroup)
            val changed = ReviewedRuleContent.candidate(rule, changedGroup)!!
            assertEquals(original.serializedRule, changed.serializedRule)
            assertNotEquals(original.serializedGroup, changed.serializedGroup)
            assertNull(ReviewedRulePolicy.admit(changed, listOf(entry)))
        }
    }

    @Test fun contentIsReencodedAndDoesNotUseTheCachedGroupSerialization() {
        val original = ReviewedRuleFixture.group()
        val mutableRules = original.group.rules.toMutableList()
        val group = ReviewedRuleFixture.replaceGroup(original, original.group.copy(rules = mutableRules))
        val rule = mutableRules.single()
        // Populate the upstream cache; then mutate a retained collection.
        group.group.cacheJsonObject
        val before = ReviewedRuleContent.candidate(rule, group)!!
        mutableRules += rule.copy(key = 8, action = "back")
        val after = ReviewedRuleContent.candidate(rule, group)!!
        assertNotEquals(before.serializedGroup, after.serializedGroup)
        assertNull(ReviewedRulePolicy.admit(after, listOf(ReviewedRuleFixture.entry(before))))
    }

    @Test fun cachedCatalogRevisionDoesNotCacheMutableRawRuleContent() {
        val original = ReviewedRuleFixture.group()
        val retainedUrls = mutableListOf("https://example.invalid/review.png")
        val rule = original.group.rules.single().copy(snapshotUrls = retainedUrls)
        val group = ReviewedRuleFixture.replaceGroup(original, original.group.copy(rules = listOf(rule)))
        group.group.cacheJsonObject
        val before = ReviewedRuleContent.candidate(rule, group)!!
        val catalog = ReviewedRuleCatalogSnapshot(listOf(ReviewedRuleFixture.entry(before)))
        val revision = catalog.consentRevision(before.packageName!!)
        assertNotNull(catalog.admit(before))
        retainedUrls += "https://example.invalid/changed.png"
        val after = ReviewedRuleContent.candidate(rule, group)!!
        assertEquals(before.matches, after.matches)
        assertNotEquals(before.serializedRule, after.serializedRule)
        assertNotEquals(before.serializedGroup, after.serializedGroup)
        assertEquals(revision, catalog.consentRevision(before.packageName))
        assertNull(catalog.admit(after))
        retainedUrls.removeAt(1)
        assertNotNull(catalog.admit(ReviewedRuleContent.candidate(rule, group)!!))
    }

    @Test fun cachedCatalogRevisionDoesNotCacheMutableRawGroupSiblingsOrMembership() {
        val original = ReviewedRuleFixture.group()
        val retainedRules = original.group.rules.toMutableList()
        val group = ReviewedRuleFixture.replaceGroup(original, original.group.copy(rules = retainedRules))
        val rule = retainedRules.single()
        group.group.cacheJsonObject
        val before = ReviewedRuleContent.candidate(rule, group)!!
        val catalog = ReviewedRuleCatalogSnapshot(listOf(ReviewedRuleFixture.entry(before)))
        assertNotNull(catalog.admit(before))
        retainedRules += rule.copy(key = 8)
        val after = ReviewedRuleContent.candidate(rule, group)!!
        assertEquals(before.serializedRule, after.serializedRule)
        assertNotEquals(before.serializedGroup, after.serializedGroup)
        assertNull(catalog.admit(after))
        retainedRules[1] = rule.copy()
        assertNull(ReviewedRuleContent.candidate(rule, group))
        retainedRules.removeAt(1)
        assertNotNull(catalog.admit(ReviewedRuleContent.candidate(rule, group)!!))
        retainedRules.clear()
        assertNull(ReviewedRuleContent.candidate(rule, group))
    }

    @Test fun detachedOrDuplicateRuleAndGroupKeysCannotBorrowTrust() {
        val group = ReviewedRuleFixture.group()
        val rule = group.group.rules.single()
        assertNull(ReviewedRuleContent.candidate(rule.copy(), group))
        val duplicateRuleGroup = ReviewedRuleFixture.replaceGroup(
            group, group.group.copy(rules = listOf(rule, rule.copy())),
        )
        assertNull(ReviewedRuleContent.candidate(rule, duplicateRuleGroup))
        val duplicateGroup = ResolvedAppGroup(
            group.group, group.subscription, group.subsItem, null,
            group.app.copy(groups = listOf(group.group, group.group.copy())), true,
        )
        assertNull(ReviewedRuleContent.candidate(rule, duplicateGroup))
    }

    @Test fun globalRulesAndCrossRuleReferencesNeverAdmit() {
        val group = ReviewedRuleFixture.group()
        val rule = group.group.rules.single()
        val referenced = ReviewedRuleFixture.replaceGroup(group, group.group.copy(scopeKeys = listOf(4)))
        val candidate = ReviewedRuleContent.candidate(rule, referenced)!!
        assertTrue(candidate.hasExternalRuleDependencies)
        assertNull(ReviewedRulePolicy.admit(candidate, listOf(ReviewedRuleFixture.entry(candidate))))
        val subscription = RawSubscription.parse(
            """{"id":1,"name":"claimed reviewed","version":1,"globalGroups":[{"key":3,"name":"Ad","rules":[{"key":7,"action":"clickNode","matches":"[text='Skip']"}]}]}""",
            json5 = false,
        )
        val global = ResolvedGlobalGroup(subscription.globalGroups.single(), subscription, group.subsItem, null)
        assertNull(ReviewedRuleContent.candidate(global.group.rules.single(), global))
    }
}

internal object ReviewedRuleFixture {
    fun group(): ResolvedAppGroup {
        val subscription = RawSubscription.parse(
            """{
              "id":1,"name":"synthetic test fixture only","version":1,
              "apps":[{"id":"example.reviewfixture","groups":[{
                "key":3,"name":"Ad","activityIds":["example.reviewfixture.AdActivity"],
                "rules":[{"key":7,"action":"clickNode",
                  "matches":["[id='example.reviewfixture:id/ad_panel'][visibleToUser=true]","[id='example.reviewfixture:id/dismiss'][visibleToUser=true][clickable=true][editable=false]"],
                  "excludeMatches":["[id='example.reviewfixture:id/reward']"]
                }]
              }]}]
            }""",
            json5 = false,
        )
        val app = subscription.apps.single()
        return ResolvedAppGroup(app.groups.single(), subscription, SubsItem(id = 1, order = 0), null, app, true)
    }

    fun replaceGroup(original: ResolvedAppGroup, rawGroup: RawSubscription.RawAppGroup) =
        ResolvedAppGroup(
            rawGroup, original.subscription, original.subsItem, null,
            original.app.copy(groups = listOf(rawGroup)), true,
        )

    fun entry(candidate: ReviewedRuleCandidate) = ReviewedRuleEntry(
        packageName = candidate.packageName!!, versionCode = 4_294_967_297L,
        currentSignerSha256 = setOf("a".repeat(64)), activityName = candidate.activityNames.single(),
        groupKey = candidate.groupKey, ruleKey = candidate.ruleKey!!,
        ruleSha256 = ReviewedRulePolicy.sha256(candidate.serializedRule),
        groupSha256 = ReviewedRulePolicy.sha256(candidate.serializedGroup),
        targetSelector = candidate.matches.last(), requiredContextSelectors = candidate.matches.dropLast(1),
        forbiddenContextSelectors = candidate.excludeMatches, purpose = ReviewedRulePurpose.AD_DISMISS,
    )
}
