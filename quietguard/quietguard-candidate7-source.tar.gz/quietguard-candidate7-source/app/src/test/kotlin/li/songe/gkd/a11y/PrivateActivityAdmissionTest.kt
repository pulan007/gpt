/* Private-fork recovery tests, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

import org.junit.Assert.*
import org.junit.Test

class PrivateActivityAdmissionTest {
    private var time = 100L
    private val admission = PrivateActivityAdmission { time }
    private fun state(packageName: String = "owned.app", windowId: Int = 7,
        epoch: Long = 1, generation: Long = 1, eligible: Boolean = true) =
        admission.observe(packageName, "owned.app.Ad", windowId, true, eligible, time, epoch, generation)
    private fun content(windowId: Int = 7, epoch: Long = 1, generation: Long = 1,
        packageName: String = "owned.app", eligible: Boolean = true) =
        admission.observe(packageName, "android.widget.TextView", windowId, false, eligible, time, epoch, generation)

    @Test fun contentBurstPreservesOneOriginalStateAndOnlyTwoOpportunities() {
        val token = state()!!
        assertTrue(admission.reserveAttempt(token))
        time = 599
        repeat(10_000) { assertSame(token, content()); assertFalse(admission.reserveAttempt(token)) }
        assertEquals(100L, token.observedAt)
        assertEquals(1L, admission.delayBeforeAttempt(token))
        time = 600
        assertTrue(admission.reserveAttempt(token))
        assertNull(admission.delayBeforeAttempt(token))
        assertFalse(admission.reserveAttempt(token))
    }

    @Test fun budgetDenialSpendsOpportunityButRetryStillUsesSharedBudget() {
        val budget = PrivateScanBudget({ time })
        assertTrue(budget.tryAcquire()) // Some earlier process-wide identity work.
        val token = state()!!
        assertTrue(admission.reserveAttempt(token))
        assertFalse(budget.tryAcquire())
        time = 600
        assertTrue(admission.reserveAttempt(token))
        assertTrue(budget.tryAcquire())
        assertFalse(admission.reserveAttempt(token))
    }

    @Test fun retrySpacingStartsAfterActualBudgetAdmissionAndKeepsOriginalDeadline() {
        val budget = PrivateScanBudget({ time })
        val token = state()!!
        assertTrue(admission.reserveAttempt(token))
        time += 25 // Work between reservation and actual process-wide budget acquisition.
        assertTrue(budget.tryAcquire())
        admission.identityAdmitted(token)
        time = 600
        assertEquals(25L, admission.delayBeforeAttempt(token))
        assertFalse(admission.reserveAttempt(token))
        time = 625
        assertTrue(admission.reserveAttempt(token))
        assertTrue(budget.tryAcquire())
        assertEquals(100L, token.observedAt)
    }

    @Test fun delayedFirstAttemptCannotExtendDeadlineToFitRetry() {
        val token = state()!!
        time = 601
        assertTrue(admission.reserveAttempt(token))
        assertNull(admission.delayBeforeAttempt(token))
        time = 1_100
        assertNull(content())
        assertFalse(admission.promote(token, "owned.app", 7))
    }

    @Test fun changedWindowPackageEpochGenerationAndDisabledContentInvalidate() {
        for (scenario in 0..4) {
            val token = state()!!
            val result = when (scenario) {
                0 -> content(windowId = 8)
                1 -> content(packageName = "other.app")
                2 -> content(epoch = 2)
                3 -> content(generation = 2)
                else -> content(eligible = false)
            }
            assertNull(result)
            assertFalse(admission.isCurrent(token, 1, 1))
            assertNull(content()) // Observed away-and-back cannot revive it.
        }
    }

    @Test fun unknownStateAndNegativeWindowNeverPromote() {
        val original = state()!!
        assertNull(state(eligible = false))
        assertFalse(admission.isCurrent(original, 1, 1))
        assertNull(content())
        assertNull(state(windowId = -1))
    }

    @Test fun identicalNewStateHasDifferentTokenAndRevokesOldOne() {
        val first = state()!!
        time++
        val latest = state(epoch = 2)!!
        assertNotSame(first, latest)
        assertFalse(admission.isCurrent(first, 1, 1))
        assertTrue(admission.isCurrent(latest, 2, 1))
    }

    @Test fun mismatchingFreshIdentityIsTerminalEvenIfOriginalRootReturnsLater() {
        for (packageName in listOf("other.app", "owned.app")) {
            val token = state()!!
            assertTrue(admission.reserveAttempt(token))
            assertFalse(admission.promote(token, packageName, if (packageName == "owned.app") 8 else 7))
            assertNull(admission.delayBeforeAttempt(token))
            assertFalse(admission.promote(token, "owned.app", 7))
        }
    }

    @Test fun promotionAndQueryClaimNeverRearmIdentityOrQueryAttempts() {
        val token = state()!!
        assertTrue(admission.reserveAttempt(token))
        assertTrue(admission.promote(token, "owned.app", 7))
        assertNull(admission.delayBeforeAttempt(token))
        assertTrue(admission.claimQuery(token))
        repeat(1_000) { assertSame(token, content()); assertFalse(admission.claimQuery(token)); assertFalse(admission.reserveAttempt(token)) }
        assertEquals(100L, token.observedAt)
    }

    @Test fun clearClockRollbackAndExpirationCannotReviveToken() {
        val token = state()!!
        time--
        assertFalse(admission.isCurrent(token, 1, 1))
        assertNull(content())
        time++
        assertFalse(admission.isCurrent(token, 1, 1))
        val replacement = state()!!
        admission.clear()
        assertFalse(admission.isCurrent(replacement, 1, 1))
        val expired = state()!!
        time += 1_000
        assertFalse(admission.isCurrent(expired, 1, 1))
        assertNull(admission.delayBeforeAttempt(expired))
    }

    @Test fun currentStatusPreservesShortCircuitOrderAndClockCountWithoutTraceWrites() {
        var reads = 0
        val checked = PrivateActivityAdmission { reads++; time }
        val token = checked.observe("owned.app", "owned.app.Ad", 7, true, true, time, 1, 1)!!
        reads = 0
        val traceSequence = FixtureAdmissionTrace.snapshot().lastOrNull()?.get(0)
        assertEquals(ContentAdmissionReason.EPOCH_CHANGED, checked.currentStatus(token, 2, 1))
        assertEquals(ContentAdmissionReason.GENERATION_CHANGED, checked.currentStatus(token, 1, 2))
        assertEquals(0, reads)
        assertEquals(ContentAdmissionReason.CURRENT, checked.currentStatus(token, 1, 1))
        assertEquals(1, reads)
        assertTrue(checked.isCurrent(token, 1, 1))
        assertEquals(2, reads)
        time += 1_000
        assertEquals(ContentAdmissionReason.EXPIRED, checked.currentStatus(token, 1, 1))
        assertEquals(3, reads)
        assertEquals(traceSequence, FixtureAdmissionTrace.snapshot().lastOrNull()?.get(0))
        checked.clear()
        assertEquals(ContentAdmissionReason.CANDIDATE_CHANGED, checked.currentStatus(token, 1, 1))
        assertEquals(3, reads)
    }


    @Test fun queryClaimExpiryIsDistinguishedWithoutAnotherClockOrGuardEvaluation() {
        var reads = 0
        val checked = PrivateActivityAdmission { reads++; time }
        val token = checked.observe("owned.app", "owned.app.Ad", 7, true, true, time, 1, 1)!!
        reads = 0
        assertEquals(ContentAdmissionReason.NOT_PROMOTED, checked.queryClaimStatus(token))
        assertEquals(0, reads)
        assertTrue(checked.reserveAttempt(token))
        assertTrue(checked.promote(token, "owned.app", 7))
        time = token.observedAt + 999
        assertTrue(checked.isCurrent(token, 1, 1))
        time++ // The deadline crosses after admissionCurrent, before claimQuery.
        reads = 0
        assertEquals(ContentAdmissionReason.EXPIRED, checked.queryClaimStatus(token))
        assertEquals(1, reads)
        assertFalse(token.queryClaimed)
        checked.clear()
        reads = 0
        assertEquals(ContentAdmissionReason.CANDIDATE_CHANGED, checked.queryClaimStatus(token))
        assertEquals(0, reads)
        val next = checked.observe("owned.app", "owned.app.Ad", 7, true, true, time, 2, 1)!!
        assertTrue(checked.reserveAttempt(next))
        assertTrue(checked.promote(next, "owned.app", 7))
        reads = 0
        assertEquals(ContentAdmissionReason.CURRENT, checked.queryClaimStatus(next))
        assertEquals(1, reads)
        assertEquals(ContentAdmissionReason.ALREADY_CLAIMED, checked.queryClaimStatus(next))
        assertEquals(1, reads)
    }

}
