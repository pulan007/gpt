// Private-fork addition, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.data

import org.junit.Assert.*
import org.junit.Test

class ReviewedRuleCatalogTest {
    private val ruleText = "{\"key\":7,\"action\":\"clickNode\"}"
    private val groupText = "{\"key\":3,\"rules\":[$ruleText]}"
    private val signer = "a".repeat(64)
    private val otherSigner = "b".repeat(64)
    private val context = "[id=\"example.reviewfixture:id/ad_panel\"][visibleToUser=true]"
    private val target = "[id=\"example.reviewfixture:id/dismiss\"][visibleToUser=true][clickable=true][editable=false]"
    private val forbidden = "[id=\"example.reviewfixture:id/reward\"]"

    private fun entry(
        packageName: String = "example.reviewfixture",
        versionCode: Long = 4_294_967_297L,
        signers: Set<String> = setOf(signer),
        activity: String = "example.reviewfixture.AdActivity",
        ruleSha256: String = ReviewedRulePolicy.sha256(ruleText),
        groupSha256: String = ReviewedRulePolicy.sha256(groupText),
        targetSelector: String = target,
        required: List<String> = listOf(context),
        forbiddenSelectors: List<String> = listOf(forbidden),
        purpose: ReviewedRulePurpose = ReviewedRulePurpose.AD_DISMISS,
    ) = ReviewedRuleEntry(
        packageName, versionCode, signers, activity, 3, 7, ruleSha256, groupSha256,
        targetSelector, required, forbiddenSelectors, purpose,
    )

    private fun candidate() = ReviewedRuleCandidate(
        packageName = "example.reviewfixture", isGlobal = false, groupKey = 3, ruleKey = 7,
        activityNames = listOf("example.reviewfixture.AdActivity"), action = "clickNode",
        hasPosition = false, hasSwipe = false, matches = listOf(context, target),
        anyMatches = emptyList(), excludeMatches = listOf(forbidden), excludeAllMatches = emptyList(),
        hasExternalRuleDependencies = false, serializedRule = ruleText, serializedGroup = groupText,
    )


    @Test fun immutableActivityScopeRequiresExactPackageAndFullClassName() {
        val source = mutableListOf(entry())
        val snapshot = ReviewedRuleCatalogSnapshot(source)
        source.clear()
        assertTrue(snapshot.supportsActivity("example.reviewfixture", "example.reviewfixture.AdActivity"))
        for ((pkg, activity) in listOf(
            "example.reviewfixture" to "example.reviewfixture.AdActivity.Child",
            "example.reviewfixture" to ".AdActivity",
            "example.reviewfixture" to "android.widget.TextView",
            "example.reviewfixture" to "example.reviewfixture.LoginActivity",
            "example.reviewfixture.child" to "example.reviewfixture.AdActivity",
            "other.app" to "example.reviewfixture.AdActivity",
            "example.reviewfixture" to "*",
        )) assertFalse(snapshot.supportsActivity(pkg, activity))
        assertFalse(ReviewedRuleCatalogSnapshot(emptyList()).supportsActivity(
            "example.reviewfixture", "example.reviewfixture.AdActivity"))
    }

    @Test fun invalidOrAmbiguousCompiledScopeCannotCreateActivityCandidate() {
        for (entries in listOf(listOf(entry(), entry()),
            listOf(entry(), entry(purpose = ReviewedRulePurpose.REWARD)),
            listOf(entry(activity = "*")), listOf(entry(versionCode = 0)))) {
            val snapshot = ReviewedRuleCatalogSnapshot(entries)
            assertNull(snapshot.consentRevision("example.reviewfixture"))
            assertFalse(snapshot.supportsActivity("example.reviewfixture", "example.reviewfixture.AdActivity"))
        }
    }

    @Test fun onlyOneExactCompleteCompiledEntryAdmitsContent() {
        val reviewed = entry()
        assertSame(reviewed, ReviewedRulePolicy.admit(candidate(), listOf(reviewed)))
        assertNull(ReviewedRulePolicy.admit(candidate(), emptyList()))
        assertNull(ReviewedRulePolicy.admit(candidate(), listOf(reviewed, reviewed)))
        assertNull(ReviewedRulePolicy.admit(candidate(), listOf(reviewed, entry(versionCode = 2))))
    }

    @Test fun globalMissingKeyOtherPackageAndUnsafeActionsNeverAdmit() {
        val safe = candidate()
        val bad = listOf(
            safe.copy(isGlobal = true), safe.copy(packageName = null), safe.copy(ruleKey = null),
            safe.copy(packageName = "example.other"), safe.copy(groupKey = 5), safe.copy(ruleKey = 8),
            safe.copy(action = null), safe.copy(action = "click"), safe.copy(action = "back"),
            safe.copy(hasPosition = true), safe.copy(hasSwipe = true),
            safe.copy(hasExternalRuleDependencies = true),
        )
        bad.forEach { assertNull(it.toString(), ReviewedRulePolicy.admit(it, listOf(entry()))) }
    }

    @Test fun exactFullActivityIsRequiredWithoutPrefixOrWildcardFallback() {
        for (activities in listOf(
            emptyList(), listOf("*"), listOf(".AdActivity"), listOf("example.reviewfixture"),
            listOf("example.reviewfixture.AdActivity.Child"),
            listOf("example.reviewfixture.AdActivity", "example.reviewfixture.Other"),
        )) assertNull(ReviewedRulePolicy.admit(candidate().copy(activityNames = activities), listOf(entry())))
    }

    @Test fun contextSelectorsCannotBeDroppedReorderedOrSubstituted() {
        val safe = candidate()
        listOf(
            safe.copy(matches = listOf(target)), safe.copy(matches = listOf(target, context)),
            safe.copy(matches = listOf("*")), safe.copy(matches = listOf(context, "[text=\"Skip\"]")),
            safe.copy(excludeMatches = emptyList()), safe.copy(anyMatches = listOf(target)),
            safe.copy(excludeAllMatches = listOf(forbidden)),
        ).forEach { assertNull(ReviewedRulePolicy.admit(it, listOf(entry()))) }
    }

    @Test fun hashesCheckActualRuleAndCompleteGroupIncludingSiblingChanges() {
        assertNull(ReviewedRulePolicy.admit(candidate().copy(serializedRule = "$ruleText "), listOf(entry())))
        assertNull(ReviewedRulePolicy.admit(candidate().copy(serializedGroup = "$groupText "), listOf(entry())))
        assertEquals(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            ReviewedRulePolicy.sha256("abc"),
        )
    }

    @Test fun incompleteOrWildcardCatalogEntriesFailClosed() {
        val bad = listOf(
            entry(packageName = ""), entry(packageName = "*"), entry(packageName = "example.*"),
            entry(versionCode = 0), entry(versionCode = -1), entry(signers = emptySet()),
            entry(signers = setOf("*")), entry(signers = setOf(signer.uppercase())),
            entry(activity = "*"), entry(activity = "example.reviewfixture.*"), entry(activity = ".AdActivity"),
            entry(ruleSha256 = ""), entry(groupSha256 = "*"), entry(targetSelector = "*"),
            entry(required = emptyList()), entry(required = listOf("")), entry(required = listOf("*")),
            entry(forbiddenSelectors = emptyList()), entry(forbiddenSelectors = listOf("*")),
            entry(required = listOf(target)), entry(forbiddenSelectors = listOf(context)),
        )
        bad.forEach { assertFalse(ReviewedRulePolicy.isComplete(it)) }
    }

    @Test fun rewardTransactionAuthPermissionAndUnknownCategoriesAreDenied() {
        ReviewedRulePurpose.entries.filter { it != ReviewedRulePurpose.AD_DISMISS }.forEach {
            val forbiddenEntry = entry(purpose = it)
            assertFalse(ReviewedRulePolicy.isComplete(forbiddenEntry))
            assertNull(ReviewedRulePolicy.admit(candidate(), listOf(forbiddenEntry)))
        }
    }

    @Test fun fuzzyGenericTextAndUnanchoredSelectorsAreRejectedEvenWhenHashed() {
        for (selector in listOf(
            "[text='Skip']", "[text*='Skip']", "[text~='.*Skip.*']", "X", "@X", "View[clickable=true]",
            "[id='example.reviewfixture:id/*']", "[id^='example.reviewfixture:id/dismiss']",
            "[id='example.other:id/dismiss'][visibleToUser=true][clickable=true][editable=false]",
            "[vid='dismiss'][visibleToUser=true][clickable=true][editable=false]",
            "[id='example.reviewfixture:id/dismiss']", "$target + *", "$target || *",
        )) assertFalse(selector, ReviewedRulePolicy.isComplete(entry(targetSelector = selector)))
        assertFalse(ReviewedRulePolicy.isComplete(entry(required = listOf("[text='Ad']"))))
        assertFalse(ReviewedRulePolicy.isComplete(entry(forbiddenSelectors = listOf("[text*='Reward']"))))
    }

    @Test fun identityUsesLongVersionExactCurrentSignerSetAndExactActivity() {
        val reviewed = entry(signers = setOf(signer, otherSigner))
        val identity = ReviewedAppIdentity(
            reviewed.packageName, reviewed.versionCode, setOf(otherSigner, signer), reviewed.activityName,
        )
        assertTrue(ReviewedRulePolicy.matchesIdentity(reviewed, identity))
        listOf(
            identity.copy(versionCode = 1L), // Same lower 32 bits is not the same version.
            identity.copy(versionCode = reviewed.versionCode + 1),
            identity.copy(currentSignerSha256 = setOf(signer)),
            identity.copy(currentSignerSha256 = setOf(signer, otherSigner, "c".repeat(64))),
            identity.copy(currentSignerSha256 = emptySet()),
            identity.copy(activityName = identity.activityName + ".Child"),
            identity.copy(packageName = identity.packageName + ".other"),
        ).forEach { assertFalse(ReviewedRulePolicy.matchesIdentity(reviewed, it)) }
    }

    @Test fun retainedMutableCollectionsCannotChangeReview() {
        val signers = mutableSetOf(signer)
        val contexts = mutableListOf(context)
        val forbiddenContexts = mutableListOf(forbidden)
        val reviewed = entry(signers = signers, required = contexts, forbiddenSelectors = forbiddenContexts)
        signers.clear(); contexts.clear(); forbiddenContexts.clear()
        assertEquals(setOf(signer), reviewed.currentSignerSha256)
        assertEquals(listOf(context), reviewed.requiredContextSelectors)
        assertEquals(listOf(forbidden), reviewed.forbiddenContextSelectors)
        assertThrows(UnsupportedOperationException::class.java) {
            (reviewed.currentSignerSha256 as MutableSet<String>).clear()
        }
        assertThrows(UnsupportedOperationException::class.java) {
            (reviewed.requiredContextSelectors as MutableList<String>).clear()
        }
        assertThrows(UnsupportedOperationException::class.java) {
            (reviewed.forbiddenContextSelectors as MutableList<String>).clear()
        }
    }

    @Test fun consentRevisionCoversExactReviewedScopeAndRejectsAmbiguity() {
        val reviewed = entry()
        val revision = ReviewedRulePolicy.consentRevision(reviewed.packageName, listOf(reviewed))
        assertNotNull(revision)
        assertEquals(revision, ReviewedRulePolicy.consentRevision(reviewed.packageName, listOf(entry())))
        val changes = listOf(
            entry(versionCode = reviewed.versionCode + 1), entry(signers = setOf(otherSigner)),
            entry(activity = "example.reviewfixture.OtherActivity"), entry(ruleSha256 = otherSigner),
            entry(groupSha256 = otherSigner),
            entry(targetSelector = target.replace("/dismiss", "/other_dismiss")),
            entry(required = listOf(context.replace("/ad_panel", "/other_panel"))),
            entry(forbiddenSelectors = listOf(forbidden.replace("/reward", "/transaction"))),
        )
        changes.forEach {
            assertNotEquals(revision, ReviewedRulePolicy.consentRevision(reviewed.packageName, listOf(it)))
        }
        assertNull(ReviewedRulePolicy.consentRevision(reviewed.packageName, emptyList()))
        assertNull(ReviewedRulePolicy.consentRevision(reviewed.packageName, listOf(reviewed, reviewed)))
        assertNull(ReviewedRulePolicy.consentRevision(reviewed.packageName, listOf(entry(purpose = ReviewedRulePurpose.REWARD))))
        val first = entry(signers = linkedSetOf(signer, otherSigner))
        val reordered = entry(signers = linkedSetOf(otherSigner, signer))
        assertEquals(
            ReviewedRulePolicy.consentRevision(reviewed.packageName, listOf(first)),
            ReviewedRulePolicy.consentRevision(reviewed.packageName, listOf(reordered)),
        )
    }
}
