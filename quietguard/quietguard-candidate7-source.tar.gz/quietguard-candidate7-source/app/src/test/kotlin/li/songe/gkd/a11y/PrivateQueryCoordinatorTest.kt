/* Private-fork tests, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import org.junit.Assert.*
import org.junit.Test

class PrivateQueryCoordinatorTest {
    private class ManualExecutor : Executor {
        val tasks = ArrayDeque<Runnable>()
        override fun execute(command: Runnable) { tasks.addLast(command) }
        fun finishRead() { tasks.removeFirst().run() }
    }

    @Test fun admissionIsClaimedBeforeDispatchAndOnlyLatestPendingSurvives() {
        val work = LatestWork<Int>()
        val active = work.offer(0)!!
        repeat(10_000) { assertNull(work.offer(it + 1)) }
        val latest = work.complete(active)!!
        assertEquals(10_000, latest.value)
        assertNull(work.complete(active)) // duplicate completion cannot release the new owner
        assertNull(work.offer(-1, keepPending = false)) // a timer cannot replace the event
        assertNull(work.complete(latest))
        assertNotNull(work.offer(20_000))
    }

    @Test fun competingAdmissionsHaveExactlyOneOwner() {
        val work = LatestWork<Int>()
        val count = AtomicInteger()
        val start = CountDownLatch(1)
        val pool = Executors.newFixedThreadPool(8)
        try {
            val results = (0 until 100).map { i -> pool.submit { start.await(); if (work.offer(i) != null) count.incrementAndGet() } }
            start.countDown()
            results.forEach { it.get(2, TimeUnit.SECONDS) }
            assertEquals(1, count.get())
        } finally { pool.shutdownNow() }
    }

    @Test fun coalescingKeepsLastTwoAndMixedEventsRequireRoot() {
        data class Event(val kind: Int, val id: Int)
        val same = { a: Event, b: Event -> a.kind == b.kind }
        var batch = EventBatch(Event(1, 0))
        repeat(10_000) { batch = batch.merge(EventBatch(Event(1, it + 1)), same) }
        assertEquals(listOf(9_999, 10_000), batch.sources()!!.map { it.id })
        batch = batch.merge(EventBatch(Event(2, 10_001)), same)
        batch = batch.merge(EventBatch(Event(2, 10_002)), same)
        assertNull(batch.sources())
        assertEquals(10_002, batch.latest.id)
    }

    @Test fun mergingBatchesPreservesOriginalAllSameAndLastTwoDecision() {
        for (mask in 0 until 256) {
            val events = (0..7).map { (mask shr it) and 1 }
            val a = events.take(4).map { EventBatch(it) }.reduce { x, y -> x.merge(y, Int::equals) }
            val b = events.drop(4).map { EventBatch(it) }.reduce { x, y -> x.merge(y, Int::equals) }
            val actual = a.merge(b, Int::equals).sources()
            val expected = if (events.distinct().size == 1) events.takeLast(2) else null
            assertEquals(expected, actual)
        }
    }

    @Test fun followUpsHaveOneTimerAbsoluteDeadlineAndNoSelfRenewal() {
        var time = 0L
        val budget = FollowUpBudget({ time })
        assertFalse(budget.isOpen())
        budget.reset()
        var count = 0
        while (true) {
            val timer = budget.reserve(300) ?: break
            assertNull(budget.reserve(300))
            time += 300
            assertTrue(budget.release(timer))
            assertFalse(budget.release(timer))
            count++
        }
        assertEquals(9, count)
        time = 3_000
        assertFalse(budget.isOpen())
        assertNull(budget.reserve(300))
        time = 100_000
        assertNull(budget.reserve(300))
        budget.reset() // Only a real external stimulus gets a new window.
        assertNotNull(budget.reserve(300))
    }

    @Test fun attemptLimitIsIndependentOfElapsedTime() {
        val budget = FollowUpBudget({ 0L }, durationMs = 100_000, maxAttempts = 3)
        budget.reset()
        repeat(3) { assertTrue(budget.release(budget.reserve(300)!!)) }
        assertNull(budget.reserve(300))
    }

    @Test fun resettingWithTimerPendingDoesNotCreateExtraTimer() {
        var time = 0L
        val budget = FollowUpBudget({ time })
        budget.reset()
        val first = budget.reserve(300)!!
        time = 100
        budget.reset()
        assertNull(budget.reserve(300))
        time = 300
        assertTrue(budget.release(first))
        assertNotNull(budget.reserve(300))
    }

    @Test fun cancelledQueuedReadRetainsOwnershipUntilPhysicalTaskFinishes() = runBlocking {
        val executor = ManualExecutor()
        val owner = PhysicalReadOwner({ 0L }, executor)
        var reads = 0
        val waiter = async(start = CoroutineStart.UNDISPATCHED) { owner.readAsync(500, { true }) { reads++; "root" } }
        waiter.cancelAndJoin()
        assertNull(owner.read(100, { true }) { reads++; "appId" })
        assertEquals(1, executor.tasks.size)
        executor.finishRead()
        assertEquals(0, reads)
        assertEquals("next service", owner.read(500, { true }) { "next service" })
    }

    @Test fun lateReadAndChangedServiceDiscardEvidence() = runBlocking {
        val executor = ManualExecutor()
        var time = 0L
        var current = true
        val owner = PhysicalReadOwner({ time }, executor)
        val late = async(start = CoroutineStart.UNDISPATCHED) {
            owner.readAsync(500, { current }) { time = 500; "stale root" }
        }
        executor.finishRead()
        assertNull(late.await())
        time = 600
        val replaced = async(start = CoroutineStart.UNDISPATCHED) {
            owner.readAsync(500, { current }) { current = false; "old service" }
        }
        executor.finishRead()
        assertNull(replaced.await())
    }

    @Test fun expiredQueuedReadDoesNotEnterBinderAtAll() = runBlocking {
        val executor = ManualExecutor()
        var time = 0L
        val owner = PhysicalReadOwner({ time }, executor)
        val result = async(start = CoroutineStart.UNDISPATCHED) {
            owner.readAsync<String>(100, { true }) { error("Expired work entered Binder") }
        }
        time = 100
        executor.finishRead()
        assertNull(result.await())
    }

    @Test fun timeoutReturnsWhileBlockedReadStillOwnsRootAndAppIdPaths() = runBlocking {
        val executor = Executors.newSingleThreadExecutor()
        val entered = CountDownLatch(1)
        val returnFromBinder = CountDownLatch(1)
        val physicallyFinished = CountDownLatch(1)
        val owner = PhysicalReadOwner(System::currentTimeMillis, executor)
        val physicalReads = AtomicInteger()
        try {
            val result = async(start = CoroutineStart.UNDISPATCHED) {
                withTimeoutOrNull(100) {
                    owner.readAsync(500, { true }) {
                        physicalReads.incrementAndGet()
                        entered.countDown()
                        // Models Binder which ignores caller cancellation/interruption.
                        returnFromBinder.await()
                        "root"
                    }
                }
            }
            assertTrue(entered.await(2, TimeUnit.SECONDS))
            assertNull(result.await())
            assertNull(owner.readAsync(100, { true }) { physicalReads.incrementAndGet(); "appId" })
            assertNull(owner.read(500, { true }) { physicalReads.incrementAndGet(); "windows" })
            assertEquals(1, physicalReads.get())
            // The caller can process another event while the read remains physically blocked.
            assertEquals("UI remains responsive", async { "UI remains responsive" }.await())
            returnFromBinder.countDown()
            executor.execute { physicallyFinished.countDown() }
            assertTrue(physicallyFinished.await(2, TimeUnit.SECONDS))
            assertEquals("fresh", owner.read(500, { true }) { "fresh" })
        } finally { returnFromBinder.countDown(); executor.shutdownNow() }
    }

    @Test fun querySessionReentersOnlyWithItsCoroutineToken() = runBlocking {
        val owner = PhysicalReadOwner({ 0L }, ManualExecutor())
        val ready = CompletableDeferred<Unit>()
        val finish = CompletableDeferred<Unit>()
        val query = async(start = CoroutineStart.UNDISPATCHED) {
            owner.withOwnership {
                assertEquals("nested root", owner.read(500, { true }) { "nested root" })
                ready.complete(Unit)
                finish.await()
            }
        }
        ready.await()
        // Same JVM thread, different coroutine: it must not inherit query reentrancy.
        assertNull(owner.read(100, { true }) { error("Borrowed another coroutine's lease") })
        assertNull(owner.withOwnership { error("Overlapping query") })
        finish.complete(Unit)
        query.await()
        assertEquals("fresh", owner.read(500, { true }) { "fresh" })
    }

    @Test fun staleAndCancelledResultsAreDisposedExactlyOnce() = runBlocking {
        var time = 0L
        var disposed = 0
        val executor = ManualExecutor()
        val owner = PhysicalReadOwner({ time }, executor)
        assertNull(owner.read(100, { true }, { _: String -> disposed++ }) { time = 100; "stale" })
        assertEquals(1, disposed)
        val result = async(start = CoroutineStart.UNDISPATCHED) {
            owner.readAsync(100, { true }, { _: String -> disposed++ }) { time += 100; "late" }
        }
        executor.finishRead()
        assertNull(result.await())
        assertEquals(2, disposed)
    }

    @Test fun failedSubmissionAndReadExceptionReleasePhysicalOwnership() = runBlocking {
        val rejected = PhysicalReadOwner({ 0L }, Executor { throw IllegalStateException("stopped") })
        assertNull(rejected.readAsync(500, { true }) { "unused" })
        assertEquals("fresh", rejected.read(500, { true }) { "fresh" })
        val executor = ManualExecutor()
        val owner = PhysicalReadOwner({ 0L }, executor)
        val failed = async(start = CoroutineStart.UNDISPATCHED) { owner.readAsync<String>(500, { true }) { throw IllegalStateException() } }
        executor.finishRead()
        assertNull(failed.await())
        assertEquals("fresh", owner.read(500, { true }) { "fresh" })
    }
}
