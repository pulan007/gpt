// Private-fork optimization regression checks, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.data

import org.junit.Assert.*
import org.junit.Test

class ReviewedRuleOptimizationTest {
    private val app = "example.reviewfixture"
    private val targetFlags = "[visibleToUser=true][clickable=true][editable=false]"
    private val contextFlags = "[visibleToUser=true]"
    private val ruleText = "{\"key\":7,\"action\":\"clickNode\"}"
    private val groupText = "{\"key\":3,\"rules\":[$ruleText]}"
    private val signer = "a".repeat(64)
    private val ruleDigest = ReviewedRulePolicy.sha256(ruleText)
    private val groupDigest = ReviewedRulePolicy.sha256(groupText)

    private fun selector(packageName: String, id: String, flags: String) = "[id='$packageName:id/$id']$flags"

    private fun entry(
        packageName: String = app,
        versionCode: Long = 4_294_967_297L,
        signers: Set<String> = setOf(signer),
        activity: String = "$app.AdActivity",
        groupKey: Int = 3,
        ruleKey: Int = 7,
        ruleSha256: String = ruleDigest,
        groupSha256: String = groupDigest,
        target: String = selector(packageName, "dismiss", targetFlags),
        required: List<String> = listOf(selector(packageName, "ad_panel", contextFlags)),
        forbidden: List<String> = listOf(selector(packageName, "reward", "")),
        purpose: ReviewedRulePurpose = ReviewedRulePurpose.AD_DISMISS,
    ) = ReviewedRuleEntry(packageName, versionCode, signers, activity, groupKey, ruleKey,
        ruleSha256, groupSha256, target, required, forbidden, purpose)

    private fun candidate(reviewed: ReviewedRuleEntry = entry()) = ReviewedRuleCandidate(
        reviewed.packageName, false, reviewed.groupKey, reviewed.ruleKey,
        listOf(reviewed.activityName), "clickNode", false, false,
        reviewed.requiredContextSelectors + reviewed.targetSelector, emptyList(),
        reviewed.forbiddenContextSelectors, emptyList(), false, ruleText, groupText,
    )

    private fun sameCompleteness(reviewed: ReviewedRuleEntry) {
        assertEquals("${reviewed.packageName}: ${reviewed.targetSelector} / " +
            "${reviewed.requiredContextSelectors} / ${reviewed.forbiddenContextSelectors}",
            LegacyReviewedRulePolicy.isComplete(reviewed), ReviewedRulePolicy.isComplete(reviewed))
    }

    @Test fun constantGrammarsMatchFrozenPredicateAcrossPackageAndSelectorBoundaries() {
        val packages = listOf(app, "A.z", "a0.B_2.c3", "a.b.c", "", "a", ".a", "a.",
            "a..b", "1a.b", "a.1b", "_a.b", "a._b", "a-b.c", "a/b.c", "a.*",
            "a.+", "a.b$", "a.é", "a.中", "a.\\E", "a.b\n", "a.'b", "a.\"b") +
            (('A'..'Z') + ('a'..'z') + ('0'..'9') + '_').flatMap {
                listOf("a${it}.b${it}", "${it}a.${it}b")
            }
        for (packageName in packages) {
            // All legal segment characters, illegal leading characters and literal package syntax.
            sameCompleteness(entry(packageName = packageName))
            sameCompleteness(entry(packageName = packageName, target =
                selector(packageName, "dismiss", targetFlags).replace("'", "\"")))
        }
        val flags = listOf("", contextFlags, targetFlags,
            "[clickable=true][visibleToUser=true][editable=false]", "[visibleToUser=true][clickable=true]",
            "[visibleToUser=true][clickable=true][editable=true]", "[visibleToUser=false]",
            "[visibleToUser=true] ", "[visibleToUser =true]", "[visibleToUser=True]",
            "$targetFlags[enabled=true]", "$contextFlags$contextFlags", "[visibleToUser=true\n]")
        val ids = listOf("dismiss", "_", "A_09z", "", "9dismiss", "a-b", "a.b", "*",
            "dismiss/child", "é", "a b", "a\nb", "a:child")
        var checked = 0
        for (packageName in listOf(app, "A.z", "a0.B_2.c3", "a.*", "", "a.b\n")) {
            for (id in ids) for (flag in flags) for (open in listOf("'", "\"")) {
                for (close in listOf("'", "\"")) {
                    val text = "[id=$open$packageName:id/$id$close]$flag"
                    sameCompleteness(entry(packageName = packageName, target = text))
                    sameCompleteness(entry(packageName = packageName, required = listOf(text)))
                    sameCompleteness(entry(packageName = packageName, forbidden = listOf(text)))
                    checked += 3
                }
            }
        }
        assertEquals(12168, checked)
        for (other in listOf("example.reviewfixture.extra", "example.reviewfixture2", "exampleXreviewfixture", "example.other")) {
            sameCompleteness(entry(target = selector(other, "dismiss", targetFlags)))
            sameCompleteness(entry(required = listOf(selector(other, "ad_panel", contextFlags))))
            sameCompleteness(entry(forbidden = listOf(selector(other, "reward", ""))))
            assertFalse(ReviewedRulePolicy.isComplete(entry(target = selector(other, "dismiss", targetFlags))))
        }
        val good = entry()
        for (extra in listOf(" ", "\n", "@", "*", " + *", " || *", "[text='Skip']")) {
            for (text in listOf(extra + good.targetSelector, good.targetSelector + extra)) {
                sameCompleteness(entry(target = text))
                assertFalse(ReviewedRulePolicy.isComplete(entry(target = text)))
            }
            sameCompleteness(entry(required = listOf(extra + good.requiredContextSelectors.single())))
            sameCompleteness(entry(forbidden = listOf(good.forbiddenContextSelectors.single() + extra)))
        }
    }

    @Test fun completeEntryCombinationsKeepAdmissionIdentityAndConsentEquivalent() {
        val good = entry()
        val targets = listOf(good.targetSelector, good.targetSelector.replace("'", "\""), "*",
            good.targetSelector.replace(app, "$app.extra"))
        val contexts = listOf(good.requiredContextSelectors, emptyList(), listOf("*"),
            good.requiredContextSelectors + good.requiredContextSelectors)
        val forbidden = listOf(good.forbiddenContextSelectors, emptyList(), listOf("*"),
            good.forbiddenContextSelectors + good.forbiddenContextSelectors)
        for (target in targets) for (required in contexts) for (excluded in forbidden) {
            for (purpose in ReviewedRulePurpose.entries) {
                val reviewed = entry(target = target, required = required, forbidden = excluded, purpose = purpose)
                sameCompleteness(reviewed)
                val entries = listOf(reviewed)
                assertEquals(LegacyReviewedRulePolicy.admit(candidate(reviewed), entries),
                    ReviewedRulePolicy.admit(candidate(reviewed), entries))
                val identity = ReviewedAppIdentity(app, reviewed.versionCode, setOf(signer), reviewed.activityName)
                assertEquals(LegacyReviewedRulePolicy.matchesIdentity(reviewed, identity),
                    ReviewedRulePolicy.matchesIdentity(reviewed, identity))
                assertEquals(LegacyReviewedRulePolicy.consentRevision(app, entries),
                    ReviewedRuleCatalogSnapshot(entries).consentRevision(app))
            }
        }
    }

    @Test fun snapshotOwnsProviderListAndAllReachableCollectionsStayImmutable() {
        val signers = mutableSetOf(signer)
        val required = mutableListOf(selector(app, "ad_panel", contextFlags))
        val forbidden = mutableListOf(selector(app, "reward", ""))
        val reviewed = entry(signers = signers, required = required, forbidden = forbidden)
        val provider = mutableListOf(reviewed)
        val catalog = ReviewedRuleCatalogSnapshot(provider)
        val before = catalog.consentRevision(app)
        assertNotNull(before)
        signers.clear(); required.clear(); forbidden.clear()
        provider.clear(); provider += entry(packageName = "other.fixture"); provider += reviewed; provider += reviewed
        assertEquals(before, catalog.consentRevision(app))
        assertNull(catalog.consentRevision("other.fixture"))
        assertEquals(setOf(app), catalog.supportedPackageNames)
        assertEquals(1, catalog.supportedAppCount)
        assertEquals(1, catalog.reviewedRuleCount)
        assertFalse(catalog.isEmpty)
        val admitted = catalog.admit(candidate())!!
        assertSame(reviewed, admitted) // Entry is already deeply immutable; no duplicate ownership needed.
        assertThrows(UnsupportedOperationException::class.java) {
            (admitted.currentSignerSha256 as MutableSet<String>).clear()
        }
        assertThrows(UnsupportedOperationException::class.java) {
            (admitted.requiredContextSelectors as MutableList<String>).clear()
        }
        assertThrows(UnsupportedOperationException::class.java) {
            (admitted.forbiddenContextSelectors as MutableList<String>).clear()
        }
        assertThrows(UnsupportedOperationException::class.java) {
            (catalog.supportedPackageNames as MutableSet<String>).clear()
        }
        assertEquals(before, catalog.consentRevision(app))
        val emptySource = mutableListOf<ReviewedRuleEntry>()
        val empty = ReviewedRuleCatalogSnapshot(emptySource)
        emptySource += reviewed
        assertTrue(empty.isEmpty)
        assertNull(empty.consentRevision(app))
        assertNull(empty.admit(candidate()))
    }

    @Test fun cachedFingerprintsRemainByteIdenticalAndScopeChangesExpireConsent() {
        val good = entry()
        val revision = LegacyReviewedRulePolicy.consentRevision(app, listOf(good))!!
        val catalog = ReviewedRuleCatalogSnapshot(listOf(good))
        assertEquals(revision, catalog.consentRevision(app))
        repeat(100) { assertSame(catalog.consentRevision(app), catalog.consentRevision(app)) }
        val changes = listOf(entry(versionCode = 2), entry(signers = setOf("b".repeat(64))),
            entry(activity = "$app.OtherActivity"), entry(groupKey = 4), entry(ruleKey = 8),
            entry(ruleSha256 = "c".repeat(64)), entry(groupSha256 = "d".repeat(64)),
            entry(target = selector(app, "other_dismiss", targetFlags)),
            entry(required = listOf(selector(app, "other_panel", contextFlags))),
            entry(forbidden = listOf(selector(app, "other_reward", ""))))
        for (changed in changes) {
            val next = ReviewedRuleCatalogSnapshot(listOf(changed)).consentRevision(app)
            assertNotNull(next)
            assertNotEquals(revision, next)
            assertEquals(LegacyReviewedRulePolicy.consentRevision(app, listOf(changed)), next)
        }
        val first = entry(signers = linkedSetOf(signer, "b".repeat(64)))
        val second = entry(ruleKey = 8)
        val reordered = entry(signers = linkedSetOf("b".repeat(64), signer))
        assertEquals(ReviewedRuleCatalogSnapshot(listOf(first, second)).consentRevision(app),
            ReviewedRuleCatalogSnapshot(listOf(second, reordered)).consentRevision(app))
    }

    @Test fun invalidEntriesAndDuplicatesAreRetainedAndFailClosedExactlyAsBefore() {
        val good = entry()
        val cases = listOf(emptyList(), listOf(good, good), listOf(good, entry(versionCode = 2)),
            listOf(good, entry(ruleKey = 8, purpose = ReviewedRulePurpose.REWARD)),
            listOf(good, entry(ruleKey = 8, required = emptyList())),
            listOf(entry(packageName = "a.*")), listOf(entry(versionCode = 0)),
            listOf(entry(signers = emptySet())), listOf(entry(activity = "*")),
            listOf(entry(ruleSha256 = "")), listOf(entry(groupSha256 = "*")),
            listOf(entry(purpose = ReviewedRulePurpose.UNKNOWN)),
            listOf(good, entry(packageName = "other.fixture", purpose = ReviewedRulePurpose.REWARD)))
        for (entries in cases) {
            val catalog = ReviewedRuleCatalogSnapshot(entries)
            for (packageName in listOf(app, "a.*", "other.fixture", "unknown.fixture")) {
                assertEquals(LegacyReviewedRulePolicy.consentRevision(packageName, entries), catalog.consentRevision(packageName))
            }
            assertEquals(LegacyReviewedRulePolicy.admit(candidate(), entries), catalog.admit(candidate()))
            assertEquals(entries.filter(LegacyReviewedRulePolicy::isComplete).map { it.packageName }.toSet(),
                catalog.supportedPackageNames)
            assertEquals(entries.count(LegacyReviewedRulePolicy::isComplete), catalog.reviewedRuleCount)
            assertEquals(entries.isEmpty(), catalog.isEmpty)
        }
        // Policy remains a fresh calculation for arbitrary caller-owned lists, without memoization.
        val mutable = mutableListOf(good)
        assertNotNull(ReviewedRulePolicy.consentRevision(app, mutable))
        mutable += good
        assertNull(ReviewedRulePolicy.consentRevision(app, mutable))
    }

    @Test fun entryStructureCacheNeverCachesLiveIdentityOrConcurrentCallerResults() {
        val good = entry()
        val invalid = entry(versionCode = 0)
        val start = java.util.concurrent.CountDownLatch(1)
        val results = java.util.Collections.synchronizedList(mutableListOf<Pair<Boolean, Boolean>>())
        val workers = List(8) {
            Thread {
                start.await()
                results += ReviewedRulePolicy.isComplete(good) to ReviewedRulePolicy.isComplete(invalid)
            }.apply { start() }
        }
        start.countDown()
        workers.forEach { it.join(5_000); assertFalse(it.isAlive) }
        assertEquals(List(8) { true to false }, results)
        val liveSigners = mutableSetOf(signer)
        val live = ReviewedAppIdentity(app, good.versionCode, liveSigners, good.activityName)
        assertTrue(ReviewedRulePolicy.matchesIdentity(good, live))
        liveSigners.clear()
        assertFalse(ReviewedRulePolicy.matchesIdentity(good, live))
        liveSigners += signer
        assertTrue(ReviewedRulePolicy.matchesIdentity(good, live))
        assertFalse(ReviewedRulePolicy.matchesIdentity(good, live.copy(versionCode = 1L)))
        assertFalse(ReviewedRulePolicy.matchesIdentity(good, live.copy(activityName = "$app.OtherActivity")))
        assertFalse(ReviewedRulePolicy.matchesIdentity(good, live.copy(packageName = "$app.extra")))
    }

    @Test fun cachedCatalogRevisionNeverCachesOptInPreferenceState() {
        val catalog = ReviewedRuleCatalogSnapshot(listOf(entry()))
        val preferences = mutableMapOf<String, String>()
        var reads = 0
        var invalidations = 0
        val policy = PrivateAppOptInPolicy(catalog::consentRevision,
            { reads++; preferences[it] },
            { key, value -> if (value == null) preferences.remove(key) else preferences[key] = value },
            { invalidations++ })
        assertFalse(policy.isEnabled(app))
        assertTrue(policy.setEnabled(app, true))
        assertTrue(policy.isEnabled(app))
        preferences.remove(app)
        assertFalse(policy.isEnabled(app))
        preferences[app] = "stale-revision"
        assertFalse(policy.isEnabled(app))
        preferences[app] = catalog.consentRevision(app)!!
        assertTrue(policy.isEnabled(app))
        assertTrue(policy.setEnabled(app, false))
        assertFalse(policy.isEnabled(app))
        assertEquals(6, reads)
        assertEquals(2, invalidations)
        assertFalse(policy.setEnabled("unknown.fixture", true))
        assertNull(preferences["unknown.fixture"])
    }
}
