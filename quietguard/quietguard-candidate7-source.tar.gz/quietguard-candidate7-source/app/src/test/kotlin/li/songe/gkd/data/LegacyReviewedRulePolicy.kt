// Test oracle copied unchanged from the noninstrumented frozen policy, except its name.
// Source SHA-256: f2467384a5e56bfe29a942ff31bc2652e1b352244e5c7c5189f65f46bdc8b6fb.
// GNU GPL v3; see LICENSE. Never included in APK source sets.
package li.songe.gkd.data

import java.security.MessageDigest

internal object LegacyReviewedRulePolicy {
    private val packagePattern = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
    private val activityPattern = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z_$][A-Za-z0-9_$]*)+")
    private val digestPattern = Regex("[0-9a-f]{64}")

    fun sha256(serialized: String): String = sha256(serialized.toByteArray(Charsets.UTF_8))

    fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val hex = "0123456789abcdef"
        return CharArray(digest.size * 2) { index ->
            val byte = digest[index / 2].toInt() and 0xff
            hex[if (index % 2 == 0) byte ushr 4 else byte and 0x0f]
        }.concatToString()
    }

    /** Deliberately small grammar: one exact app-owned resource ID plus fixed node flags. */
    private fun exactSelector(selector: String, packageName: String, flags: String): Boolean =
        Regex("\\[id=(['\"])${Regex.escape(packageName)}:id/[A-Za-z_][A-Za-z0-9_]*\\1\\]${Regex.escape(flags)}")
            .matches(selector)

    fun isComplete(entry: ReviewedRuleEntry): Boolean =
        packagePattern.matches(entry.packageName) && entry.versionCode > 0L &&
            activityPattern.matches(entry.activityName) &&
            entry.currentSignerSha256.isNotEmpty() &&
            entry.currentSignerSha256.all(digestPattern::matches) &&
            digestPattern.matches(entry.ruleSha256) && digestPattern.matches(entry.groupSha256) &&
            entry.purpose == ReviewedRulePurpose.AD_DISMISS &&
            exactSelector(entry.targetSelector, entry.packageName,
                "[visibleToUser=true][clickable=true][editable=false]") &&
            entry.requiredContextSelectors.isNotEmpty() &&
            entry.requiredContextSelectors.all { exactSelector(it, entry.packageName, "[visibleToUser=true]") } &&
            entry.forbiddenContextSelectors.isNotEmpty() &&
            entry.forbiddenContextSelectors.all { exactSelector(it, entry.packageName, "") } &&
            (entry.requiredContextSelectors + entry.targetSelector + entry.forbiddenContextSelectors)
                .let { selectors -> selectors.distinct().size == selectors.size }

    /** Require exactly one entry for the claimed package/group/rule, even if duplicates agree. */
    fun admit(
        candidate: ReviewedRuleCandidate,
        entries: List<ReviewedRuleEntry>,
    ): ReviewedRuleEntry? {
        if (candidate.isGlobal || candidate.packageName == null || candidate.ruleKey == null ||
            candidate.hasExternalRuleDependencies ||
            !PrivateActionPolicy.allowsAction(candidate.action, candidate.hasPosition, candidate.hasSwipe) ||
            candidate.anyMatches.isNotEmpty() || candidate.excludeAllMatches.isNotEmpty()
        ) return null
        val entry = entries.filter {
            it.packageName == candidate.packageName && it.groupKey == candidate.groupKey &&
                it.ruleKey == candidate.ruleKey
        }.singleOrNull() ?: return null
        if (!isComplete(entry) || candidate.activityNames != listOf(entry.activityName) ||
            // A11yContext.queryRule returns the last matched selector's node.
            candidate.matches != entry.requiredContextSelectors + entry.targetSelector ||
            candidate.excludeMatches != entry.forbiddenContextSelectors ||
            sha256(candidate.serializedRule) != entry.ruleSha256 ||
            sha256(candidate.serializedGroup) != entry.groupSha256
        ) return null
        return entry
    }

    /** Current signer set equality rejects subsets, added signers and old signer history. */
    fun matchesIdentity(entry: ReviewedRuleEntry, identity: ReviewedAppIdentity): Boolean =
        isComplete(entry) && identity.packageName == entry.packageName &&
            identity.versionCode == entry.versionCode &&
            identity.currentSignerSha256 == entry.currentSignerSha256 &&
            identity.activityName == entry.activityName

    /** Per-app consent expires if any reviewed scope or rule content for that app changes. */
    fun consentRevision(packageName: String, entries: List<ReviewedRuleEntry>): String? {
        val appEntries = entries.filter { it.packageName == packageName }
        if (appEntries.isEmpty() || appEntries.any { !isComplete(it) } ||
            appEntries.map { it.groupKey to it.ruleKey }.distinct().size != appEntries.size
        ) return null
        val fingerprints = appEntries.map { entry ->
            val encoded = buildString {
                fun field(value: String) { append(value.length).append(':').append(value) }
                fun fields(values: List<String>) {
                    field(values.size.toString())
                    values.forEach(::field)
                }
                field(entry.packageName)
                field(entry.versionCode.toString())
                fields(entry.currentSignerSha256.sorted())
                field(entry.activityName)
                field(entry.groupKey.toString())
                field(entry.ruleKey.toString())
                field(entry.ruleSha256)
                field(entry.groupSha256)
                field(entry.targetSelector)
                fields(entry.requiredContextSelectors)
                fields(entry.forbiddenContextSelectors)
                field(entry.purpose.name)
            }
            sha256(encoded)
        }.sorted()
        return sha256("gkd-private-review-consent-v1\n" + fingerprints.joinToString("\n"))
    }
}

