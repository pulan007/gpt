// Private-fork addition, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.data

import org.junit.Assert.assertEquals
import org.junit.Test

class PrivateActionPolicyTest {
    @Test
    fun onlyExplicitNodeClickWithoutLocationIsAllowed() {
        val actions = listOf(
            null, "", "unknown", "click", "clickCenter", "longClick", "longClickNode",
            "longClickCenter", "swipe", "back", "none", "ClickNode", " clickNode",
            "clickNode ", "clickNode",
        )
        for (action in actions) {
            for (hasPosition in listOf(false, true)) {
                for (hasSwipe in listOf(false, true)) {
                    assertEquals(
                        "action=$action, position=$hasPosition, swipe=$hasSwipe",
                        action == "clickNode" && !hasPosition && !hasSwipe,
                        PrivateActionPolicy.allowsAction(action, hasPosition, hasSwipe),
                    )
                }
            }
        }
    }

    @Test
    fun onlyVisibleEnabledClickableNonInputNodeIsAllowed() {
        // Exhaust all flag combinations so each disqualifier is tested independently.
        for (flags in 0 until 32) {
            assertEquals(
                "node flags=$flags",
                flags == 0b00111,
                PrivateActionPolicy.allowsNode(
                    isVisibleToUser = flags and 1 != 0,
                    isEnabled = flags and 2 != 0,
                    isClickable = flags and 4 != 0,
                    isPassword = flags and 8 != 0,
                    isEditable = flags and 16 != 0,
                ),
            )
        }
    }
}
