package li.songe.gkd.a11y

// Private derivative, 2026-10-07. GPL-3.0; see LICENSE.
import java.util.ArrayDeque

/** External event storms cannot reset or renew this process-wide rolling budget. */
internal class PrivateScanBudget(
    private val now: () -> Long,
    private val maxAdmissions: Int = 12,
    private val windowMs: Long = 60_000L,
    private val minimumGapMs: Long = 500L,
) {
    private val admitted = ArrayDeque<Long>()
    private var previousClock: Long? = null
    private var invalidClock = false

    init {
        require(maxAdmissions > 0 && windowMs > 0 && minimumGapMs >= 0)
    }

    @Synchronized
    fun tryAcquire(): Boolean {
        val t = now()
        if (invalidClock || t < 0 || previousClock?.let { t < it } == true) {
            invalidClock = true
            return false
        }
        previousClock = t
        while (admitted.isNotEmpty() && t - admitted.first >= windowMs) admitted.removeFirst()
        if (admitted.size >= maxAdmissions ||
            admitted.peekLast()?.let { t - it < minimumGapMs } == true
        ) return false
        admitted.addLast(t)
        return true
    }
}
