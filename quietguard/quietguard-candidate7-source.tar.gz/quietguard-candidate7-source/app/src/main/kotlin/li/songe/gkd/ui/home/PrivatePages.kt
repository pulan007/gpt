package li.songe.gkd.ui.home

// Private derivative UI, 2026-10-07. GKD GPL-3.0; see LICENSE.
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.update
import li.songe.gkd.META
import li.songe.gkd.PrivateForkInfo
import li.songe.gkd.PrivateAutomationControl
import li.songe.gkd.data.ReviewedRuleCatalog
import li.songe.gkd.data.PrivateAppConsent
import li.songe.gkd.service.A11yService
import li.songe.gkd.store.actionCountFlow
import li.songe.gkd.store.storeFlow
import li.songe.gkd.ui.component.PerfTopAppBar
import li.songe.gkd.util.openA11ySettings
import li.songe.gkd.util.openUri

@Composable
fun usePrivateControlPage(): ScaffoldExt {
    val settings by storeFlow.collectAsState()
    val running by A11yService.isRunning.collectAsState()
    val accepted by actionCountFlow.collectAsState()
    return ScaffoldExt(
        navItem = BottomNavItem.Control,
        topBar = { PerfTopAppBar(title = { Text(PrivateForkInfo.NAME) }) },
    ) { padding ->
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("自动处理主开关", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Switch(
                            checked = settings.enableMatch,
                            onCheckedChange = PrivateAutomationControl::setMasterEnabled,
                        )
                    }
                    Text(if (settings.enableMatch) "已开启；仅已验证且单独启用的规则有资格运行。" else "已关闭，不提交自动点击。")
                    Text("暂停时关闭此开关；已经提交到系统的点击无法撤回。")
                }
            }
            Text(if (running) "系统无障碍服务已连接" else "系统无障碍服务未连接")
            Button(onClick = { openA11ySettings() }) { Text("打开系统无障碍设置") }
            Text("TEST ONLY · 仅自有模拟测试；真实应用0", style = MaterialTheme.typography.titleMedium)
            Text("仅自有模拟测试；真实应用0。编译测试条目：${ReviewedRuleCatalog.reviewedRuleCount}。仍须手动保存精确草稿、开启本应用授权及主开关。")
            ReviewedRuleCatalog.supportedPackageNames.sorted().forEach { packageName ->
                var optedIn by remember(packageName, ReviewedRuleCatalog.consentRevision(packageName)) {
                    mutableStateOf(PrivateAppConsent.isEnabled(packageName))
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("TEST ONLY 自有 Demo\n$packageName", Modifier.weight(1f))
                    Switch(checked = optedIn, onCheckedChange = { enabled ->
                        PrivateAppConsent.setEnabled(packageName, enabled)
                        optedIn = PrivateAppConsent.isEnabled(packageName)
                    })
                }
            }
            Text("系统已接受的控件点击：$accepted 次。此计数不能证明广告成功关闭或奖励已到账。")
            Text(PrivateForkInfo.SCOPE)
        }
    }
}

@Composable
fun PrivateAboutContent() {
    Text(PrivateForkInfo.NAME, style = MaterialTheme.typography.titleLarge)
    Text("${META.versionName} · 基于 ${PrivateForkInfo.UPSTREAM_VERSION}")
    Text(PrivateForkInfo.NOTICE)
    Text("本项目的对应源码、测试记录和修改说明随安装包提供。当前调试签名只用于测试，不代表 GKD 官方签名。")
    Text(PrivateForkInfo.PRIVACY)
    Text(PrivateForkInfo.SCOPE)
    Text("适配仅对逐项验证的版本负责；无障碍权限需要本人设置。当前没有真实手机耗电、发热或 HyperOS 效果结论。")
    TextButton(onClick = { openUri("https://github.com/gkd-kit/gkd/tree/${PrivateForkInfo.UPSTREAM_COMMIT}") }) {
        Text("查看上游源码与原作者署名")
    }
    TextButton(onClick = { openUri("https://www.gnu.org/licenses/gpl-3.0.html") }) {
        Text("查看 GPL-3.0 许可")
    }
}

@Composable
fun usePrivateSettingsPage(): ScaffoldExt = ScaffoldExt(navItem = BottomNavItem.Settings) { padding ->
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) { PrivateAboutContent() }
}
