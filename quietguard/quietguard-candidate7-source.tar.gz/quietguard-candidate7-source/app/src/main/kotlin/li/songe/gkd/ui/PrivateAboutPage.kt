package li.songe.gkd.ui

// Private derivative, 2026-10-07. GPL-3.0; see LICENSE.
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import li.songe.gkd.ui.component.PerfIcon
import li.songe.gkd.ui.component.PerfIconButton
import li.songe.gkd.ui.component.PerfTopAppBar
import li.songe.gkd.ui.home.PrivateAboutContent
import li.songe.gkd.ui.share.LocalMainViewModel

@Composable
fun AboutPage() {
    val mainVm = LocalMainViewModel.current
    Scaffold(topBar = {
        PerfTopAppBar(
            title = { Text("私人修改版说明") },
            navigationIcon = {
                PerfIconButton(imageVector = PerfIcon.ArrowBack, onClick = { mainVm.popPage() })
            },
        )
    }) { padding ->
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) { PrivateAboutContent() }
    }
}
