package li.songe.gkd.ui.component

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.takeOrElse
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import li.songe.gkd.ui.icon.SportsBasketball

@Composable
fun GroupNameText(
    modifier: Modifier = Modifier,
    preText: String? = null,
    isGlobal: Boolean,
    text: String,
    color: Color = Color.Unspecified,
    style: TextStyle = LocalTextStyle.current,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
) {
    if (isGlobal) {
        val text = remember(preText, text) {
            buildAnnotatedString {
                if (preText != null) {
                    append(preText)
                }
                appendInlineContent("icon")
                append(text)
            }
        }
        val textColor = color.takeOrElse { style.color.takeOrElse { LocalContentColor.current } }
        val inlineContent = remember(style, textColor) {
            mapOf(
                "icon" to InlineTextContent(
                    placeholder = Placeholder(
                        width = style.fontSize,
                        height = style.lineHeight,
                        placeholderVerticalAlign = PlaceholderVerticalAlign.Center
                    )
                ) {
                    PerfIcon(
                        imageVector = SportsBasketball,
                        modifier = Modifier.fillMaxSize(),
                        tint = textColor
                    )
                }
            )
        }
        Text(
            modifier = modifier,
            text = text,
            inlineContent = inlineContent,
            style = style,
            color = color,
            overflow = overflow,
            softWrap = softWrap,
            maxLines = maxLines,
        )
    } else {
        Text(
            text = if (preText.isNullOrEmpty()) {
                text
            } else {
                preText + text
            },
            style = style,
            color = color,
            overflow = overflow,
            softWrap = softWrap,
            maxLines = maxLines,
        )
    }
}
