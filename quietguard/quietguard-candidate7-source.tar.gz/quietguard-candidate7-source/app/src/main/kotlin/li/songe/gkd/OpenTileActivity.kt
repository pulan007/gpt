// Private offline-profile modifications, 2026-10-07; GKD GPL-3.0, see LICENSE.
package li.songe.gkd

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.net.toUri
import li.songe.gkd.util.extraCptName

class OpenTileActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!PrivateCapabilities.EXTERNAL_COMMANDS) {
            li.songe.gkd.util.toast("私有离线版已禁用：外部导入与链接")
            finish()
            return
        }
        val qsTileCpt = intent?.extraCptName
        if (qsTileCpt != null && intent.data == null) {
            val serviceInfo =
                app.packageManager.getServiceInfo(qsTileCpt, PackageManager.GET_META_DATA)
            val uriValue = serviceInfo.metaData.getString("QS_TILE_URI")
            if (uriValue != null) {
                intent.data = uriValue.toUri()
            }
        }
        navToMainActivity()
    }
}