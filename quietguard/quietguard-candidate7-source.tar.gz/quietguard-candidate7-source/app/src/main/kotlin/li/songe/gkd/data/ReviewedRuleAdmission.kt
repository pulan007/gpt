// Private-fork addition, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.data

import kotlinx.serialization.json.Json

/**
 * Canonical digest input: the complete concrete RawAppRule and RawAppGroup serializers,
 * UTF-8, defaults and nulls included, compact JSON. Group content includes every sibling
 * rule and inherited field. Do not hash cacheStr/cacheJsonObject, which can become stale.
 */
internal object ReviewedRuleContent {
    private val canonicalJson = Json {
        encodeDefaults = true
        explicitNulls = true
        prettyPrint = false
    }

    fun candidate(rule: RawSubscription.RawRuleProps, group: ResolvedGroup): ReviewedRuleCandidate? {
        val appGroup = group as? ResolvedAppGroup ?: return null
        val appRule = rule as? RawSubscription.RawAppRule ?: return null
        val rawGroup = appGroup.group
        // Require unique, actual membership; detached rules or duplicate keys cannot borrow trust.
        if (rawGroup.rules.count { it === appRule } != 1 ||
            rawGroup.rules.count { it.key == appRule.key } != 1 ||
            appGroup.app.groups.count { it === rawGroup } != 1 ||
            appGroup.app.groups.count { it.key == rawGroup.key } != 1
        ) return null
        return ReviewedRuleCandidate(
            packageName = appGroup.app.id,
            isGlobal = false,
            groupKey = rawGroup.key,
            ruleKey = appRule.key,
            activityNames = appRule.activityIds ?: rawGroup.activityIds ?: emptyList(),
            action = appRule.action,
            hasPosition = appRule.position != null,
            hasSwipe = appRule.swipeArg != null,
            matches = appRule.matches ?: emptyList(),
            anyMatches = appRule.anyMatches ?: emptyList(),
            excludeMatches = appRule.excludeMatches ?: emptyList(),
            excludeAllMatches = appRule.excludeAllMatches ?: emptyList(),
            // Cross-group/count/cooldown and predecessor references are not independently reviewed.
            hasExternalRuleDependencies = !rawGroup.scopeKeys.isNullOrEmpty() ||
                !appRule.preKeys.isNullOrEmpty() || appRule.actionCdKey != null ||
                rawGroup.actionCdKey != null || appRule.actionMaximumKey != null ||
                rawGroup.actionMaximumKey != null,
            serializedRule = canonicalJson.encodeToString(RawSubscription.RawAppRule.serializer(), appRule),
            serializedGroup = canonicalJson.encodeToString(RawSubscription.RawAppGroup.serializer(), rawGroup),
        )
    }
}

/** Cheap empty-catalog/package prefilter, followed by fresh content verification when supported. */
internal fun ResolvedRule.reviewedEntry(): ReviewedRuleEntry? {
    if (ReviewedRuleCatalog.isEmpty || !ReviewedRuleCatalog.supportsPackage(g.appId ?: return null)) {
        return null
    }
    return runCatching {
        ReviewedRuleContent.candidate(rule, g)?.let(ReviewedRuleCatalog::admit)
    }.getOrNull()
}
