package li.songe.gkd

// Private derivative, 2026-10-07. GPL-3.0; see LICENSE.
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.update
import li.songe.gkd.store.storeFlow

/** Synchronous invalidation: a quick OFF -> ON can never revive an older work ticket. */
object PrivateAutomationControl {
    private val revision = AtomicLong(1)
    fun epoch(): Long = revision.get()
    fun invalidate() { revision.incrementAndGet() }

    @Synchronized
    fun setMasterEnabled(enabled: Boolean) {
        invalidate()
        storeFlow.update { it.copy(enableMatch = enabled) }
    }
}
