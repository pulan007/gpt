// Private offline-profile modifications, 2026-10-07; GKD GPL-3.0, see LICENSE.
package li.songe.gkd

import android.app.Activity
import android.os.Bundle

class OpenFileActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!PrivateCapabilities.EXTERNAL_IMPORTS) {
            li.songe.gkd.util.toast("私有离线版已禁用：外部导入与链接")
            finish()
            return
        }
        navToMainActivity()
    }
}