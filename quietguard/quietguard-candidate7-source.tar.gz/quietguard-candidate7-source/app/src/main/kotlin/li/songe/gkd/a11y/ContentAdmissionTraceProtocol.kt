/* TEST-fixture CONTENT admission diagnostics, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

/** Fixed reason codes; no package, class, UI text, node, or event is retained. */
internal enum class ContentAdmissionReason(val code: Long) {
    CURRENT(0), CREATED(1), PROMOTED(2),
    STATE_REPLACED(10), STATE_REJECTED(11), MALFORMED_STATE(12), OLD_STATE(13),
    RECONNECTED(14), SCREEN_ACTIVATED(15), TOP_ACTIVITY_CHANGED(16),
    CONTENT_INELIGIBLE(17), CONTENT_PACKAGE_CHANGED(18), CONTENT_WINDOW_CHANGED(19),
    CANDIDATE_CHANGED(20), EPOCH_CHANGED(21), GENERATION_CHANGED(22), EXPIRED(23),
    ROOT_IDENTITY_CHANGED(24), CLEARED(25), SERVICE_INACTIVE(26), MATCH_DISABLED(27),
    SCREEN_INACTIVE(28), CONSENT_DISABLED(29), NOT_PROMOTED(30), ALREADY_CLAIMED(31),
}

/** Entry/rejection milestones only, never individual node or repeated guard checks. */
internal enum class ContentQueryStage(val code: Long) {
    CONSUME_REJECTED(1), IDENTITY_REJECTED(2), PROMOTION_REJECTED(3),
    BEFORE_QUERY_REJECTED(4), ACTIVITY_RULE_REJECTED(5), REQUESTED(6),
    REQUEST_CONTROL_REJECTED(7), NO_REVIEWED_RULE(8), FOLLOW_UP_CLOSED(9),
    SERVICE_START_DEFERRED(10), NO_ADMITTED_CANDIDATE(11), ADMISSION_REJECTED(12),
    OBSERVED_TIME_REJECTED(13), CLAIM_REJECTED(14), ENQUEUED(15), WORKER_ENTERED(16),
    WORKER_CONTROL_REJECTED(17), QUERY_BUDGET_REJECTED(18),
    PHYSICAL_BUSY(19), OWNED_QUERY_ENTERED(20), OWNED_RULE_OR_CONTEXT_REJECTED(21),
    EVENTS_MISSING(22), MATCH_SKIPPED(23), GATE_ENTERED(24), WORKER_AGE_REJECTED(25),
}

internal inline fun contentAdmissionTrace(reason: ContentAdmissionReason, id: Long, observedAt: Long) {
    if (FixtureAdmissionTrace.ENABLED)
        FixtureAdmissionTrace.record(AdmissionTracePoint.CONTENT_ADMISSION, id, reason.code, observedAt)
}

internal inline fun contentQueryTrace(stage: ContentQueryStage, id: Long,
    reason: ContentAdmissionReason = ContentAdmissionReason.CURRENT) {
    if (FixtureAdmissionTrace.ENABLED)
        FixtureAdmissionTrace.record(AdmissionTracePoint.CONTENT_QUERY, id, stage.code, reason.code)
}
