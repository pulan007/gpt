// Private-fork addition, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.a11y

import android.content.pm.PackageManager
import android.graphics.Rect
import android.os.Build
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.util.Collections
import java.util.IdentityHashMap
import li.songe.gkd.a11y.GateRejectReason as Reject
import li.songe.gkd.a11y.GateTracePhase as Phase
import li.songe.gkd.data.PrivateAppConsent
import li.songe.gkd.data.ReviewedAppIdentity
import li.songe.gkd.data.ReviewedRuleEntry
import li.songe.gkd.data.ReviewedRulePolicy

/** No node is exposed. Only the synchronous, creating thread can consume this once. */
internal sealed class ReviewedExecutionProof {
    internal abstract fun click(entry: ReviewedRuleEntry): Boolean
}

private class ScopedExecutionProof(
    private val entry: ReviewedRuleEntry,
    private val traceId: Long,
    private var click: (() -> Boolean)?,
) : ReviewedExecutionProof() {
    private val thread = Thread.currentThread()
    var accepted = false
        private set

    override fun click(entry: ReviewedRuleEntry): Boolean {
        if (gateTraceTrue(Thread.currentThread() !== thread,
                Reject.PROOF_WRONG_THREAD, Phase.PROOF_ENTRY, traceId)) return false
        val action = gateTraceNull(click, Reject.PROOF_CONSUMED_OR_CLOSED, Phase.PROOF_ENTRY, traceId)
            ?: return false
        click = null // Consume before validation/IPC, including failed or throwing dispatches.
        if (gateTraceTrue(entry !== this.entry,
                Reject.PROOF_WRONG_ENTRY, Phase.PROOF_ENTRY, traceId)) return false
        accepted = action()
        return accepted
    }

    fun close() { click = null }
}

/** Only immutable identity metadata survives an attempt; never nodes or screen content. */
internal data class ReviewedDispatchKey(
    val packageName: String,
    val versionCode: Long,
    val currentSignerSha256: Set<String>,
    val activityName: String,
    val windowId: Int,
    val targetId: String,
)

/**
 * Process-lifetime suppression, shared across service restarts/generations. No LRU eviction
 * or lifecycle reset can re-enable a spent key. On capacity exhaustion new dispatches fail
 * closed. Reserve before IPC: a false/throwing result is also not automatically retried.
 * A reviewed entry therefore permits at most one attempt for its app/window/activity/ID
 * for this process lifetime, even if a genuinely new ad later reuses that same window.
 * There is deliberately no inferred screen-change rearm.
 */
internal enum class ReviewedDispatchReservation { RESERVED, ALREADY_ATTEMPTED, CAPACITY_REACHED }

internal class ReviewedDispatchLedger(private val capacity: Int = 256) {
    private val spent = HashSet<ReviewedDispatchKey>()
    @Synchronized fun reserve(key: ReviewedDispatchKey): ReviewedDispatchReservation {
        if (key in spent) return ReviewedDispatchReservation.ALREADY_ATTEMPTED
        if (spent.size >= capacity) return ReviewedDispatchReservation.CAPACITY_REACHED
        spent += key.copy(currentSignerSha256 = key.currentSignerSha256.toSet())
        return ReviewedDispatchReservation.RESERVED
    }
}

/** Reason only, containing no node, app identity or UI content. */
internal enum class ReviewedExecutionOutcome {
    NOT_VERIFIED, ACCEPTED, ACTION_REJECTED, ACTION_UNCERTAIN, ALREADY_ATTEMPTED, CAPACITY_REACHED,
}

private val processDispatchLedger = ReviewedDispatchLedger()

/**
 * Caller MUST hold the process-wide physical read/action lease for this entire call.
 * Callbacks are synchronous. Window metadata must come from getWindows(), whose API
 * contract is the default display; no other-app root is requested. Platform IPC cannot be
 * interrupted by these limits: late/partial evidence is rejected after the call returns.
 * This narrows, but cannot make atomic, the race between a screen read and ACTION_CLICK.
 */
internal class ReviewedExecutionGate(
    private val now: () -> Long = SystemClock::elapsedRealtime,
    private val ledger: ReviewedDispatchLedger = processDispatchLedger,
) {
    @Volatile var lastOutcome = ReviewedExecutionOutcome.NOT_VERIFIED
        private set

    companion object {
        val process = ReviewedExecutionGate()
        const val MAX_NODES = 128
        const val MAX_DEPTH = 12
        const val MAX_SCAN_MS = 250L
        const val MAX_SNAPSHOT_AGE_MS = 500L
        const val MAX_ACTION_AGE_MS = 1_500L
        private const val MAX_WINDOWS = 16
    }

    fun execute(
        entry: ReviewedRuleEntry,
        packageManager: PackageManager,
        activityName: String?,
        observedAt: Long,
        freshRoot: () -> AccessibilityNodeInfo?,
        freshDefaultWindows: () -> List<AccessibilityWindowInfo>?,
        queryFresh: (AccessibilityNodeInfo, () -> Unit, (AccessibilityNodeInfo) -> Unit) -> AccessibilityNodeInfo?,
        guard: () -> Boolean,
        traceId: Long = 0,
        guardFailure: GuardFailureDiagnostic? = null,
        dispatch: (ReviewedExecutionProof) -> Boolean,
    ): Boolean {
        lastOutcome = ReviewedExecutionOutcome.NOT_VERIFIED
        val nodes = Collections.newSetFromMap(IdentityHashMap<AccessibilityNodeInfo, Boolean>())
        fun own(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? = node?.also { nodes += it }
        var proof: ScopedExecutionProof? = null
        var phase = Phase.ENTRY
        gateTracePhase(phase, traceId)
        try {
            if (!gateTraceFalse(ReviewedRulePolicy.isComplete(entry), Reject.RULE_INCOMPLETE, phase, traceId))
                return false
            // Keep this predicate direct so Kotlin retains the original non-null smart cast.
            if (activityName != entry.activityName)
                return gateTraceFalse(false, Reject.ACTIVITY_MISMATCH, phase, traceId)
            if (!gateTraceFalse(PrivateAppConsent.isEnabled(entry), Reject.CONSENT_DISABLED, phase, traceId) ||
                !gateTraceFalse(fresh(observedAt, MAX_ACTION_AGE_MS), Reject.ACTION_AGE, phase, traceId) ||
                !gateTraceGuard(guard(), phase, traceId, guardFailure)
            ) return false
            val ids = exactIds(entry, traceId, phase) ?: return false
            phase = Phase.IDENTITY_INITIAL
            if (!matchesInstalledIdentity(entry, packageManager, activityName, traceId, phase)) return false
            phase = Phase.POST_IDENTITY
            if (!gateTraceFalse(fresh(observedAt, MAX_ACTION_AGE_MS), Reject.ACTION_AGE, phase, traceId) ||
                !gateTraceGuard(guard(), phase, traceId, guardFailure)) return false
            val startedAt = now()
            phase = Phase.ROOT_INITIAL
            val root = gateTraceNull(own(freshRoot()), Reject.ROOT_NULL, phase, traceId) ?: return false
            if (!gateTraceFalse(root.refresh(), Reject.ROOT_REFRESH, phase, traceId) ||
                gateTraceTrue(own(root.parent) != null, Reject.ROOT_HAS_PARENT, phase, traceId)) return false
            phase = Phase.WINDOW_INITIAL
            val window = readWindow(root.windowId, freshDefaultWindows, traceId, phase) ?: return false
            phase = Phase.POST_WINDOW
            if (!gateTraceFalse(fresh(startedAt, MAX_SCAN_MS), Reject.SCAN_AGE, phase, traceId)) return false
            phase = Phase.CAPTURE_INITIAL
            val snapshot = capture(root, entry, ids, window, startedAt, ::own, traceId, phase) ?: return false
            phase = Phase.POST_CAPTURE
            gateTracePhase(phase, traceId)
            if (!gateTraceFalse(fresh(observedAt, MAX_ACTION_AGE_MS), Reject.ACTION_AGE, phase, traceId) ||
                !gateTraceGuard(guard(), phase, traceId, guardFailure)) return false
            // Engine supplies a fresh, bounded full-rule query. Cached event targets are
            // never accepted; independent scan binds the result to the exact compiled ID.
            val queryStartedAt = now()
            phase = Phase.QUERY_INITIAL
            val selected = gateTraceNull(own(queryFresh(root, queryBudget(queryStartedAt, traceId, phase)) { own(it) }),
                Reject.SELECTOR_NULL, phase, traceId) ?: return false
            phase = Phase.POST_QUERY
            if (!gateTraceFalse(fresh(queryStartedAt, MAX_SCAN_MS), Reject.SELECTOR_TIME_BUDGET, phase, traceId) ||
                gateTraceTrue(selected != snapshot.target.node, Reject.SELECTOR_TARGET_MISMATCH, phase, traceId) ||
                !gateTraceFalse(fresh(startedAt, MAX_SNAPSHOT_AGE_MS), Reject.SNAPSHOT_AGE, phase, traceId)
            ) return false
            val key = ReviewedDispatchKey(entry.packageName, entry.versionCode,
                entry.currentSignerSha256, entry.activityName, window.id, ids.target)
            proof = ScopedExecutionProof(entry, traceId) {
                phase = Phase.PROOF_ENTRY
                gateTracePhase(phase, traceId)
                if (!gateTraceFalse(fresh(startedAt, MAX_SNAPSHOT_AGE_MS), Reject.SNAPSHOT_AGE, phase, traceId) ||
                    !gateTraceFalse(fresh(observedAt, MAX_ACTION_AGE_MS), Reject.ACTION_AGE, phase, traceId) ||
                    !gateTraceFalse(PrivateAppConsent.isEnabled(entry), Reject.CONSENT_DISABLED, phase, traceId) ||
                    !gateTraceGuard(guard(), phase, traceId, guardFailure)
                ) return@ScopedExecutionProof false
                // Reacquire and completely scan once more at consumption. Unknown children,
                // a new sensitive context, changed IDs or changed parentage all fail closed.
                val finalStartedAt = now()
                phase = Phase.ROOT_FINAL
                val finalRoot = gateTraceNull(own(freshRoot()), Reject.ROOT_NULL, phase, traceId)
                    ?: return@ScopedExecutionProof false
                if (gateTraceTrue(finalRoot != root, Reject.FINAL_ROOT_CHANGED, phase, traceId) ||
                    !gateTraceFalse(finalRoot.refresh(), Reject.ROOT_REFRESH, phase, traceId) ||
                    gateTraceTrue(own(finalRoot.parent) != null, Reject.ROOT_HAS_PARENT, phase, traceId))
                    return@ScopedExecutionProof false
                phase = Phase.WINDOW_FINAL
                val finalWindow = readWindow(finalRoot.windowId, freshDefaultWindows, traceId, phase)
                    ?: return@ScopedExecutionProof false
                if (gateTraceTrue(finalWindow != window, Reject.FINAL_WINDOW_CHANGED, phase, traceId))
                    return@ScopedExecutionProof false
                phase = Phase.CAPTURE_FINAL
                val finalSnapshot = capture(finalRoot, entry, ids, finalWindow, finalStartedAt, ::own, traceId, phase)
                    ?: return@ScopedExecutionProof false
                if (gateTraceTrue(finalSnapshot.all != snapshot.all, Reject.FINAL_SNAPSHOT_CHANGED, phase, traceId))
                    return@ScopedExecutionProof false
                gateTracePhase(phase, traceId)
                val finalQueryAt = now()
                phase = Phase.QUERY_FINAL
                if (gateTraceTrue(own(queryFresh(finalRoot, queryBudget(finalQueryAt, traceId, phase)) { own(it) }) !=
                        finalSnapshot.target.node, Reject.SELECTOR_TARGET_MISMATCH, phase, traceId) ||
                    !gateTraceFalse(fresh(finalQueryAt, MAX_SCAN_MS), Reject.SELECTOR_TIME_BUDGET, phase, traceId))
                    return@ScopedExecutionProof false
                // Identity/window IPC must precede the last ancestor/context refreshes:
                // changes during that IPC cannot reuse earlier ancestor eligibility.
                phase = Phase.WINDOW_RECHECK
                if (gateTraceTrue(readWindow(window.id, freshDefaultWindows, traceId, phase) != window,
                        Reject.FINAL_WINDOW_CHANGED, phase, traceId)) return@ScopedExecutionProof false
                phase = Phase.IDENTITY_FINAL
                if (!matchesInstalledIdentity(entry, packageManager, activityName, traceId, phase))
                    return@ScopedExecutionProof false
                // Refresh target and required ancestors/context after the selector callback.
                val refreshStartedAt = now()
                phase = Phase.CRITICAL_REFRESH
                for (fact in finalSnapshot.critical) {
                    if (!gateTraceFalse(fresh(refreshStartedAt, MAX_SCAN_MS), Reject.SCAN_AGE, phase, traceId) ||
                        !gateTraceFalse(fact.node.refresh(), Reject.CRITICAL_REFRESH, phase, traceId) ||
                        gateTraceTrue(own(fact.node.parent) != fact.parent?.node,
                            Reject.CRITICAL_PARENT_CHANGED, phase, traceId) ||
                        gateTraceTrue(readFact(fact.node, entry.packageName, window.id, fact.parent, traceId, phase) != fact,
                            Reject.CRITICAL_FACT_CHANGED, phase, traceId)
                    ) return@ScopedExecutionProof false
                }
                phase = Phase.TARGET_REFRESH
                if (!gateTraceFalse(fresh(refreshStartedAt, MAX_SCAN_MS), Reject.SCAN_AGE, phase, traceId) ||
                    !gateTraceFalse(finalSnapshot.target.node.refresh(), Reject.TARGET_REFRESH, phase, traceId) ||
                    gateTraceTrue(own(finalSnapshot.target.node.parent) != finalSnapshot.target.parent?.node,
                        Reject.TARGET_PARENT_CHANGED, phase, traceId) ||
                    gateTraceTrue(readFact(finalSnapshot.target.node, entry.packageName, window.id,
                        finalSnapshot.target.parent, traceId, phase) != finalSnapshot.target,
                        Reject.TARGET_FACT_CHANGED, phase, traceId)
                ) return@ScopedExecutionProof false
                phase = Phase.PRE_RESERVE
                if (!gateTraceFalse(fresh(startedAt, MAX_SNAPSHOT_AGE_MS), Reject.SNAPSHOT_AGE, phase, traceId) ||
                    !gateTraceFalse(fresh(observedAt, MAX_ACTION_AGE_MS), Reject.ACTION_AGE, phase, traceId) ||
                    !gateTraceFalse(PrivateAppConsent.isEnabled(entry), Reject.CONSENT_DISABLED, phase, traceId) ||
                    !gateTraceGuard(guard(), phase, traceId, guardFailure)
                ) return@ScopedExecutionProof false
                phase = Phase.RESERVE
                when (ledger.reserve(key)) {
                    ReviewedDispatchReservation.ALREADY_ATTEMPTED -> {
                        gateTraceTrue(true, Reject.ALREADY_ATTEMPTED, phase, traceId)
                        lastOutcome = ReviewedExecutionOutcome.ALREADY_ATTEMPTED
                        return@ScopedExecutionProof false
                    }
                    ReviewedDispatchReservation.CAPACITY_REACHED -> {
                        gateTraceTrue(true, Reject.LEDGER_CAPACITY, phase, traceId)
                        lastOutcome = ReviewedExecutionOutcome.CAPACITY_REACHED
                        return@ScopedExecutionProof false
                    }
                    ReviewedDispatchReservation.RESERVED -> Unit
                }
                // This is the last operation before click; generation, pause, foreground,
                // interactivity and per-app consent must be checked by the caller's guard.
                phase = Phase.PRE_ACTION
                gateTracePhase(phase, traceId)
                if (!gateTraceFalse(fresh(startedAt, MAX_SNAPSHOT_AGE_MS), Reject.SNAPSHOT_AGE, phase, traceId) ||
                    !gateTraceFalse(fresh(observedAt, MAX_ACTION_AGE_MS), Reject.ACTION_AGE, phase, traceId) ||
                    !gateTraceFalse(PrivateAppConsent.isEnabled(entry), Reject.CONSENT_DISABLED, phase, traceId) ||
                    !gateTraceGuard(guard(), phase, traceId, guardFailure)
                ) return@ScopedExecutionProof false
                phase = Phase.ACTION
                try {
                    finalSnapshot.target.node.performAction(AccessibilityNodeInfo.ACTION_CLICK).also {
                        gateTraceFalse(it, Reject.ACTION_FALSE, phase, traceId)
                        lastOutcome = if (it) ReviewedExecutionOutcome.ACCEPTED
                            else ReviewedExecutionOutcome.ACTION_REJECTED
                    }
                } catch (_: Exception) {
                    gateTraceTrue(true, Reject.ACTION_EXCEPTION, phase, traceId)
                    lastOutcome = ReviewedExecutionOutcome.ACTION_UNCERTAIN
                    false
                }
            }
            dispatch(proof)
            return proof.accepted.also { gateTracePhase(Phase.DISPATCH_RETURN, traceId, if (it) 1 else 0) }
        } catch (_: Exception) {
            gateTraceTrue(true, Reject.EXCEPTION, phase, traceId)
            return proof?.accepted == true
        } finally {
            proof?.close() // Drop all node-capturing closures even if callback retained proof.
            @Suppress("DEPRECATION")
            nodes.forEach { runCatching { it.recycle() } }
        }
    }

    private fun fresh(start: Long, limit: Long): Boolean = now() - start in 0..limit

    private fun queryBudget(startedAt: Long, traceId: Long, phase: Phase): () -> Unit {
        var remaining = MAX_NODES
        return {
            if (gateTraceTrue(remaining-- <= 0, Reject.QUERY_BUDGET_COUNT_EXHAUSTED, phase, traceId,
                    remaining.toLong(), MAX_NODES.toLong()) ||
                !gateTraceFalse(fresh(startedAt, MAX_SCAN_MS), Reject.QUERY_BUDGET_TIME_EXHAUSTED, phase, traceId,
                    remaining.toLong(), MAX_NODES.toLong()))
                throw IllegalStateException("Reviewed query budget exhausted")
        }
    }

    @Suppress("DEPRECATION")
    private fun matchesInstalledIdentity(
        entry: ReviewedRuleEntry,
        manager: PackageManager,
        activity: String,
        traceId: Long,
        phase: Phase,
    ): Boolean {
        val modern = Build.VERSION.SDK_INT >= 28
        val info = manager.getPackageInfo(entry.packageName,
            if (modern) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES)
        if (gateTraceTrue(info.packageName != entry.packageName, Reject.IDENTITY_PACKAGE, phase, traceId)) return false
        // On API28+ legacy signatures may return old rotation identities: never use them.
        // API26/27 has no signing-certificate rotation; its complete signatures array is
        // the signer set understood by that platform, without lineage matching.
        val signatures = if (modern) info.signingInfo?.apkContentsSigners else info.signatures
        // As above, leave the null predicate direct to retain its existing smart cast.
        if (signatures.isNullOrEmpty())
            return gateTraceFalse(false, Reject.IDENTITY_SIGNERS_MISSING, phase, traceId)
        val digests = signatures.map { signature ->
            val bytes = gateTraceNull(signature?.toByteArray(), Reject.IDENTITY_SIGNER_NULL, phase, traceId)
                ?: return false
            if (gateTraceTrue(bytes.isEmpty(), Reject.IDENTITY_SIGNER_EMPTY, phase, traceId)) return false
            ReviewedRulePolicy.sha256(bytes)
        }.toSet()
        if (gateTraceTrue(digests.size != signatures.size, Reject.IDENTITY_SIGNERS_DUPLICATE, phase, traceId)) return false
        val version = if (modern) info.longVersionCode else info.versionCode.toLong() and 0xffffffffL
        return gateTraceFalse(ReviewedRulePolicy.matchesIdentity(entry,
            ReviewedAppIdentity(info.packageName, version, digests, activity)), Reject.IDENTITY_POLICY, phase, traceId)
    }

    private data class Ids(val target: String, val required: Set<String>, val forbidden: Set<String>)
    private fun exactIds(entry: ReviewedRuleEntry, traceId: Long, phase: Phase): Ids? {
        fun id(selector: String) = selector.substringAfter("[id=").substring(1).substringBefore("'")
            .substringBefore("\"")
        val target = id(entry.targetSelector)
        val required = entry.requiredContextSelectors.map(::id)
        val forbidden = entry.forbiddenContextSelectors.map(::id)
        val all = listOf(target) + required + forbidden
        if (gateTraceTrue(all.size != all.distinct().size, Reject.IDS_NOT_INDEPENDENT, phase, traceId))
            return null // Independent IDs, not flag variants.
        return Ids(target, required.toSet(), forbidden.toSet())
    }

    private data class WindowFact(val id: Int, val bounds: Rect)
    private fun readWindow(
        windowId: Int,
        freshDefaultWindows: () -> List<AccessibilityWindowInfo>?,
        traceId: Long,
        phase: Phase,
    ): WindowFact? {
        if (gateTraceTrue(windowId < 0, Reject.WINDOW_ID_INVALID, phase, traceId)) return null
        val windows = gateTraceNull(freshDefaultWindows(), Reject.WINDOWS_NULL, phase, traceId) ?: return null
        try {
            if (gateTraceTrue(windows.isEmpty(), Reject.WINDOWS_EMPTY, phase, traceId) ||
                gateTraceTrue(windows.size > MAX_WINDOWS, Reject.WINDOWS_LIMIT, phase, traceId)) return null
            if (gateTraceTrue(windows.count { it.isActive } != 1, Reject.WINDOW_ACTIVE_COUNT, phase, traceId) ||
                gateTraceTrue(windows.count { it.isFocused } != 1, Reject.WINDOW_FOCUSED_COUNT, phase, traceId)) return null
            val window = gateTraceNull(windows.singleOrNull { it.id == windowId },
                Reject.WINDOW_ID_NOT_UNIQUE, phase, traceId) ?: return null
            if (!gateTraceFalse(window.isActive, Reject.WINDOW_INACTIVE, phase, traceId) ||
                !gateTraceFalse(window.isFocused, Reject.WINDOW_UNFOCUSED, phase, traceId) ||
                gateTraceTrue(window.type != AccessibilityWindowInfo.TYPE_APPLICATION, Reject.WINDOW_TYPE, phase, traceId) ||
                (Build.VERSION.SDK_INT >= 30 &&
                    gateTraceTrue(window.displayId != Display.DEFAULT_DISPLAY, Reject.WINDOW_DISPLAY, phase, traceId))
            ) return null
            val bounds = Rect().also(window::getBoundsInScreen)
            if (gateTraceTrue(bounds.isEmpty, Reject.WINDOW_EMPTY_BOUNDS, phase, traceId)) return null
            return WindowFact(window.id, bounds)
        } finally {
            @Suppress("DEPRECATION")
            windows.forEach { runCatching { it.recycle() } }
        }
    }

    private data class NodeFact(
        val node: AccessibilityNodeInfo,
        val parent: NodeFact?,
        val id: String?,
        val bounds: Rect,
        val visible: Boolean,
        val enabled: Boolean,
        val clickable: Boolean,
        val childCount: Int,
    ) {
        // Keep the original recursive short circuit: a failing ancestor must not read
        // descendant containment, and no fact is reread merely to explain a failure.
        fun validChain(traceId: Long, phase: Phase): Boolean =
            gateTraceFalse(visible, Reject.CHAIN_INVISIBLE, phase, traceId) &&
            gateTraceFalse(enabled, Reject.CHAIN_DISABLED, phase, traceId) &&
            !gateTraceTrue(bounds.isEmpty, Reject.CHAIN_EMPTY_BOUNDS, phase, traceId) &&
            (parent == null || (parent.validChain(traceId, phase) &&
                gateTraceFalse(parent.bounds.contains(bounds), Reject.CHAIN_OUTSIDE_PARENT, phase, traceId)))
    }

    private fun readFact(
        node: AccessibilityNodeInfo,
        packageName: String,
        windowId: Int,
        parent: NodeFact?,
        traceId: Long,
        phase: Phase,
    ): NodeFact? {
        if (gateTraceTrue(node.packageName?.toString() != packageName, Reject.NODE_PACKAGE, phase, traceId) ||
            gateTraceTrue(node.windowId != windowId, Reject.NODE_WINDOW, phase, traceId) ||
            gateTraceTrue(node.className.isNullOrEmpty(), Reject.NODE_CLASS_EMPTY, phase, traceId) ||
            gateTraceTrue(node.isPassword, Reject.NODE_PASSWORD, phase, traceId) ||
            gateTraceTrue(node.isEditable, Reject.NODE_EDITABLE, phase, traceId) ||
            (Build.VERSION.SDK_INT >= 34 &&
                gateTraceTrue(node.isAccessibilityDataSensitive, Reject.NODE_DATA_SENSITIVE, phase, traceId))
        ) return null
        val children = node.childCount
        if (gateTraceTrue(children < 0, Reject.NODE_CHILD_COUNT_NEGATIVE, phase, traceId) ||
            gateTraceTrue(children > MAX_NODES, Reject.NODE_CHILD_COUNT_LIMIT, phase, traceId)) return null
        return NodeFact(node, parent, node.viewIdResourceName,
            Rect().also(node::getBoundsInScreen), node.isVisibleToUser,
            node.isEnabled, node.isClickable, children)
    }

    private data class Snapshot(
        val target: NodeFact, val critical: List<NodeFact>, val all: List<NodeFact>,
    )
    private fun capture(
        root: AccessibilityNodeInfo,
        entry: ReviewedRuleEntry,
        ids: Ids,
        window: WindowFact,
        startedAt: Long,
        own: (AccessibilityNodeInfo?) -> AccessibilityNodeInfo?,
        traceId: Long,
        phase: Phase,
    ): Snapshot? {
        data class Pending(val node: AccessibilityNodeInfo, val parent: NodeFact?, val depth: Int)
        val pending = ArrayDeque<Pending>()
        pending += Pending(root, null, 0)
        val visited = HashSet<AccessibilityNodeInfo>()
        val matches = HashMap<String, NodeFact>()
        val all = ArrayList<NodeFact>()
        var discovered = 1
        while (pending.isNotEmpty()) {
            if (!gateTraceFalse(fresh(startedAt, MAX_SCAN_MS), Reject.SCAN_AGE, phase, traceId)) return null
            val item = pending.removeFirst()
            if (gateTraceTrue(item.depth > MAX_DEPTH, Reject.TREE_DEPTH, phase, traceId) ||
                !gateTraceFalse(visited.add(item.node), Reject.TREE_REPEATED_NODE, phase, traceId) ||
                !gateTraceFalse(item.node.refresh(), Reject.NODE_REFRESH, phase, traceId) ||
                gateTraceTrue(own(item.node.parent) != item.parent?.node, Reject.NODE_PARENT, phase, traceId)) return null
            val fact = readFact(item.node, entry.packageName, window.id, item.parent, traceId, phase) ?: return null
            all += fact
            if (item.parent == null && (!fact.validChain(traceId, phase) ||
                    !gateTraceFalse(window.bounds.contains(fact.bounds), Reject.ROOT_OUTSIDE_WINDOW, phase, traceId))) return null
            if (gateTraceTrue(fact.id in ids.forbidden, Reject.FORBIDDEN_ID, phase, traceId)) return null
            if (fact.id == ids.target || fact.id in ids.required) {
                if (!fact.validChain(traceId, phase) ||
                    gateTraceTrue(matches.put(fact.id!!, fact) != null,
                        Reject.DUPLICATE_REQUIRED_OR_TARGET_ID, phase, traceId)) return null
                if (fact.id == ids.target && !gateTraceFalse(fact.clickable, Reject.TARGET_NOT_CLICKABLE, phase, traceId)) return null
            }
            if (gateTraceTrue(discovered + fact.childCount > MAX_NODES, Reject.TREE_NODE_LIMIT, phase, traceId) ||
                (item.depth == MAX_DEPTH &&
                    gateTraceTrue(fact.childCount != 0, Reject.TREE_DEPTH_TRUNCATION, phase, traceId))
            ) return null
            discovered += fact.childCount
            repeat(fact.childCount) { index ->
                if (!gateTraceFalse(fresh(startedAt, MAX_SCAN_MS), Reject.SCAN_AGE, phase, traceId)) return null
                val child = gateTraceNull(own(item.node.getChild(index)), Reject.CHILD_NULL, phase, traceId) ?: return null
                pending += Pending(child, fact, item.depth + 1)
            }
        }
        if (!gateTraceFalse(fresh(startedAt, MAX_SCAN_MS), Reject.SCAN_AGE, phase, traceId) ||
            !gateTraceFalse(matches.keys.containsAll(ids.required), Reject.REQUIRED_ID_MISSING, phase, traceId)) return null
        val target = gateTraceNull(matches[ids.target], Reject.TARGET_ID_MISSING, phase, traceId) ?: return null
        val critical = LinkedHashSet<NodeFact>()
        matches.values.forEach { fact ->
            var next: NodeFact? = fact
            while (next != null) {
                critical += next
                next = next.parent
            }
        }
        return Snapshot(target, critical.toList(), all)
    }
}
