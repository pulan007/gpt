/* TEST-fixture admission diagnostics, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

/** Fixed codes only. No screen text, package/class strings, nodes, or events. */
internal enum class AdmissionTracePoint(val code: Long) {
    ARRIVAL(1), CONSUME_START(2), PRE_EFFECTIVE_REJECT(3), PRE_EPOCH(4),
    PRE_EPOCH_REJECT(5), PRE_AGE(6), PRE_AGE_REJECT(7), PACKAGE_REJECT(8),
    CONSENT_REJECT(9), SAME_APP(10), IDENTITY_BUDGET_DENIED(11), IDENTITY_BUDGET_ACQUIRED(12),
    GUARD_CAPTURE(13), GUARD_EFFECTIVE_REJECT(14), GUARD_GENERATION_REJECT(15),
    GUARD_EPOCH(16), GUARD_EPOCH_REJECT(17), GUARD_ACTIVITY_REJECT(18), GUARD_STATE_REJECT(19),
    PHYSICAL_BUSY(20), PHYSICAL_ACQUIRED(21), SUBMIT(22), WORKER_START(23),
    PRE_WAITER_REJECT(24), PHYSICAL_PRE_AGE(25), PHYSICAL_PRE_AGE_REJECT(26),
    PHYSICAL_PRE_GUARD_REJECT(27), BLOCK_START(28), BLOCK_RESULT(29), BLOCK_EXCEPTION(30),
    PHYSICAL_RELEASED(31), POST_WAITER_REJECT(32), PHYSICAL_POST_AGE(33),
    PHYSICAL_POST_AGE_REJECT(34), PHYSICAL_POST_GUARD_REJECT(35), WAITER_RESULT(36),
    RESULT_DISCARDED(37), SUBMISSION_EXCEPTION(38), ROOT_START(39), ROOT_RESULT(40),
    ROOT_PACKAGE_RESULT(41), IDENTITY_OUTER_TIMEOUT(42), IDENTITY_RESULT(43),
    IDENTITY_FINAL_GUARD_REJECT(44), IDENTITY_NULL_RETURN(45), POST_EFFECTIVE_REJECT(46),
    POST_EPOCH(47), POST_EPOCH_REJECT(48), POST_STATE_REJECT(49), POST_AGE(50),
    POST_AGE_REJECT(51), EVENT_KIND(52), ACTIVITY_RECOGNIZED(53), ACTIVITY_UPDATED(54),
    FALLBACK_UPDATE(55), FINAL_RULE_COUNT(56), FINAL_APP_MISMATCH(57), FINAL_SKIP_CONSUME(58),
    FINAL_MATCH_DISABLED(59), QUERY_REQUESTED(60), CONSUME_SKIPPED(61), IDENTITY_FINAL_RESULT(62),
    QUERY_REJECT(63), QUERY_PHASE(64), GATE_REJECT(100), GATE_PHASE(101),
    CONTENT_ADMISSION(200), CONTENT_QUERY(201),
}

/** 0: negative, 1: [0,100), 2: [100,500), 3: [500,1000), 4: >=1000 ms. */
internal fun admissionAgeCategory(age: Long): Long = when {
    age < 0 -> 0
    age < 100 -> 1
    age < 500 -> 2
    age < 1_000 -> 3
    else -> 4
}

internal inline fun traceFalse(value: Boolean, point: AdmissionTracePoint, id: Long): Boolean {
    if (FixtureAdmissionTrace.ENABLED && !value) FixtureAdmissionTrace.record(point, id)
    return value
}

internal inline fun traceFlag(value: Boolean, point: AdmissionTracePoint, id: Long): Boolean {
    if (FixtureAdmissionTrace.ENABLED) FixtureAdmissionTrace.record(point, id, if (value) 1 else 0)
    return value
}

internal inline fun traceAge(value: Long, point: AdmissionTracePoint, id: Long): Long {
    if (FixtureAdmissionTrace.ENABLED) FixtureAdmissionTrace.record(point, id, value, admissionAgeCategory(value))
    return value
}

internal inline fun traceEpoch(value: Long, point: AdmissionTracePoint, id: Long, expected: Long): Long {
    if (FixtureAdmissionTrace.ENABLED) FixtureAdmissionTrace.record(point, id, expected, value)
    return value
}
