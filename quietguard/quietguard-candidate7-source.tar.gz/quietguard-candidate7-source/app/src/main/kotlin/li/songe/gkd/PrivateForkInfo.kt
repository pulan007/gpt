package li.songe.gkd

// Private derivative notice, 2026-10-07. GKD source remains GPL-3.0-only.
object PrivateForkInfo {
    const val NAME = "轻停 TEST ONLY·自有模拟测试"
    const val UPSTREAM_VERSION = "GKD 1.12.1"
    const val UPSTREAM_COMMIT = "5a00f844989471458e4cf4601acb3f4710438f9a"
    const val NOTICE = "TEST ONLY：仅自有模拟测试；真实应用0。基于 GKD 的非官方私人修改版，保留原作者署名与 GPL-3.0 许可。此版本由本项目维护，请在当前项目中反馈问题。"
    const val PRIVACY = "本版关闭联网、HTTP 调试、快照、截屏、Shizuku、坐标与手势点击。无障碍系统仍可能向服务提供界面内容；程序不记录或导出页面内容与应用访问历史。设置、规则草稿与累计次数保存在本机。"
    const val SCOPE = "仅测试已有自有 Demo；不支持任何真实广告应用。仅允许已核实的应用版本、签名和界面规则。新增或修改的规则草稿不会直接执行。奖励广告、支付、登录及系统授权保留手动操作。"
}
