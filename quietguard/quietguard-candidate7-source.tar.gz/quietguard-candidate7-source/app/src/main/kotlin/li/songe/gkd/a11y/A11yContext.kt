// Private offline-profile modifications, 2026-10-07; GKD GPL-3.0, see LICENSE.
package li.songe.gkd.a11y

import android.util.Log
import android.util.LruCache
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.atomicfu.atomic
import li.songe.gkd.PrivateCapabilities
import li.songe.gkd.META
import li.songe.gkd.data.ResolvedRule
import li.songe.gkd.shizuku.casted
import li.songe.gkd.util.InterruptRuleMatchException
import li.songe.selector.FastQuery
import li.songe.selector.MatchOption
import li.songe.selector.QueryContext
import li.songe.selector.Selector
import li.songe.selector.Transform
import li.songe.selector.getBooleanInvoke
import li.songe.selector.getCharSequenceAttr
import li.songe.selector.getCharSequenceInvoke
import li.songe.selector.getIntInvoke


private operator fun <K, V> LruCache<K, V>.set(child: K, value: V): V {
    return put(child, value)
}

private fun List<Any>.getInt(i: Int = 0) = get(i) as Int

private const val MAX_CACHE_SIZE = MAX_DESCENDANTS_SIZE

private val AccessibilityNodeInfo?.notExpiredNode: AccessibilityNodeInfo?
    get() {
        if (this != null) {
            val expiryMillis = if (text == null) 2000L else 1000L
            if (isExpired(expiryMillis)) {
                return null
            }
        }
        return this
    }

class A11yContext(
    private val a11yEngine: A11yRuleEngine,
    private val interruptable: Boolean = true,
    private val nodeQueryGuard: (() -> Unit)? = null,
    private val allowFastQuery: Boolean = true,
    private val nodeOwner: ((AccessibilityNodeInfo) -> Unit)? = null,
) {
    private var childCache =
        LruCache<Pair<AccessibilityNodeInfo, Int>, AccessibilityNodeInfo>(MAX_CACHE_SIZE)
    private var indexCache = LruCache<AccessibilityNodeInfo, Int>(MAX_CACHE_SIZE)
    private var parentCache = LruCache<AccessibilityNodeInfo, AccessibilityNodeInfo>(MAX_CACHE_SIZE)
    val rootCache = atomic<AccessibilityNodeInfo?>(null)

    private fun clearChildCache(node: AccessibilityNodeInfo) {
        repeat(node.childCount.coerceAtMost(MAX_CHILD_SIZE)) { i ->
            childCache.remove(node to i)?.let {
                clearChildCache(it)
            }
        }
    }

    fun clearNodeCache(eventNode: AccessibilityNodeInfo? = null) {
        if (rootCache.value?.packageName != topActivityFlow.value.appId) {
            rootCache.value = null
        }
        if (eventNode != null) {
            clearChildCache(eventNode)
            parentCache[eventNode]?.let { p ->
                getPureIndex(eventNode)?.let { i ->
                    childCache[p to i] = eventNode
                }
            }
            if (rootCache.value == eventNode) {
                rootCache.value = eventNode
            } else {
                if (PrivateCapabilities.SENSITIVE_LOGGING && META.debuggable) {
                    Log.d(
                        "cache",
                        "clear node cache ${eventNode.packageName}/${eventNode.className}"
                    )
                }
                return
            }
        }
        if (PrivateCapabilities.SENSITIVE_LOGGING && META.debuggable) {
            val sizeList = listOf(childCache.size(), parentCache.size(), indexCache.size())
            if (sizeList.any { it > 0 }) {
                Log.d("cache", "clear cache -> $sizeList")
            }
        }
        try {
            childCache.evictAll()
            parentCache.evictAll()
            indexCache.evictAll()
        } catch (_: Exception) {
            // https://github.com/gkd-kit/gkd/issues/664
            // 在某些机型上 未知原因 缓存不一致 导致删除失败
            childCache = LruCache(MAX_CACHE_SIZE)
            indexCache = LruCache(MAX_CACHE_SIZE)
            parentCache = LruCache(MAX_CACHE_SIZE)
        }
    }

    private var lastAppChangeTime = appChangeTime
    fun clearOldAppNodeCache(): Boolean {
        if (appChangeTime != lastAppChangeTime) {
            lastAppChangeTime = appChangeTime
            clearNodeCache()
            return true
        }
        return false
    }

    var currentRule: ResolvedRule? = null

    @Volatile
    var interruptKey = 0
    private var interruptInnerKey = 0

    private fun guardInterrupt() {
        a11yEngine.guardNodeQuery()
        nodeQueryGuard?.invoke()
        if (!interruptable) return
        if (interruptInnerKey == interruptKey) return
        interruptInnerKey = interruptKey
        val rule = currentRule ?: return
        if (!activityRuleFlow.value.activePriority) return
        if (!activityRuleFlow.value.currentRules.any { it === rule }) return
        if (rule.isPriority()) return
        if (PrivateCapabilities.SENSITIVE_LOGGING && META.debuggable) {
            Log.d("guardInterrupt", "中断 rule=${rule.statusText()}")
        }
        throw InterruptRuleMatchException()
    }

    private fun getA11Root(): AccessibilityNodeInfo? {
        guardInterrupt()
        // A proof context is confined to the gate-owned root supplied at construction.
        // It must never refill the persistent engine cache or acquire an unrelated root.
        if (nodeOwner != null) return rootCache.value?.also(nodeOwner)
        return a11yEngine.safeActiveWindow
    }

    private fun ownFreshNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? = node?.also {
        if (nodeOwner != null) nodeOwner.invoke(it) else it.setGeneratedTime()
    }

    private fun usableCachedNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? =
        if (nodeOwner != null) node else node.notExpiredNode

    private fun getA11Child(node: AccessibilityNodeInfo, index: Int): AccessibilityNodeInfo? {
        guardInterrupt()
        return ownFreshNode(node.getChild(index))
    }

    private fun getA11Parent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        guardInterrupt()
        return ownFreshNode(node.parent)
    }

    private fun getA11ByText(
        node: AccessibilityNodeInfo,
        value: String
    ): List<AccessibilityNodeInfo> {
        guardInterrupt()
        return node.findAccessibilityNodeInfosByText(value).apply {
            // Register every returned handle before later guard/selector work can throw.
            if (nodeOwner != null) forEach(nodeOwner) else forEach { it.setGeneratedTime() }
        }
    }

    private fun getA11ById(
        node: AccessibilityNodeInfo,
        value: String
    ): List<AccessibilityNodeInfo> {
        guardInterrupt()
        return node.findAccessibilityNodeInfosByViewId(value).apply {
            // Register every returned handle before later guard/selector work can throw.
            if (nodeOwner != null) forEach(nodeOwner) else forEach { it.setGeneratedTime() }
        }
    }

    private fun getFastQueryNodes(
        node: AccessibilityNodeInfo,
        fastQuery: FastQuery
    ): List<AccessibilityNodeInfo> {
        return when (fastQuery) {
            is FastQuery.Id -> getA11ById(node, fastQuery.value)
            is FastQuery.Text -> getA11ByText(node, fastQuery.value)
            is FastQuery.Vid -> getA11ById(node, "${node.packageName}:id/${fastQuery.value}")
        }
    }

    private fun getCacheRoot(node: AccessibilityNodeInfo? = null): AccessibilityNodeInfo? {
        guardInterrupt()
        if (usableCachedNode(rootCache.value) == null) {
            rootCache.value = getA11Root()
        }
        if (node == rootCache.value) return null
        return rootCache.value
    }

    private fun getCacheParent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        guardInterrupt()
        if (getCacheRoot() == node) {
            return null
        }
        usableCachedNode(parentCache[node])?.let { return it }
        return getA11Parent(node).apply {
            if (this != null) {
                parentCache[node] = this
            } else {
                rootCache.value = node
            }
        }
    }

    private fun getCacheChild(node: AccessibilityNodeInfo, index: Int): AccessibilityNodeInfo? {
        guardInterrupt()
        if (index !in 0 until node.childCount) {
            return null
        }
        return usableCachedNode(childCache[node to index]) ?: getA11Child(node, index)?.also { child ->
            indexCache[child] = index
            parentCache[child] = node
            childCache[node to index] = child
        }
    }

    private fun getPureIndex(node: AccessibilityNodeInfo): Int? {
        return indexCache[node]
    }

    private fun getCacheIndex(node: AccessibilityNodeInfo): Int {
        indexCache[node]?.let { return it }
        getCacheChildren(getCacheParent(node)).forEachIndexed { index, child ->
            if (child == node) {
                indexCache[node] = index
                return index
            }
        }
        return 0
    }

    /**
     * 在无缓存时, 此方法小概率造成无限节点片段,底层原因未知
     *
     * https://github.com/gkd-kit/gkd/issues/28
     */
    private fun getCacheDepth(node: AccessibilityNodeInfo): Int {
        var p: AccessibilityNodeInfo = node
        var depth = 0
        while (true) {
            val p2 = getCacheParent(p)
            if (p2 != null) {
                p = p2
                depth++
            } else {
                break
            }
        }
        return depth
    }

    private fun getCacheChildren(node: AccessibilityNodeInfo?): Sequence<AccessibilityNodeInfo> {
        if (node == null) return emptySequence()
        return sequence {
            repeat(node.childCount.coerceAtMost(MAX_CHILD_SIZE)) { index ->
                val child = getCacheChild(node, index) ?: return@sequence
                yield(child)
            }
        }
    }

    private var tempVid: CharSequence? = null
    private var tempVidNode: AccessibilityNodeInfo? = null
    private fun getTempVid(n: AccessibilityNodeInfo): CharSequence? {
        if (n !== tempVidNode) {
            tempVid = n.getVid()
            tempVidNode = n
        }
        return tempVid
    }

    private fun getCacheAttr(node: AccessibilityNodeInfo, name: String): Any? = when (name) {
        "id" -> node.viewIdResourceName
        "vid" -> getTempVid(node)

        "name" -> node.className
        "text" -> node.text
        "desc" -> node.contentDescription

        "clickable" -> node.isClickable
        "focusable" -> node.isFocusable
        "checkable" -> node.isCheckable
        "checked" -> node.compatChecked

        "editable" -> node.isEditable
        "longClickable" -> node.isLongClickable
        "visibleToUser" -> node.isVisibleToUser

        "left" -> node.casted.boundsInScreen.left
        "top" -> node.casted.boundsInScreen.top
        "right" -> node.casted.boundsInScreen.right
        "bottom" -> node.casted.boundsInScreen.bottom

        "width" -> node.casted.boundsInScreen.width()
        "height" -> node.casted.boundsInScreen.height()

        "index" -> getCacheIndex(node)
        "depth" -> getCacheDepth(node)
        "childCount" -> node.childCount

        "parent" -> getCacheParent(node)

        else -> null
    }

    private val transform = Transform(
        getAttr = { target, name ->
            when (target) {
                is QueryContext<*> -> when (name) {
                    "prev" -> target.prev
                    "current" -> target.current
                    else -> getCacheAttr(target.current as AccessibilityNodeInfo, name)
                }

                is AccessibilityNodeInfo -> getCacheAttr(target, name)
                is CharSequence -> getCharSequenceAttr(target, name)
                else -> null
            }
        },
        getInvoke = { target, name, args ->
            when (target) {
                is AccessibilityNodeInfo -> when (name) {
                    "getChild" -> {
                        getCacheChild(target, args.getInt())
                    }

                    else -> null
                }

                is QueryContext<*> -> when (name) {
                    "getPrev" -> {
                        args.getInt().let { target.getPrev(it) }
                    }

                    "getChild" -> {
                        getCacheChild(target.current as AccessibilityNodeInfo, args.getInt())
                    }

                    else -> null
                }

                is CharSequence -> getCharSequenceInvoke(target, name, args)
                is Int -> getIntInvoke(target, name, args)
                is Boolean -> getBooleanInvoke(target, name, args)

                else -> null
            }
        },
        getName = { node -> node.className },
        getChildren = ::getCacheChildren,
        getParent = ::getCacheParent,
        getRoot = ::getCacheRoot,
        getDescendants = { node ->
            sequence {
                val stack = getCacheChildren(node).toMutableList()
                if (stack.isEmpty()) return@sequence
                stack.reverse()
                val tempNodes = mutableListOf<AccessibilityNodeInfo>()
                do {
                    val top = stack.removeAt(stack.lastIndex)
                    yield(top)
                    for (childNode in getCacheChildren(top)) {
                        tempNodes.add(childNode)
                    }
                    if (tempNodes.isNotEmpty()) {
                        for (i in tempNodes.size - 1 downTo 0) {
                            stack.add(tempNodes[i])
                        }
                        tempNodes.clear()
                    }
                } while (stack.isNotEmpty())
            }.take(MAX_DESCENDANTS_SIZE)
        },
        traverseChildren = { node, connectExpression ->
            sequence {
                repeat(node.childCount.coerceAtMost(MAX_CHILD_SIZE)) { offset ->
                    connectExpression.maxOffset?.let { maxOffset ->
                        if (offset > maxOffset) return@sequence
                    }
                    if (connectExpression.checkOffset(offset)) {
                        val child = getCacheChild(node, offset) ?: return@sequence
                        yield(child)
                    }
                }
            }
        },
        traverseBeforeBrothers = { node, connectExpression ->
            sequence {
                val parentVal = getCacheParent(node) ?: return@sequence
                // 如果 node 由 fastQuery 得到, 则第一次调用此方法可能得到 cache.index 是空
                val index = getPureIndex(node)
                if (index != null) {
                    var i = index - 1
                    var offset = 0
                    while (0 <= i && i < parentVal.childCount) {
                        connectExpression.maxOffset?.let { maxOffset ->
                            if (offset > maxOffset) return@sequence
                        }
                        if (connectExpression.checkOffset(offset)) {
                            val child = getCacheChild(parentVal, i) ?: return@sequence
                            yield(child)
                        }
                        i--
                        offset++
                    }
                } else {
                    val list = getCacheChildren(parentVal).takeWhile { it != node }.toMutableList()
                    list.reverse()
                    yieldAll(list.filterIndexed { i, _ ->
                        connectExpression.checkOffset(
                            i
                        )
                    })
                }
            }
        },
        traverseAfterBrothers = { node, connectExpression ->
            val parentVal = getCacheParent(node)
            if (parentVal != null) {
                val index = getPureIndex(node)
                if (index != null) {
                    sequence {
                        var i = index + 1
                        var offset = 0
                        while (0 <= i && i < parentVal.childCount) {
                            connectExpression.maxOffset?.let { maxOffset ->
                                if (offset > maxOffset) return@sequence
                            }
                            if (connectExpression.checkOffset(offset)) {
                                val child = getCacheChild(parentVal, i) ?: return@sequence
                                yield(child)
                            }
                            i++
                            offset++
                        }
                    }
                } else {
                    getCacheChildren(parentVal).dropWhile { it != node }
                        .drop(1)
                        .let {
                            if (connectExpression.maxOffset != null) {
                                it.take(connectExpression.maxOffset!! + 1)
                            } else {
                                it
                            }
                        }
                        .filterIndexed { i, _ ->
                            connectExpression.checkOffset(
                                i
                            )
                        }
                }
            } else {
                emptySequence()
            }
        },
        traverseDescendants = { node, connectExpression ->
            sequence {
                val stack = getCacheChildren(node).toMutableList()
                if (stack.isEmpty()) return@sequence
                stack.reverse()
                val tempNodes = mutableListOf<AccessibilityNodeInfo>()
                var offset = 0
                do {
                    val top = stack.removeAt(stack.lastIndex)
                    if (connectExpression.checkOffset(offset)) {
                        yield(top)
                    }
                    offset++
                    if (offset > MAX_DESCENDANTS_SIZE) {
                        return@sequence
                    }
                    connectExpression.maxOffset?.let { maxOffset ->
                        if (offset > maxOffset) return@sequence
                    }
                    for (childNode in getCacheChildren(top)) {
                        tempNodes.add(childNode)
                    }
                    if (tempNodes.isNotEmpty()) {
                        for (i in tempNodes.size - 1 downTo 0) {
                            stack.add(tempNodes[i])
                        }
                        tempNodes.clear()
                    }
                } while (stack.isNotEmpty())
            }
        },
        traverseFastQueryDescendants = { node, list ->
            sequence {
                for (fastQuery in list) {
                    val nodes = getFastQueryNodes(node, fastQuery)
                    nodes.forEach { childNode ->
                        yield(childNode)
                    }
                }
            }
        }
    )

    fun querySelfOrSelector(
        node: AccessibilityNodeInfo,
        selector: Selector,
        option: MatchOption,
    ): AccessibilityNodeInfo? {
        if (selector.isMatchRoot) {
            return selector.match(
                getCacheRoot() ?: return null,
                transform,
                option
            )
        }
        selector.match(node, transform, option)?.let {
            return it
        }
        return transform.querySelector(node, selector, option)
    }

    fun queryRule(
        rule: ResolvedRule,
        node: AccessibilityNodeInfo,
    ): AccessibilityNodeInfo? {
        currentRule = rule
        val option = if (allowFastQuery) rule.matchOption else rule.matchOption.copy(fastQuery = false)
        try {
            val queryNode = if (rule.matchRoot) {
                getCacheRoot()
            } else {
                node
            } ?: return null
            var resultNode: AccessibilityNodeInfo? = null
            if (rule.anyMatches.isNotEmpty()) {
                for (selector in rule.anyMatches) {
                    resultNode = querySelfOrSelector(
                        queryNode,
                        selector,
                        option,
                    )
                    if (resultNode != null) break
                }
                if (resultNode == null) return null
            }
            for (selector in rule.matches) {
                resultNode = querySelfOrSelector(
                    queryNode,
                    selector,
                    option,
                ) ?: return null
            }
            for (selector in rule.excludeMatches) {
                querySelfOrSelector(
                    queryNode,
                    selector,
                    option,
                )?.let { return null }
            }
            if (rule.excludeAllMatches.isNotEmpty()) {
                val allExclude = rule.excludeAllMatches.all {
                    querySelfOrSelector(
                        queryNode,
                        it,
                        option,
                    ) == null
                }
                if (!allExclude) {
                    return null
                }
            }
            return resultNode
        } finally {
            currentRule = null
        }
    }
}
