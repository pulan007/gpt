/* TEST-fixture gate diagnostics, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

/** GATE_REJECT value1: the existing predicate which rejected the attempt. */
internal enum class GateRejectReason(val code: Long) {
    NONE(0), RULE_INCOMPLETE(1), ACTIVITY_MISMATCH(2), CONSENT_DISABLED(3),
    ACTION_AGE(4), GUARD_FALSE(5), IDS_NOT_INDEPENDENT(6), ROOT_NULL(7),
    ROOT_REFRESH(8), ROOT_HAS_PARENT(9), SCAN_AGE(10), SELECTOR_NULL(11),
    SELECTOR_TARGET_MISMATCH(12), SNAPSHOT_AGE(13), FINAL_ROOT_CHANGED(14),
    FINAL_WINDOW_CHANGED(15), FINAL_SNAPSHOT_CHANGED(16), CRITICAL_REFRESH(17),
    CRITICAL_PARENT_CHANGED(18), CRITICAL_FACT_CHANGED(19), TARGET_REFRESH(20),
    TARGET_PARENT_CHANGED(21), TARGET_FACT_CHANGED(22), ALREADY_ATTEMPTED(23),
    LEDGER_CAPACITY(24), ACTION_FALSE(25), ACTION_EXCEPTION(26), EXCEPTION(27),
    PROOF_WRONG_THREAD(28), PROOF_CONSUMED_OR_CLOSED(29), PROOF_WRONG_ENTRY(30),
    QUERY_BUDGET_COUNT_EXHAUSTED(31), QUERY_BUDGET_TIME_EXHAUSTED(32), SELECTOR_TIME_BUDGET(33),
    IDENTITY_PACKAGE(40), IDENTITY_SIGNERS_MISSING(41), IDENTITY_SIGNER_NULL(42),
    IDENTITY_SIGNER_EMPTY(43), IDENTITY_SIGNERS_DUPLICATE(44), IDENTITY_POLICY(45),
    WINDOW_ID_INVALID(50), WINDOWS_NULL(51), WINDOWS_EMPTY(52), WINDOWS_LIMIT(53),
    WINDOW_ACTIVE_COUNT(54), WINDOW_FOCUSED_COUNT(55), WINDOW_ID_NOT_UNIQUE(56),
    WINDOW_INACTIVE(57), WINDOW_UNFOCUSED(58), WINDOW_TYPE(59), WINDOW_DISPLAY(60),
    WINDOW_EMPTY_BOUNDS(61), NODE_PACKAGE(70), NODE_WINDOW(71), NODE_CLASS_EMPTY(72),
    NODE_PASSWORD(73), NODE_EDITABLE(74), NODE_DATA_SENSITIVE(75),
    NODE_CHILD_COUNT_NEGATIVE(76), NODE_CHILD_COUNT_LIMIT(77), CHAIN_INVISIBLE(78),
    CHAIN_DISABLED(79), CHAIN_EMPTY_BOUNDS(80), CHAIN_OUTSIDE_PARENT(81),
    ROOT_OUTSIDE_WINDOW(82), TREE_DEPTH(83), TREE_REPEATED_NODE(84), NODE_REFRESH(85),
    NODE_PARENT(86), FORBIDDEN_ID(87), DUPLICATE_REQUIRED_OR_TARGET_ID(88),
    TARGET_NOT_CLICKABLE(89), TREE_NODE_LIMIT(90), TREE_DEPTH_TRUNCATION(91),
    CHILD_NULL(92), REQUIRED_ID_MISSING(93), TARGET_ID_MISSING(94),
}

/** GATE_REJECT/GATE_PHASE value2: the stage that was already being evaluated. */
internal enum class GateTracePhase(val code: Long) {
    ENTRY(1), IDENTITY_INITIAL(2), POST_IDENTITY(3), ROOT_INITIAL(4), WINDOW_INITIAL(5),
    POST_WINDOW(6), CAPTURE_INITIAL(7), POST_CAPTURE(8), QUERY_INITIAL(9), POST_QUERY(10),
    PROOF_ENTRY(11), ROOT_FINAL(12), WINDOW_FINAL(13), CAPTURE_FINAL(14), QUERY_FINAL(15),
    WINDOW_RECHECK(16), IDENTITY_FINAL(17), CRITICAL_REFRESH(18), TARGET_REFRESH(19),
    PRE_RESERVE(20), RESERVE(21), PRE_ACTION(22), ACTION(23), DISPATCH_RETURN(24),
}

/** Value-preserving taps: no clocks, node/platform reads, strings, or retained objects. */
internal inline fun gateTraceFalse(
    value: Boolean, reason: GateRejectReason, phase: GateTracePhase, traceId: Long,
    value3: Long = 0, value4: Long = 0,
): Boolean {
    if (FixtureAdmissionTrace.ENABLED && !value)
        FixtureAdmissionTrace.record(AdmissionTracePoint.GATE_REJECT, traceId, reason.code, phase.code, value3, value4)
    return value
}

internal inline fun gateTraceTrue(
    value: Boolean, reason: GateRejectReason, phase: GateTracePhase, traceId: Long,
    value3: Long = 0, value4: Long = 0,
): Boolean {
    if (FixtureAdmissionTrace.ENABLED && value)
        FixtureAdmissionTrace.record(AdmissionTracePoint.GATE_REJECT, traceId, reason.code, phase.code, value3, value4)
    return value
}

internal inline fun <T> gateTraceNull(
    value: T?, reason: GateRejectReason, phase: GateTracePhase, traceId: Long,
): T? {
    if (FixtureAdmissionTrace.ENABLED && value == null)
        FixtureAdmissionTrace.record(AdmissionTracePoint.GATE_REJECT, traceId, reason.code, phase.code)
    return value
}

/** Only a handful of phase boundaries; value3 is a scalar result where documented. */
internal inline fun gateTracePhase(phase: GateTracePhase, traceId: Long, result: Long = 0) {
    if (FixtureAdmissionTrace.ENABLED)
        FixtureAdmissionTrace.record(AdmissionTracePoint.GATE_PHASE, traceId,
            GateRejectReason.NONE.code, phase.code, result)
}

/** Reuse the existing rejection row; an absent/unpopulated carrier is explicitly unknown. */
internal inline fun gateTraceGuard(
    value: Boolean, phase: GateTracePhase, traceId: Long, failure: GuardFailureDiagnostic?,
): Boolean {
    if (FixtureAdmissionTrace.ENABLED && !value)
        FixtureAdmissionTrace.record(AdmissionTracePoint.GATE_REJECT, traceId,
            GateRejectReason.GUARD_FALSE.code, phase.code,
            failure?.reason ?: GuardFailureComponent.UNATTRIBUTED.code,
            failure?.ageMs ?: Long.MIN_VALUE)
    return value
}
