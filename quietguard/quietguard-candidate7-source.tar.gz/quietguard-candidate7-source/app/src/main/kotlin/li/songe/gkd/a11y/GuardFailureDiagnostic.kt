/* TEST-fixture first-failed guard attribution, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

/** GATE_REJECT/GUARD_FALSE value3. Admission failures are 100 + ContentAdmissionReason.code. */
internal enum class GuardFailureComponent(val code: Long) {
    UNATTRIBUTED(0),
    QUERY_EFFECTIVE(201), QUERY_GENERATION(202), QUERY_EPOCH(203), QUERY_OBSERVED_AT(204),
    QUERY_MATCH_ENABLED(205), QUERY_INTERACTIVE(206), QUERY_AGE(207),
    QUERY_ACTIVITY_RULE(208), QUERY_STATE_EVENT(209),
    OUTDATED_QUERY_GUARD_UNAVAILABLE(300), OUTDATED_EFFECTIVE(301),
    OUTDATED_MATCH_ENABLED(302), OUTDATED_INTERACTIVE(303), OUTDATED_AGE(304),
    OUTDATED_STATE_EVENT(305), OUTDATED_TOP_ACTIVITY(306), OUTDATED_SKIP_MATCH(307),
    OUTDATED_ACTIVITY_RULE(308),
    GATE_OBSERVED_AT(401), GATE_PACKAGE(402), GATE_ACTIVITY(403), GATE_CONSENT(404),
    GATE_REVIEWED_ENTRY(405), GATE_RULE_STATUS(406), GATE_MATCH_ACTIVITY(407),
}

/**
 * One execute call's two primitive failure scalars. Never retains a node/event or reads
 * a clock. Allocated only by the ownedFixture caller. Passing and node guards never
 * write here. A rejected guard ends this attempt's guard evaluation, so no reset is needed.
 */
internal class GuardFailureDiagnostic {
    var reason: Long = GuardFailureComponent.UNATTRIBUTED.code
        private set
    var ageMs: Long = Long.MIN_VALUE
        private set

    fun reject(reason: Long, ageMs: Long = Long.MIN_VALUE) {
        if (FixtureAdmissionTrace.ENABLED && this.reason == GuardFailureComponent.UNATTRIBUTED.code) {
            this.reason = reason
            this.ageMs = ageMs
        }
    }

    fun rejectAdmission(reason: ContentAdmissionReason) {
        if (reason != ContentAdmissionReason.CURRENT) reject(100L + reason.code)
    }
}

/** Value-preserving taps; arguments are the already evaluated original operands. */
internal inline fun guardComponent(
    value: Boolean, reason: GuardFailureComponent, failure: GuardFailureDiagnostic?,
): Boolean {
    if (!value) failure?.reject(reason.code)
    return value
}

internal inline fun guardAge(
    ageMs: Long, limitMs: Long, reason: Long, failure: GuardFailureDiagnostic?,
): Boolean {
    val valid = ageMs in 0 until limitMs
    if (!valid) failure?.reject(reason, ageMs)
    return valid
}
