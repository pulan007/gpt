/* Private-fork scheduling/capability changes, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.atomicfu.atomic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asContextElement
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import li.songe.gkd.META
import li.songe.gkd.app
import li.songe.gkd.PrivateAutomationControl
import li.songe.gkd.PrivateCapabilities
import li.songe.gkd.data.ActionPerformer
import li.songe.gkd.data.ActionResult
import li.songe.gkd.data.AppRule
import li.songe.gkd.data.GkdAction
import li.songe.gkd.data.PrivateAppConsent
import li.songe.gkd.data.ResolvedRule
import li.songe.gkd.data.ReviewedRuleCatalog
import li.songe.gkd.data.reviewedEntry
import li.songe.gkd.data.RpcError
import li.songe.gkd.data.RuleStatus
import li.songe.gkd.isActivityVisible
import li.songe.gkd.service.A11yService
import li.songe.gkd.service.EventService
import li.songe.gkd.service.topAppIdFlow
import li.songe.gkd.shizuku.shizukuContextFlow
import li.songe.gkd.shizuku.uiAutomationFlow
import li.songe.gkd.store.actualBlockA11yAppList
import li.songe.gkd.store.storeFlow
import li.songe.gkd.util.InterruptRuleMatchException
import li.songe.gkd.util.AndroidTarget
import li.songe.gkd.util.AutomatorModeOption
import li.songe.gkd.util.launchTry
import li.songe.gkd.util.runMainPost
import li.songe.gkd.util.showActionToast
import li.songe.gkd.util.systemUiAppId
import li.songe.selector.MatchOption
import li.songe.selector.Selector
import java.util.concurrent.Executors


private val eventDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
private val queryDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
private val actionDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

private val latestServiceMode = atomic(0)
private val latestServiceGeneration = atomic(0L)
// Entire queries and root/window/app-ID reads share physical ownership across all engines.
private val physicalReads = PhysicalReadOwner(SystemClock::elapsedRealtime,
    Executors.newSingleThreadExecutor())
private const val MAX_QUERY_AGE_MS = 1_000L
private val queryAdmissionBudget = PrivateScanBudget(SystemClock::elapsedRealtime)
private val identityAdmissionBudget = PrivateScanBudget(SystemClock::elapsedRealtime)

class A11yRuleEngine(val service: A11yCommonImpl) {
    private val a11yContext = A11yContext(this)
    @Volatile
    private var serviceGeneration = 0L
    private val effective get() = serviceGeneration != 0L &&
        latestServiceGeneration.value == serviceGeneration &&
        latestServiceMode.value == service.mode.value && scope.isActive
    private val followUps = FollowUpBudget(SystemClock::elapsedRealtime)
    private val activityAdmission = PrivateActivityAdmission(SystemClock::elapsedRealtime)
    @Volatile private var admissionTopActivity = topActivityFlow.value
    private val hasOthersService = when (service.mode) {
        AutomatorModeOption.A11yMode -> uiAutomationFlow.value != null
        AutomatorModeOption.AutomationMode -> A11yService.instance != null
    }

    fun onA11yConnected() {
        PrivateAutomationControl.invalidate()
        activityAdmission.clear(ContentAdmissionReason.RECONNECTED)
        serviceGeneration = latestServiceGeneration.incrementAndGet()
        latestServiceMode.value = service.mode.value
        followUps.reset()
        val generation = serviceGeneration
        if (storeFlow.value.enableBlockA11yAppList && !actualBlockA11yAppList.contains(topAppIdFlow.value)) {
            startQueryJob(byForced = true)
        }
        runMainPost(1000L) {// 共存 1000ms, 等待另一个服务稳定
            if (latestServiceGeneration.value == generation && serviceGeneration == generation) {
                when (service.mode) {
                    AutomatorModeOption.A11yMode -> uiAutomationFlow.value?.shutdown(true)
                    AutomatorModeOption.AutomationMode -> A11yService.instance?.shutdown(true)
                }
            }
        }
    }

    fun onScreenForcedActive() {
        PrivateAutomationControl.invalidate()
        activityAdmission.clear(ContentAdmissionReason.SCREEN_ACTIVATED)
        followUps.reset()
        // 关闭屏幕 -> Activity::onStop -> 点亮屏幕 -> Activity::onStart -> Activity::onResume
        val a = topActivityFlow.value
        synchronized(topActivityFlow) {
            updateTopActivity(
                a.appId,
                a.activityId,
                scene = ActivityScene.ScreenOn
            )
        }
        startQueryJob()
    }

    private fun readWindow(): AccessibilityNodeInfo? = try {
        service.windowNodeInfo
    } catch (_: Throwable) {
        null
    }

    @Suppress("DEPRECATION")
    private fun recycleUnusedRoot(node: AccessibilityNodeInfo) { node.recycle() }

    private fun currentReadGuard(): () -> Boolean {
        val activity = topActivityFlow.value
        val stateEvent = latestStateEvent
        val generation = serviceGeneration
        val epoch = PrivateAutomationControl.epoch()
        return { effective && serviceGeneration == generation &&
            PrivateAutomationControl.epoch() == epoch &&
            topActivityFlow.value == activity && latestStateEvent === stateEvent }
    }

    val safeActiveWindow: AccessibilityNodeInfo?
        get() = physicalReads.read(500L, currentReadGuard(), ::recycleUnusedRoot, ::readWindow)?.also {
            it.setGeneratedTime()
            a11yContext.rootCache.value = it
        }

    val safeActiveWindowAppId: String?
        get() = safeActiveWindow?.packageName?.toString()

    private val scope get() = service.scope

    @Volatile
    private var latestStateEvent: A11yEvent? = null
    private var lastContentEventTime = 0L
    private var lastEventTime = 0L
    private data class EventInput(
        val events: EventBatch<A11yEvent>,
        val candidate: PrivateActivityAdmission.Candidate?,
    )
    private val eventWork = LatestWork<EventInput> { previous, next ->
        next.copy(events = previous.events.merge(next.events, A11yEvent::sameAs))
    }
    fun onA11yEvent(event: AccessibilityEvent?) {
        if (!effective || event == null) return
        // Secondary displays do not establish foreground identity on the default display.
        if (AndroidTarget.TIRAMISU && event.displayId != Display.DEFAULT_DISPLAY) return
        if (!event.isUseful()) {
            if (event.eventType == STATE_CHANGED) synchronized(activityAdmission) {
                PrivateAutomationControl.invalidate()
                latestStateEvent = null
                activityAdmission.clear(ContentAdmissionReason.MALFORMED_STATE)
            }
            return
        }
        onA11yFeatEvent(event)
        val a11yEvent = event.toA11yEvent() ?: run {
            if (event.eventType == STATE_CHANGED) synchronized(activityAdmission) {
                PrivateAutomationControl.invalidate()
                latestStateEvent = null
                activityAdmission.clear(ContentAdmissionReason.MALFORMED_STATE)
            }
            return
        }
        if (event.eventTime < lastEventTime) {
            if (event.eventType == STATE_CHANGED) synchronized(activityAdmission) {
                PrivateAutomationControl.invalidate()
                latestStateEvent = null
                activityAdmission.clear(ContentAdmissionReason.OLD_STATE)
            }
            return
        }
        lastEventTime = event.eventTime
        val receivedAt = SystemClock.elapsedRealtime()
        // These exact existing CONTENT exclusions do not describe a foreground
        // transition. Ignore them before observing the candidate, including during proof.
        // STATE always reaches invalidation before the corresponding own/IME filters.
        if (event.eventType == CONTENT_CHANGED) {
            if (!isInteractive) return
            if (event.packageName == systemUiAppId && event.packageName != topActivityFlow.value.appId) return
            if (event.packageName == imeAppId && topActivityFlow.value.appId != imeAppId &&
                event.recordCount == 0 && event.action == 0 && !event.isFullScreen) return
            if (event.packageName == META.appId) return
        }
        val candidate = synchronized(activityAdmission) {
            if (event.eventType == STATE_CHANGED) {
                PrivateAutomationControl.invalidate()
                latestStateEvent = a11yEvent
                admissionTopActivity = topActivityFlow.value
            } else if (topActivityFlow.value !== admissionTopActivity) {
                activityAdmission.clear(ContentAdmissionReason.TOP_ACTIVITY_CHANGED)
            }
            val supported = storeFlow.value.enableMatch && isInteractive &&
                ReviewedRuleCatalog.supportsPackage(a11yEvent.appId) &&
                PrivateAppConsent.isEnabled(a11yEvent.appId)
            val exactActivity = supported && (event.eventType != STATE_CHANGED ||
                ReviewedRuleCatalog.supportsActivity(a11yEvent.appId, a11yEvent.name))
            activityAdmission.observe(a11yEvent.appId, a11yEvent.name, a11yEvent.windowId,
                event.eventType == STATE_CHANGED, supported && exactActivity, receivedAt,
                PrivateAutomationControl.epoch(), serviceGeneration)
        }
        if (event.eventType != CONTENT_CHANGED) {
            // Preserve STATE exclusions only after irrevocably fencing older work.
            if (event.packageName == imeAppId && topActivityFlow.value.appId != imeAppId) {
                if (event.recordCount == 0 && event.action == 0 && !event.isFullScreen) return
            }
            if (!isActivityVisible && event.packageName == META.appId) return
        }

        if (a11yEvent.type == CONTENT_CHANGED) {
            // 防止 content 类型事件过快
            if (a11yEvent.time - lastContentEventTime < 100 && a11yEvent.time - appChangeTime > 5000 && a11yEvent.time - lastTriggerTime > 3000) {
                return
            }
            lastContentEventTime = a11yEvent.time
        }
        EventService.logEvent(event)
        if (PrivateCapabilities.SENSITIVE_LOGGING && META.debuggable) {
            Log.d(
                "onNewA11yEvent",
                "type:${event.eventType}, time:${event.eventTime - lastEventTime}, app:${event.packageName}, cls:${event.className}"
            )
        }
        if (ReviewedRuleCatalog.isEmpty) return
        followUps.reset()
        eventWork.offer(EventInput(EventBatch(a11yEvent), candidate))
            ?.let(::launchEvent)
    }

    private fun launchEvent(ticket: LatestWork.Ticket<EventInput>) {
        scope.launchTry(eventDispatcher) { consumeEvent(ticket.value) }.invokeOnCompletion {
            eventWork.complete(ticket)?.let(::launchEvent)
        }
    }

    private val queryEventsLock = Any()
    private var queryEvents: EventBatch<A11yEvent>? = null
    // Preserve the original guard's short-circuit order and clock count. The optional
    // carrier is supplied only by Gate's guard; sparse admission/node checks omit it.
    private fun admissionStatus(
        candidate: PrivateActivityAdmission.Candidate,
        failure: GuardFailureDiagnostic? = null,
    ): ContentAdmissionReason {
        val status = when {
            !effective -> ContentAdmissionReason.SERVICE_INACTIVE
            !storeFlow.value.enableMatch -> ContentAdmissionReason.MATCH_DISABLED
            !isInteractive -> ContentAdmissionReason.SCREEN_INACTIVE
            topActivityFlow.value !== admissionTopActivity -> ContentAdmissionReason.TOP_ACTIVITY_CHANGED
            !PrivateAppConsent.isEnabled(candidate.packageName) -> ContentAdmissionReason.CONSENT_DISABLED
            else -> activityAdmission.currentStatus(candidate, PrivateAutomationControl.epoch(), serviceGeneration, failure)
        }
        failure?.rejectAdmission(status)
        return status
    }

    private fun admissionCurrent(
        candidate: PrivateActivityAdmission.Candidate,
        failure: GuardFailureDiagnostic? = null,
    ): Boolean = admissionStatus(candidate, failure) == ContentAdmissionReason.CURRENT

    private fun admissionAt(candidate: PrivateActivityAdmission.Candidate, stage: ContentQueryStage): Boolean {
        val status = admissionStatus(candidate)
        if (status != ContentAdmissionReason.CURRENT) contentQueryTrace(stage, candidate.epoch, status)
        return status == ContentAdmissionReason.CURRENT
    }

    private suspend fun consumeEvent(input: EventInput) {
        val candidate = input.candidate ?: return
        if (!admissionAt(candidate, ContentQueryStage.CONSUME_REJECTED)) return
        // Both opportunities belong to this one event worker. No polling, follow-up job,
        // renewed timestamp, or third read is created by a timeout or a content burst.
        repeat(2) {
            if (!admissionAt(candidate, ContentQueryStage.IDENTITY_REJECTED)) return
            val waitMs = activityAdmission.delayBeforeAttempt(candidate) ?: return@repeat
            if (waitMs > 0) delay(waitMs)
            if (!admissionAt(candidate, ContentQueryStage.IDENTITY_REJECTED) || !activityAdmission.reserveAttempt(candidate)) return
            val identity = getTimeoutIdentity(candidate)
            if (!admissionAt(candidate, ContentQueryStage.IDENTITY_REJECTED)) return
            if (identity != null) {
                synchronized(activityAdmission) {
                    if (!admissionAt(candidate, ContentQueryStage.PROMOTION_REJECTED)) return
                    if (!activityAdmission.promote(candidate, identity.packageName, identity.windowId)) return
                    synchronized(topActivityFlow) {
                        // No generic class or lastValidActivity/package-only fallback.
                        if (!admissionAt(candidate, ContentQueryStage.PROMOTION_REJECTED)) return
                        updateTopActivity(candidate.packageName, candidate.activityName)
                        admissionTopActivity = topActivityFlow.value
                    }
                }
            }
        }
        if (!admissionAt(candidate, ContentQueryStage.BEFORE_QUERY_REJECTED)) return
        if (activityAdmission.admitted() !== candidate) {
            contentQueryTrace(ContentQueryStage.NO_ADMITTED_CANDIDATE, candidate.epoch,
                ContentAdmissionReason.NOT_PROMOTED)
            return
        }
        val activityRule = activityRuleFlow.value
        if (activityRule.topActivity.appId != candidate.packageName ||
            activityRule.topActivity.activityId != candidate.activityName || activityRule.skipConsumeEvent) {
            contentQueryTrace(ContentQueryStage.ACTIVITY_RULE_REJECTED, candidate.epoch)
            return
        }
        synchronized(queryEventsLock) {
            queryEvents = queryEvents?.merge(input.events, A11yEvent::sameAs) ?: input.events
        }
        a11yContext.interruptKey++
        startQueryJob(byEvent = input.events.latest, observedAt = candidate.observedAt,
            controlEpoch = candidate.epoch, generation = candidate.generation)
    }

    private data class WindowIdentity(val packageName: String, val windowId: Int)

    private suspend fun getTimeoutIdentity(candidate: PrivateActivityAdmission.Candidate): WindowIdentity? {
        if (!admissionCurrent(candidate) || !identityAdmissionBudget.tryAcquire()) return null
        activityAdmission.identityAdmitted(candidate)
        val guard = { admissionCurrent(candidate) }
        // A timeout expires only the evidence/waiter, never the physical lease. This
        // provisional root identity is not action proof; Gate verifies active/focused
        // default-display windows and all live identity/context again before dispatch.
        return withTimeoutOrNull(100L) {
            physicalReads.readAsync(100L, guard) {
                val root = readWindow() ?: return@readAsync null
                try { WindowIdentity(root.packageName?.toString().orEmpty(), root.windowId) }
                finally { recycleUnusedRoot(root) }
            }
        }?.takeIf { guard() }
    }

    private fun readAdmittedWindow(
        candidate: PrivateActivityAdmission.Candidate,
        previouslyTransferred: AccessibilityNodeInfo?,
    ): AccessibilityNodeInfo? {
        if (!admissionCurrent(candidate)) return null
        val root = readWindow() ?: return null
        var transferred = false
        try {
            if (!admissionCurrent(candidate) || root.packageName?.toString() != candidate.packageName ||
                root.windowId != candidate.windowId || !admissionCurrent(candidate)) return null
            transferred = true
            return root
        } catch (_: Exception) {
            return null
        } finally {
            // Gate already owns an identical handle returned by its first root read.
            if (!transferred && root !== previouslyTransferred) recycleUnusedRoot(root)
        }
    }

    private fun getTimeoutActiveWindow(): AccessibilityNodeInfo? {
        // Inline on queryDispatcher while the full-query lease is held. The 500 ms age
        // limit discards late evidence; it does not pretend a blocked Binder call ended.
        return safeActiveWindow
    }

    private data class QueryRequest(
        val event: A11yEvent?,
        val forced: Boolean,
        val delayRule: ResolvedRule?,
        val observedAt: Long,
        val controlEpoch: Long,
        val generation: Long,
        val admission: PrivateActivityAdmission.Candidate,
    )

    private fun startQueryJob(
        byEvent: A11yEvent? = null,
        byForced: Boolean = false,
        byDelayRule: ResolvedRule? = null,
        observedAt: Long = SystemClock.elapsedRealtime(),
        controlEpoch: Long = PrivateAutomationControl.epoch(),
        generation: Long = serviceGeneration,
    ) {
        contentQueryTrace(ContentQueryStage.REQUESTED, controlEpoch)
        if (!effective || !storeFlow.value.enableMatch || !isInteractive ||
            controlEpoch != PrivateAutomationControl.epoch() || generation != serviceGeneration) {
            contentQueryTrace(ContentQueryStage.REQUEST_CONTROL_REJECTED, controlEpoch)
            return
        }
        if (activityRuleFlow.value.currentRules.none { it.reviewedEntry()?.takeIf(PrivateAppConsent::isEnabled) != null }) {
            contentQueryTrace(ContentQueryStage.NO_REVIEWED_RULE, controlEpoch)
            return
        }
        if (byEvent == null && !followUps.isOpen()) {
            contentQueryTrace(ContentQueryStage.FOLLOW_UP_CLOSED, controlEpoch)
            return
        }
        // 无障碍从零启动时获取 safeActiveWindow 非常耗时
        if (byEvent == null && service.justStarted && !hasOthersService) {
            contentQueryTrace(ContentQueryStage.SERVICE_START_DEFERRED, controlEpoch)
            return checkFutureStartJob()
        }
        val admission = activityAdmission.admitted() ?: run {
            contentQueryTrace(ContentQueryStage.NO_ADMITTED_CANDIDATE, controlEpoch)
            return
        }
        if (!admissionAt(admission, ContentQueryStage.ADMISSION_REJECTED)) return
        if (observedAt != admission.observedAt) {
            contentQueryTrace(ContentQueryStage.OBSERVED_TIME_REJECTED, controlEpoch)
            return
        }
        val claimStatus = activityAdmission.queryClaimStatus(admission)
        if (claimStatus != ContentAdmissionReason.CURRENT) {
            contentQueryTrace(ContentQueryStage.CLAIM_REJECTED, controlEpoch, claimStatus)
            return
        }
        contentQueryTrace(ContentQueryStage.ENQUEUED, controlEpoch)
        queryWork.offer(this to QueryRequest(byEvent, byForced, byDelayRule, observedAt, controlEpoch, generation, admission),
            keepPending = byEvent != null)?.let(::launchQuery)
    }

    private fun launchQuery(ticket: LatestWork.Ticket<Pair<A11yRuleEngine, QueryRequest>>) {
        scope.launchTry(queryDispatcher) {
            val request = ticket.value.second
            contentQueryTrace(ContentQueryStage.WORKER_ENTERED, request.controlEpoch)
            if (!effective || !storeFlow.value.enableMatch || !isInteractive) {
                contentQueryTrace(ContentQueryStage.WORKER_CONTROL_REJECTED, request.controlEpoch)
                return@launchTry
            }
            if (SystemClock.elapsedRealtime() - request.observedAt >= MAX_QUERY_AGE_MS) {
                contentQueryTrace(ContentQueryStage.WORKER_AGE_REJECTED, request.controlEpoch,
                    ContentAdmissionReason.EXPIRED)
                return@launchTry
            }
            if (!queryAdmissionBudget.tryAcquire()) {
                contentQueryTrace(ContentQueryStage.QUERY_BUDGET_REJECTED, request.controlEpoch)
                return@launchTry
            }
            queryAction(request.event, request.forced, request.delayRule, request.observedAt,
                request.controlEpoch, request.generation, request.admission)
        }.invokeOnCompletion {
            val next = queryWork.complete(ticket)
            if (next != null) next.value.first.launchQuery(next)
            // Exhausted admission or a failed attempt never initiates automatic polling.
        }
    }

    private fun scheduleFollowUp(byForced: Boolean = false) {
        if (!effective || !storeFlow.value.enableMatch || !isInteractive) return
        val token = followUps.reserve(300L) ?: return
        val epoch = PrivateAutomationControl.epoch()
        val generation = serviceGeneration
        scope.launch(actionDispatcher) {
            delay(300L)
            if (followUps.release(token)) startQueryJob(byForced = byForced, controlEpoch = epoch, generation = generation)
        }.invokeOnCompletion { followUps.release(token) }
    }

    private fun checkFutureStartJob() {
        val t = System.currentTimeMillis()
        if (t - lastTriggerTime < 3000L || t - appChangeTime < 3000L) {
            scheduleFollowUp()
        } else if (activityRuleFlow.value.hasFeatureAction) {
            scheduleFollowUp(byForced = true)
        }
    }

    private fun fixAppId(rightAppId: String) {
        if (topActivityFlow.value.appId == rightAppId) return
        synchronized(topActivityFlow) {
            val topCpn = shizukuContextFlow.value.topCpn()
            if (topCpn?.packageName == rightAppId) {
                updateTopActivity(topCpn.packageName, topCpn.className)
            } else {
                updateTopActivity(rightAppId, null)
            }
        }
        scheduleFollowUp()
    }

    private suspend fun queryAction(
        byEvent: A11yEvent? = null,
        byForced: Boolean = false,
        delayRule: ResolvedRule? = null,
        observedAt: Long,
        controlEpoch: Long,
        generation: Long,
        admission: PrivateActivityAdmission.Candidate,
    ) {
        val activityRule = activityRuleFlow.value
        val stateEvent = latestStateEvent
        val guard = { failure: GuardFailureDiagnostic? ->
            guardComponent(effective, GuardFailureComponent.QUERY_EFFECTIVE, failure) &&
                guardComponent(generation == serviceGeneration, GuardFailureComponent.QUERY_GENERATION, failure) &&
                guardComponent(controlEpoch == PrivateAutomationControl.epoch(), GuardFailureComponent.QUERY_EPOCH, failure) &&
                admissionCurrent(admission, failure) &&
                guardComponent(observedAt == admission.observedAt, GuardFailureComponent.QUERY_OBSERVED_AT, failure) &&
                guardComponent(storeFlow.value.enableMatch, GuardFailureComponent.QUERY_MATCH_ENABLED, failure) &&
                guardComponent(isInteractive, GuardFailureComponent.QUERY_INTERACTIVE, failure) &&
                guardAge(SystemClock.elapsedRealtime() - observedAt, MAX_QUERY_AGE_MS,
                    GuardFailureComponent.QUERY_AGE.code, failure) &&
                guardComponent(activityRule === activityRuleFlow.value, GuardFailureComponent.QUERY_ACTIVITY_RULE, failure) &&
                guardComponent(stateEvent === latestStateEvent, GuardFailureComponent.QUERY_STATE_EVENT, failure)
        }
        val owned = physicalReads.withOwnership {
            withContext(queryGuard.asContextElement(guard)) {
                queryActionOwned(byEvent, byForced, delayRule, observedAt, controlEpoch, generation, admission)
            }
        }
        if (owned == null) contentQueryTrace(ContentQueryStage.PHYSICAL_BUSY, controlEpoch)
    }

    private val queryGuard = ThreadLocal<((GuardFailureDiagnostic?) -> Boolean)?>()

    internal fun guardNodeQuery() {
        if (queryGuard.get()?.invoke(null) != true) throw InterruptRuleMatchException()
    }

    private suspend fun queryActionOwned(
        byEvent: A11yEvent?,
        byForced: Boolean,
        delayRule: ResolvedRule?,
        observedAt: Long,
        controlEpoch: Long,
        generation: Long,
        admission: PrivateActivityAdmission.Candidate,
    ) {
        contentQueryTrace(ContentQueryStage.OWNED_QUERY_ENTERED, controlEpoch)
        val tempStateEvent = latestStateEvent
        val activityRule = synchronized(topActivityFlow) { activityRuleFlow.value }
        // No event source, root, cache traversal, or delay work for unreviewed imports.
        val eligibleRules = activityRule.currentRules.filter { it.reviewedEntry()?.takeIf(PrivateAppConsent::isEnabled) != null }
        if (eligibleRules.isEmpty() || checkOutDate(activityRule, tempStateEvent, observedAt)) {
            contentQueryTrace(ContentQueryStage.OWNED_RULE_OR_CONTEXT_REJECTED, controlEpoch)
            return
        }
        if (delayRule == null) {
            synchronized(queryEventsLock) {
                if (byEvent != null && queryEvents == null) {
                    contentQueryTrace(ContentQueryStage.EVENTS_MISSING, controlEpoch)
                    return
                }
                queryEvents = null
            }
        }
        eligibleRules.forEach { rule ->
            if (rule.status == RuleStatus.Status3 && rule.matchDelayJob.value == null) {
                rule.matchDelayJob.value = scope.launch(actionDispatcher) {
                    delay(rule.matchDelay)
                    rule.matchDelayJob.value = null
                    startQueryJob(byDelayRule = rule, controlEpoch = controlEpoch, generation = generation)
                }
            }
        }
        if (activityRule.skipMatch) {
            contentQueryTrace(ContentQueryStage.MATCH_SKIPPED, controlEpoch)
            // 如果当前应用没有规则/暂停匹配, 则不去调用获取事件节点避免阻塞
            return
        }
        // Event content and old selector caches never authorize a dispatch. Every reviewed
        // attempt builds its own bounded, disposable root/context inside the physical lease.
        for (rule in activityRule.priorityRules) {
            if (rule !in eligibleRules) continue
            if (checkOutDate(activityRule, tempStateEvent, observedAt)) break
            if (delayRule != null && delayRule !== rule) continue
            if (rule.status != RuleStatus.StatusOk || (byForced && !rule.checkForced())) continue
            val entry = rule.reviewedEntry()?.takeIf(PrivateAppConsent::isEnabled) ?: continue
            val activityName = topActivityFlow.value.activityId ?: continue
            // Gate calls freshRoot at most twice and deduplicates handles by identity.
            // Keep only this execute call's first transfer so a rejected alias is not
            // recycled both here and again by Gate's finally block.
            var transferredRoot: AccessibilityNodeInfo? = null
            contentQueryTrace(ContentQueryStage.GATE_ENTERED, controlEpoch)
            val guardFailure = if (FixtureAdmissionTrace.ENABLED) GuardFailureDiagnostic() else null
            val accepted = ReviewedExecutionGate.process.execute(
                entry = entry,
                packageManager = app.packageManager,
                activityName = activityName,
                observedAt = observedAt,
                traceId = admission.epoch,
                guardFailure = guardFailure,
                freshRoot = {
                    readAdmittedWindow(admission, transferredRoot)?.also { transferredRoot = it }
                },
                freshDefaultWindows = { service.windowInfos },
                queryFresh = { root, budgetGuard, ownNode ->
                    A11yContext(this, nodeQueryGuard = budgetGuard,
                        allowFastQuery = false, nodeOwner = ownNode).apply {
                        rootCache.value = root
                    }.queryRule(rule, root)
                },
                guard = {
                    admissionCurrent(admission, guardFailure) &&
                        guardComponent(observedAt == admission.observedAt, GuardFailureComponent.GATE_OBSERVED_AT, guardFailure) &&
                        !checkOutDate(activityRule, tempStateEvent, observedAt, guardFailure) &&
                        guardComponent(topActivityFlow.value.appId == entry.packageName, GuardFailureComponent.GATE_PACKAGE, guardFailure) &&
                        guardComponent(topActivityFlow.value.activityId == entry.activityName, GuardFailureComponent.GATE_ACTIVITY, guardFailure) &&
                        guardComponent(PrivateAppConsent.isEnabled(entry), GuardFailureComponent.GATE_CONSENT, guardFailure) &&
                        guardComponent(rule.reviewedEntry() === entry, GuardFailureComponent.GATE_REVIEWED_ENTRY, guardFailure) &&
                        guardComponent(rule.status == RuleStatus.StatusOk, GuardFailureComponent.GATE_RULE_STATUS, guardFailure) &&
                        guardComponent(rule.matchActivity(entry.packageName, entry.activityName), GuardFailureComponent.GATE_MATCH_ACTIVITY, guardFailure)
                },
                dispatch = { proof ->
                    if (rule.checkDelay()) {
                        if (rule.actionDelayJob.value == null) {
                            rule.actionDelayJob.value = scope.launch(actionDispatcher) {
                                delay(rule.actionDelay)
                                rule.actionDelayJob.value = null
                                startQueryJob(byDelayRule = rule, controlEpoch = controlEpoch,
                                    generation = generation)
                            }
                        }
                        false
                    } else {
                        rule.performReviewedAction(proof).result
                    }
                },
            )
            if (accepted) {
                rule.trigger()
                showActionToast(rule)
                // No target logging, stored node, fallback or automatic post-action retry.
                // ACTION_CLICK acceptance is not proof that the advertisement disappeared.
            }
        }
    }

    private fun checkOutDate(
        activityRule: ActivityRule,
        stateEvent: A11yEvent?,
        observedAt: Long,
        failure: GuardFailureDiagnostic? = null,
    ): Boolean {
        if (!guardComponent(queryGuard.get()?.invoke(failure) == true,
                GuardFailureComponent.OUTDATED_QUERY_GUARD_UNAVAILABLE, failure)) return true
        if (!guardComponent(effective, GuardFailureComponent.OUTDATED_EFFECTIVE, failure) ||
            !guardComponent(storeFlow.value.enableMatch, GuardFailureComponent.OUTDATED_MATCH_ENABLED, failure) ||
            !guardComponent(isInteractive, GuardFailureComponent.OUTDATED_INTERACTIVE, failure)) return true
        if (!guardAge(SystemClock.elapsedRealtime() - observedAt, MAX_QUERY_AGE_MS,
                GuardFailureComponent.OUTDATED_AGE.code, failure)) return true
        if (!guardComponent(stateEvent === latestStateEvent, GuardFailureComponent.OUTDATED_STATE_EVENT, failure)) return true
        if (!guardComponent(activityRule.topActivity == topActivityFlow.value, GuardFailureComponent.OUTDATED_TOP_ACTIVITY, failure) ||
            !guardComponent(!activityRule.skipMatch, GuardFailureComponent.OUTDATED_SKIP_MATCH, failure)) return true
        synchronized(topActivityFlow) {
            if (!guardComponent(activityRule === activityRuleFlow.value,
                    GuardFailureComponent.OUTDATED_ACTIVITY_RULE, failure)) return true
        }
        return false
    }

    companion object {
        // Admission is process-wide: recreating services cannot grow the query executor queue.
        private val queryWork = LatestWork<Pair<A11yRuleEngine, QueryRequest>>()

        val service: A11yCommonImpl?
            get() = uiAutomationFlow.value?.takeIf {
                it.mode.value == latestServiceMode.value
            } ?: A11yService.instance
        val instance: A11yRuleEngine? get() = service?.ruleEngine

        fun compatWindows(): List<AccessibilityWindowInfo> {
            val engine = instance ?: return emptyList()
            return physicalReads.read(500L, engine.currentReadGuard(), discard = { windows ->
                @Suppress("DEPRECATION")
                windows.forEach { it.recycle() }
            }) {
                try {
                    engine.service.windowInfos
                } catch (_: Throwable) {
                    null
                }
            } ?: emptyList()
        }

        fun onScreenForcedActive() {
            instance?.onScreenForcedActive()
        }

        fun performActionBack(): Boolean {
            if (!PrivateCapabilities.EXTERNAL_COMMANDS) return false
            val r1 = shizukuContextFlow.value.inputManager?.key(KeyEvent.KEYCODE_BACK)
            if (r1 != null) return true
            return A11yService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) == true
        }

        suspend fun screenshot(): Bitmap? {
            if (!PrivateCapabilities.SCREENSHOTS) return null
            return service?.screenshot()
        }

        suspend fun execAction(gkdAction: GkdAction): ActionResult {
            PrivateCapabilities.requireEnabled(PrivateCapabilities.EXTERNAL_COMMANDS, "外部动作")
            val selector = Selector.parseOrNull(gkdAction.selector) ?: throw RpcError("非法选择器")
            runCatching { selector.checkType(typeInfo) }.exceptionOrNull()?.let {
                throw RpcError("选择器类型错误:${it.message}")
            }
            val s = instance ?: throw RpcError("服务未连接")
            val a = s.safeActiveWindow ?: throw RpcError("界面没有节点信息")
            val targetNode = A11yContext(s, interruptable = false).querySelfOrSelector(
                a, selector, MatchOption(fastQuery = gkdAction.fastQuery)
            ) ?: throw RpcError("没有查询到节点")
            return withContext(Dispatchers.IO) {
                ActionPerformer
                    .getAction(gkdAction.action ?: ActionPerformer.None.action)
                    .perform(targetNode, gkdAction)
            }
        }

    }
}
