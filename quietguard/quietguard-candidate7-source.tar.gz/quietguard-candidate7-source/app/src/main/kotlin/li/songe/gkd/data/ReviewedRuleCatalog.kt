// Private-fork addition, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.data

import java.security.MessageDigest
import java.util.Collections

/** A review decision compiled with the application, never read from a subscription. */
internal enum class ReviewedRulePurpose {
    AD_DISMISS, REWARD, TRANSACTION, AUTHENTICATION, PERMISSION, UNKNOWN,
}

/**
 * Exact reviewed scope. Defensive copies prevent a caller retaining a mutable collection
 * from changing an approved identity or selector. No serializer/importer can enroll entries.
 * A digest is lowercase SHA-256, without colons, over the documented canonical UTF-8 JSON.
 */
internal class ReviewedRuleEntry(
    val packageName: String,
    val versionCode: Long,
    currentSignerSha256: Set<String>,
    val activityName: String,
    val groupKey: Int,
    val ruleKey: Int,
    val ruleSha256: String,
    val groupSha256: String,
    val targetSelector: String,
    requiredContextSelectors: List<String>,
    forbiddenContextSelectors: List<String>,
    val purpose: ReviewedRulePurpose,
) {
    val currentSignerSha256: Set<String> =
        Collections.unmodifiableSet(LinkedHashSet(currentSignerSha256))
    val requiredContextSelectors: List<String> =
        Collections.unmodifiableList(ArrayList(requiredContextSelectors))
    val forbiddenContextSelectors: List<String> =
        Collections.unmodifiableList(ArrayList(forbiddenContextSelectors))

    // Only immutable compiled structure is memoized, after all defensive copies exist.
    // Default synchronized lazy publication also caches false without a global entry cache.
    val structurallyComplete: Boolean by lazy { ReviewedRulePolicy.computeCompleteness(this) }
}

/** Live facts must come from Android, never a rule or an imported app description. */
internal data class ReviewedAppIdentity(
    val packageName: String,
    val versionCode: Long,
    val currentSignerSha256: Set<String>,
    val activityName: String,
)

/** The local rule shape and freshly serialized content, not a self-declared review label. */
internal data class ReviewedRuleCandidate(
    val packageName: String?,
    val isGlobal: Boolean,
    val groupKey: Int,
    val ruleKey: Int?,
    val activityNames: List<String>,
    val action: String?,
    val hasPosition: Boolean,
    val hasSwipe: Boolean,
    val matches: List<String>,
    val anyMatches: List<String>,
    val excludeMatches: List<String>,
    val excludeAllMatches: List<String>,
    val hasExternalRuleDependencies: Boolean,
    val serializedRule: String,
    val serializedGroup: String,
)

/** Pure admission policy. Successful admission is not permission to click a node. */
internal object ReviewedRulePolicy {
    private val packagePattern = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
    private val activityPattern = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z_$][A-Za-z0-9_$]*)+")
    private val digestPattern = Regex("[0-9a-f]{64}")

    fun sha256(serialized: String): String = sha256(serialized.toByteArray(Charsets.UTF_8))

    fun sha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val hex = "0123456789abcdef"
        return CharArray(digest.size * 2) { index ->
            val byte = digest[index / 2].toInt() and 0xff
            hex[if (index % 2 == 0) byte ushr 4 else byte and 0x0f]
        }.concatToString()
    }

    // Only these three complete literal forms are accepted. The package guard below
    // uses the same grammar; capture comparison still requires the exact app package.
    private val targetSelectorPattern = Regex(
        "\\[id=(['\"])([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z][A-Za-z0-9_]*)+):id/[A-Za-z_][A-Za-z0-9_]*\\1\\]\\[visibleToUser=true\\]\\[clickable=true\\]\\[editable=false\\]",
    )
    private val contextSelectorPattern = Regex(
        "\\[id=(['\"])([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z][A-Za-z0-9_]*)+):id/[A-Za-z_][A-Za-z0-9_]*\\1\\]\\[visibleToUser=true\\]",
    )
    private val forbiddenSelectorPattern = Regex(
        "\\[id=(['\"])([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z][A-Za-z0-9_]*)+):id/[A-Za-z_][A-Za-z0-9_]*\\1\\]",
    )

    /** Deliberately small grammar: one exact app-owned resource ID plus fixed node flags. */
    private fun exactSelector(selector: String, packageName: String, pattern: Regex): Boolean =
        pattern.matchEntire(selector)?.groupValues?.get(2) == packageName

    fun isComplete(entry: ReviewedRuleEntry): Boolean = entry.structurallyComplete

    /** Uncached structural predicate; never calls isComplete or reads any live state. */
    fun computeCompleteness(entry: ReviewedRuleEntry): Boolean =
        packagePattern.matches(entry.packageName) && entry.versionCode > 0L &&
            activityPattern.matches(entry.activityName) &&
            entry.currentSignerSha256.isNotEmpty() &&
            entry.currentSignerSha256.all(digestPattern::matches) &&
            digestPattern.matches(entry.ruleSha256) && digestPattern.matches(entry.groupSha256) &&
            entry.purpose == ReviewedRulePurpose.AD_DISMISS &&
            exactSelector(entry.targetSelector, entry.packageName, targetSelectorPattern) &&
            entry.requiredContextSelectors.isNotEmpty() &&
            entry.requiredContextSelectors.all { exactSelector(it, entry.packageName, contextSelectorPattern) } &&
            entry.forbiddenContextSelectors.isNotEmpty() &&
            entry.forbiddenContextSelectors.all { exactSelector(it, entry.packageName, forbiddenSelectorPattern) } &&
            (entry.requiredContextSelectors + entry.targetSelector + entry.forbiddenContextSelectors)
                .let { selectors -> selectors.distinct().size == selectors.size }

    /** Require exactly one entry for the claimed package/group/rule, even if duplicates agree. */
    fun admit(
        candidate: ReviewedRuleCandidate,
        entries: List<ReviewedRuleEntry>,
    ): ReviewedRuleEntry? {
        if (candidate.isGlobal || candidate.packageName == null || candidate.ruleKey == null ||
            candidate.hasExternalRuleDependencies ||
            !PrivateActionPolicy.allowsAction(candidate.action, candidate.hasPosition, candidate.hasSwipe) ||
            candidate.anyMatches.isNotEmpty() || candidate.excludeAllMatches.isNotEmpty()
        ) return null
        val entry = entries.filter {
            it.packageName == candidate.packageName && it.groupKey == candidate.groupKey &&
                it.ruleKey == candidate.ruleKey
        }.singleOrNull() ?: return null
        if (!isComplete(entry) || candidate.activityNames != listOf(entry.activityName) ||
            // A11yContext.queryRule returns the last matched selector's node.
            candidate.matches != entry.requiredContextSelectors + entry.targetSelector ||
            candidate.excludeMatches != entry.forbiddenContextSelectors ||
            sha256(candidate.serializedRule) != entry.ruleSha256 ||
            sha256(candidate.serializedGroup) != entry.groupSha256
        ) return null
        return entry
    }

    /** Current signer set equality rejects subsets, added signers and old signer history. */
    fun matchesIdentity(entry: ReviewedRuleEntry, identity: ReviewedAppIdentity): Boolean =
        isComplete(entry) && identity.packageName == entry.packageName &&
            identity.versionCode == entry.versionCode &&
            identity.currentSignerSha256 == entry.currentSignerSha256 &&
            identity.activityName == entry.activityName

    /** Per-app consent expires if any reviewed scope or rule content for that app changes. */
    fun consentRevision(packageName: String, entries: List<ReviewedRuleEntry>): String? {
        val appEntries = entries.filter { it.packageName == packageName }
        if (appEntries.isEmpty() || appEntries.any { !isComplete(it) } ||
            appEntries.map { it.groupKey to it.ruleKey }.distinct().size != appEntries.size
        ) return null
        val fingerprints = appEntries.map { entry ->
            val encoded = buildString {
                fun field(value: String) { append(value.length).append(':').append(value) }
                fun fields(values: List<String>) {
                    field(values.size.toString())
                    values.forEach(::field)
                }
                field(entry.packageName)
                field(entry.versionCode.toString())
                fields(entry.currentSignerSha256.sorted())
                field(entry.activityName)
                field(entry.groupKey.toString())
                field(entry.ruleKey.toString())
                field(entry.ruleSha256)
                field(entry.groupSha256)
                field(entry.targetSelector)
                fields(entry.requiredContextSelectors)
                fields(entry.forbiddenContextSelectors)
                field(entry.purpose.name)
            }
            sha256(encoded)
        }.sorted()
        return sha256("gkd-private-review-consent-v1\n" + fingerprints.joinToString("\n"))
    }
}

/**
 * Own the compiled list before deriving revisions. Each final ReviewedRuleEntry already
 * owns defensive, unmodifiable copies of every collection; strings/scalars are immutable.
 * Do not cache imported candidates, preference reads, or live Android identity here.
 */
internal class ReviewedRuleCatalogSnapshot(entries: List<ReviewedRuleEntry>) {
    private val entries: List<ReviewedRuleEntry> = Collections.unmodifiableList(ArrayList(entries))
    val supportedPackageNames: Set<String> = Collections.unmodifiableSet(
        this.entries.filter(ReviewedRulePolicy::isComplete).map { it.packageName }.toSet(),
    )
    // Event ingress only needs exact compiled scope, never mutable imported payloads.
    private val supportedActivities: Set<Pair<String, String>> = Collections.unmodifiableSet(
        this.entries.filter(ReviewedRulePolicy::isComplete).map { it.packageName to it.activityName }.toSet(),
    )
    private val consentRevisions: Map<String, String?> = Collections.unmodifiableMap(
        this.entries.map { it.packageName }.distinct().associateWith {
            // Keep invalid and duplicate entries: either must invalidate the whole app revision.
            ReviewedRulePolicy.consentRevision(it, this.entries)
        },
    )
    val supportedAppCount: Int get() = supportedPackageNames.size
    val reviewedRuleCount: Int get() = entries.count(ReviewedRulePolicy::isComplete)
    val isEmpty: Boolean get() = entries.isEmpty()
    fun supportsPackage(packageName: String): Boolean = packageName in supportedPackageNames
    fun supportsActivity(packageName: String, activityName: String): Boolean =
        consentRevisions[packageName] != null && (packageName to activityName) in supportedActivities
    fun consentRevision(packageName: String): String? = consentRevisions[packageName]
    fun admit(candidate: ReviewedRuleCandidate): ReviewedRuleEntry? =
        ReviewedRulePolicy.admit(candidate, entries)
}

/**
 * The source-set provider keeps production EMPTY. Only the explicitly selected
 * ownedFixtureDebug test variant contains the one owned-demo fixture. Imported
 * subscriptions cannot enroll entries. Neither variant claims real-app support.
 */
internal object ReviewedRuleCatalog {
    private val snapshot = ReviewedRuleCatalogSnapshot(ReviewedRuleCatalogSource.entries)
    val supportedPackageNames: Set<String> get() = snapshot.supportedPackageNames
    val supportedAppCount: Int get() = snapshot.supportedAppCount
    val reviewedRuleCount: Int get() = snapshot.reviewedRuleCount
    val isEmpty: Boolean get() = snapshot.isEmpty
    fun supportsPackage(packageName: String): Boolean = snapshot.supportsPackage(packageName)
    fun supportsActivity(packageName: String, activityName: String): Boolean = snapshot.supportsActivity(packageName, activityName)
    fun consentRevision(packageName: String): String? = snapshot.consentRevision(packageName)
    fun admit(candidate: ReviewedRuleCandidate): ReviewedRuleEntry? = snapshot.admit(candidate)
}
