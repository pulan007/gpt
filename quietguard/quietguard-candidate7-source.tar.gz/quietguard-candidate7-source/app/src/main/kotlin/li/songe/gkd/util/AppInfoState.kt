package li.songe.gkd.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.UserHandle
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import li.songe.gkd.App
import li.songe.gkd.PrivateCapabilities
import li.songe.gkd.app
import li.songe.gkd.appScope
import li.songe.gkd.data.AppInfo
import li.songe.gkd.data.otherUserMapFlow
import li.songe.gkd.data.toAppInfo
import li.songe.gkd.data.toAppInfoAndIcon
import li.songe.gkd.permission.canQueryPkgState
import li.songe.gkd.shizuku.currentUserId
import li.songe.gkd.shizuku.shizukuContextFlow

val userAppInfoMapFlow = MutableStateFlow(emptyMap<String, AppInfo>())
val userAppIconMapFlow = MutableStateFlow(emptyMap<String, Drawable>())
val otherUserAppInfoMapFlow = MutableStateFlow(emptyMap<String, AppInfo>())
val otherUserAppIconMapFlow = MutableStateFlow(emptyMap<String, Drawable>())

val appInfoMapFlow by lazy {
    combine(otherUserAppInfoMapFlow, userAppInfoMapFlow) { a, b -> a + b }
        .stateIn(appScope, SharingStarted.Eagerly, emptyMap())
}

val appIconMapFlow by lazy {
    combine(otherUserAppIconMapFlow, userAppIconMapFlow) { a, b -> a + b }
        .stateIn(appScope, SharingStarted.Eagerly, emptyMap())
}

val systemAppInfoCacheFlow by lazy {
    appInfoMapFlow.mapState(appScope) { c ->
        c.filter { a -> a.value.isSystem }
    }
}

val systemAppsFlow by lazy { systemAppInfoCacheFlow.mapState(appScope) { c -> c.keys } }

val visibleAppInfosFlow by lazy {
    appInfoMapFlow.mapState(appScope) { c ->
        c.values.filterNot { it.hidden }.sortedWith { a, b ->
            collator.compare(a.name, b.name)
        }
    }
}

private val willUpdateAppIds = MutableStateFlow(emptySet<String>())

private fun dispatchAppUpdate(appId: String) = willUpdateAppIds.update { it + appId }

private fun registerPackageListener() {
    val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val appId = intent?.data?.schemeSpecificPart ?: return
            dispatchAppUpdate(appId)
        }
    }
    ContextCompat.registerReceiver(
        app,
        packageReceiver,
        IntentFilter().apply {
            arrayOf(
                Intent.ACTION_PACKAGE_ADDED,
                Intent.ACTION_PACKAGE_REPLACED,
                Intent.ACTION_PACKAGE_REMOVED,
            ).forEach { addAction(it) }
            addDataScheme("package")
        },
        ContextCompat.RECEIVER_EXPORTED,
    )

    // 某些设备 ACTION_PACKAGE_ADDED 接收不到，使用 LauncherApps.Callback 作为补充
    val packageCallback = object : LauncherApps.Callback() {
        override fun onPackageAdded(packageName: String, user: UserHandle) {
            dispatchAppUpdate(packageName)
        }

        override fun onPackageChanged(packageName: String, user: UserHandle) {
            dispatchAppUpdate(packageName)
        }

        override fun onPackageRemoved(packageName: String, user: UserHandle) {
            dispatchAppUpdate(packageName)
        }

        override fun onPackagesAvailable(
            p0: Array<String>,
            p1: UserHandle,
            p2: Boolean
        ) = Unit

        override fun onPackagesUnavailable(
            p0: Array<String>,
            p1: UserHandle,
            p2: Boolean
        ) = Unit
    }
    app.launcherApps.registerCallback(packageCallback)
}

const val PKG_FLAGS = PackageManager.MATCH_UNINSTALLED_PACKAGES

val updateAppMutex = MutexState()

private fun updateOtherUserAppInfo(userAppInfoMap: Map<String, AppInfo>? = null) {
    if (!PrivateCapabilities.SHIZUKU) {
        otherUserMapFlow.value = emptyMap()
        otherUserAppIconMapFlow.value = emptyMap()
        otherUserAppInfoMapFlow.value = emptyMap()
        return
    }
    val pkgManager = shizukuContextFlow.value.packageManager
    val userManager = shizukuContextFlow.value.userManager
    val actualUserAppInfoMap = userAppInfoMap ?: userAppInfoMapFlow.value
    if (pkgManager == null || userManager == null || actualUserAppInfoMap.isEmpty()) {
        otherUserMapFlow.value = emptyMap()
        otherUserAppIconMapFlow.value = emptyMap()
        otherUserAppInfoMapFlow.value = emptyMap()
        return
    }
    val otherUsers = userManager.getUsers().filter { it.id != currentUserId }.sortedBy { it.id }
    val userPackageInfoMap = otherUsers.associate { user ->
        user.id to pkgManager.getInstalledPackages(
            PKG_FLAGS,
            user.id
        ).filterNot { actualUserAppInfoMap.contains(it.packageName) }
    }
    val newIconMap = HashMap<String, Drawable>()
    val newAppMap = HashMap<String, AppInfo>()
    userPackageInfoMap.forEach { (userId, pkgInfoList) ->
        pkgInfoList.forEach { pkgInfo ->
            if (!newAppMap.contains(pkgInfo.packageName)) {
                val (appInfo, appIcon) = pkgInfo.toAppInfoAndIcon(userId)
                newAppMap[pkgInfo.packageName] = appInfo
                if (appIcon != null) {
                    newIconMap[pkgInfo.packageName] = appIcon
                }
            }
        }
    }
    otherUserMapFlow.value = otherUsers.associateBy { it.id }
    otherUserAppInfoMapFlow.value = newAppMap
    otherUserAppIconMapFlow.value = newIconMap
}

private fun updatePartAppInfo(
    appIds: Set<String>,
) = updateAppMutex.launchTry(appScope, Dispatchers.IO) {
    willUpdateAppIds.update { it - appIds }
    val newAppMap = HashMap(userAppInfoMapFlow.value)
    val newIconMap = HashMap(userAppIconMapFlow.value)
    val oldMapSize = newAppMap.size
    appIds.forEach { appId ->
        val info = app.getPkgInfo(appId)
        if (info != null) {
            newAppMap[appId] = info.toAppInfo()
        } else {
            newAppMap.remove(appId)
        }
        val icon = info?.pkgIcon
        if (icon != null) {
            newIconMap[appId] = icon
        } else {
            newIconMap.remove(appId)
        }
    }
    updateOtherUserAppInfo(newAppMap)
    userAppInfoMapFlow.value = newAppMap
    userAppIconMapFlow.value = newIconMap
    LogUtils.d(
        "updatePartAppInfo",
        "change=${appIds.map { (if (newAppMap.contains(it)) "+" else "-") + it }}",
        "size=${oldMapSize}->${newAppMap.size}"
    )
}

val appListAuthAbnormalFlow = MutableStateFlow(false)

fun updateAllAppInfo(): Unit = updateAppMutex.launchTry(appScope, Dispatchers.IO) {
    val newAppMap = HashMap<String, AppInfo>()
    val newIconMap = HashMap<String, Drawable>()
    // see #1169 DeadObjectException BadParcelableException
    val pkgList = app.packageManager.getInstalledPackages(PKG_FLAGS)
    pkgList.forEach { pkgInfo ->
        val (appInfo, appIcon) = pkgInfo.toAppInfoAndIcon()
        newAppMap[pkgInfo.packageName] = appInfo
        if (appIcon != null) {
            newIconMap[pkgInfo.packageName] = appIcon
        }
    }
    // Limited Android visibility is expected here, not a denied inventory grant.
    val mayAuthDenied = canQueryPkgState.capabilityEnabled &&
            newAppMap.count { !it.value.isSystem } <= 4
    canQueryPkgState.updateAndGet()
    appListAuthAbnormalFlow.value = canQueryPkgState.value && mayAuthDenied
    if (!canQueryPkgState.value || mayAuthDenied) {
        LogUtils.d(
            "updateAllAppInfo",
            "mayAuthDenied=$mayAuthDenied, newAppMap.size=${newAppMap.size}"
        )
        val pkgList2 = if (PrivateCapabilities.SHIZUKU) {
            shizukuContextFlow.value.packageManager?.getInstalledPackages(PKG_FLAGS)
        } else {
            null
        }
        if (!pkgList2.isNullOrEmpty()) {
            pkgList2.forEach { pkgInfo ->
                val (appInfo, appIcon) = pkgInfo.toAppInfoAndIcon()
                newAppMap[pkgInfo.packageName] = appInfo
                if (appIcon != null) {
                    newIconMap[pkgInfo.packageName] = appIcon
                }
            }
        } else {
            val visiblePkgList =
                arrayOf(Intent.ACTION_MAIN, Intent.ACTION_VIEW).asSequence().flatMap { action ->
                    try {
                        // DeadObjectException BadParcelableException
                        app.packageManager.queryIntentActivities(
                            Intent(action),
                            PackageManager.MATCH_DISABLED_COMPONENTS
                        )
                    } catch (_: Throwable) {
                        emptyList()
                    }
                }
                    .map { it.activityInfo.packageName }.toSet()
                    .filter { !newAppMap.contains(it) }.mapNotNull { app.getPkgInfo(it) }.toList()
            visiblePkgList.forEach { pkgInfo ->
                val (appInfo, appIcon) = pkgInfo.toAppInfoAndIcon(hidden = false)
                newAppMap[pkgInfo.packageName] = appInfo
                if (appIcon != null) {
                    newIconMap[pkgInfo.packageName] = appIcon
                }
            }
        }
    }
    updateOtherUserAppInfo(newAppMap)
    userAppInfoMapFlow.value = newAppMap
    userAppIconMapFlow.value = newIconMap
    if (!app.justStarted) {
        toast("应用列表更新成功")
    }
    if (canQueryPkgState.value && mayAuthDenied && app.justStarted) {
        // 概率出现：即使有「读取应用列表权限」在刚启动时也只能获取到少量应用，延迟几秒再试一次
        appScope.launch {
            delay(App.START_WAIT_TIME)
            updateAllAppInfo()
        }
    }
}

fun initAppState() {
    registerPackageListener()
    updateAllAppInfo()
    if (PrivateCapabilities.SHIZUKU) {
        appScope.launchTry {
            shizukuContextFlow.drop(1).collect {
                updateAppMutex.launchTry(appScope, Dispatchers.IO) {
                    updateOtherUserAppInfo()
                }
            }
        }
    }
    appScope.launchTry {
        willUpdateAppIds.debounce(3000)
            .filter { it.isNotEmpty() }
            .collect { updatePartAppInfo(it) }
    }
}