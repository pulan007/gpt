/* Private-fork Activity admission, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

/**
 * One metadata-only Activity transition. CONTENT may retain it, never renew it.
 * The engine serializes ingress and promotion on this monitor; no IPC runs here.
 * Admission is provisional: the unchanged execution gate must prove the live window.
 */
internal class PrivateActivityAdmission(private val now: () -> Long) {
    class Candidate internal constructor(
        val packageName: String,
        val activityName: String,
        val windowId: Int,
        val observedAt: Long,
        val epoch: Long,
        val generation: Long,
    ) {
        internal var attempts = 0
        internal var firstAttemptAt = 0L
        internal var promoted = false
        internal var queryClaimed = false
    }

    private var current: Candidate? = null

    @Synchronized fun clear(reason: ContentAdmissionReason = ContentAdmissionReason.CLEARED) {
        val previous = current
        current = null
        if (previous != null) contentAdmissionTrace(reason, previous.epoch, previous.observedAt)
    }

    @Synchronized fun observe(
        packageName: String,
        activityName: String,
        windowId: Int,
        stateChanged: Boolean,
        eligible: Boolean,
        observedAt: Long,
        epoch: Long,
        generation: Long,
    ): Candidate? {
        if (stateChanged) {
            val next = if (eligible && windowId >= 0 && now() - observedAt in 0 until MAX_AGE_MS)
                Candidate(packageName, activityName, windowId, observedAt, epoch, generation)
            else null
            clear(if (next == null) ContentAdmissionReason.STATE_REJECTED else ContentAdmissionReason.STATE_REPLACED)
            current = next
            if (next != null) contentAdmissionTrace(ContentAdmissionReason.CREATED, next.epoch, next.observedAt)
        } else {
            val candidate = current
            when {
                !eligible -> clear(ContentAdmissionReason.CONTENT_INELIGIBLE)
                candidate == null -> Unit
                candidate.packageName != packageName -> clear(ContentAdmissionReason.CONTENT_PACKAGE_CHANGED)
                candidate.windowId != windowId -> clear(ContentAdmissionReason.CONTENT_WINDOW_CHANGED)
                else -> {
                    val status = currentStatus(candidate, epoch, generation)
                    if (status != ContentAdmissionReason.CURRENT) clear(status)
                }
            }
        }
        return current
    }

    @Synchronized fun currentStatus(
        candidate: Candidate, epoch: Long, generation: Long,
        failure: GuardFailureDiagnostic? = null,
    ): ContentAdmissionReason {
        val status = when {
            current !== candidate -> ContentAdmissionReason.CANDIDATE_CHANGED
            candidate.epoch != epoch -> ContentAdmissionReason.EPOCH_CHANGED
            candidate.generation != generation -> ContentAdmissionReason.GENERATION_CHANGED
            !guardAge(now() - candidate.observedAt, MAX_AGE_MS,
                100L + ContentAdmissionReason.EXPIRED.code, failure) -> ContentAdmissionReason.EXPIRED
            else -> ContentAdmissionReason.CURRENT
        }
        failure?.rejectAdmission(status)
        return status
    }

    @Synchronized fun isCurrent(candidate: Candidate, epoch: Long, generation: Long): Boolean =
        currentStatus(candidate, epoch, generation) == ContentAdmissionReason.CURRENT

    /** One wait, inside the existing event coroutine, can precede the second attempt. */
    @Synchronized fun delayBeforeAttempt(candidate: Candidate): Long? {
        if (current !== candidate || candidate.promoted || candidate.attempts >= 2 ||
            now() - candidate.observedAt !in 0 until MAX_AGE_MS) return null
        val delay = if (candidate.attempts == 0) 0L
            else (candidate.firstAttemptAt + MINIMUM_GAP_MS - now()).coerceAtLeast(0L)
        return delay.takeIf { now() + it - candidate.observedAt in 0 until MAX_AGE_MS }
    }

    /** Denied/busy attempts are spent too. The separate process budget still gates IPC. */
    @Synchronized fun reserveAttempt(candidate: Candidate): Boolean {
        if (delayBeforeAttempt(candidate) != 0L) return false
        if (candidate.attempts == 0) candidate.firstAttemptAt = now()
        candidate.attempts++
        return true
    }

    /** Anchor spacing at/after actual budget admission, not the earlier reservation. */
    @Synchronized fun identityAdmitted(candidate: Candidate) {
        if (current === candidate && candidate.attempts == 1 && !candidate.promoted)
            candidate.firstAttemptAt = now()
    }

    @Synchronized fun promote(candidate: Candidate, packageName: String, windowId: Int): Boolean {
        if (current !== candidate || candidate.promoted || candidate.attempts == 0 ||
            now() - candidate.observedAt !in 0 until MAX_AGE_MS) return false
        if (packageName != candidate.packageName || windowId != candidate.windowId) {
            // A witnessed different root cannot be retried after an unseen return.
            clear(ContentAdmissionReason.ROOT_IDENTITY_CHANGED)
            return false
        }
        candidate.promoted = true
        contentAdmissionTrace(ContentAdmissionReason.PROMOTED, candidate.epoch, candidate.observedAt)
        return true
    }

    @Synchronized fun queryClaimStatus(candidate: Candidate): ContentAdmissionReason {
        val status = when {
            current !== candidate -> ContentAdmissionReason.CANDIDATE_CHANGED
            !candidate.promoted -> ContentAdmissionReason.NOT_PROMOTED
            candidate.queryClaimed -> ContentAdmissionReason.ALREADY_CLAIMED
            now() - candidate.observedAt !in 0 until MAX_AGE_MS -> ContentAdmissionReason.EXPIRED
            else -> ContentAdmissionReason.CURRENT
        }
        if (status == ContentAdmissionReason.CURRENT) candidate.queryClaimed = true
        return status
    }

    @Synchronized fun claimQuery(candidate: Candidate): Boolean =
        queryClaimStatus(candidate) == ContentAdmissionReason.CURRENT

    @Synchronized fun admitted(): Candidate? = current?.takeIf { it.promoted }

    companion object {
        const val MAX_AGE_MS = 1_000L
        private const val MINIMUM_GAP_MS = 500L
    }
}
