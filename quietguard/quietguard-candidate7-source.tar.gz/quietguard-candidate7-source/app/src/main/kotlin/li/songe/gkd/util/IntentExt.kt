// Private offline-profile modifications, 2026-10-07; GKD GPL-3.0, see LICENSE.
package li.songe.gkd.util

import android.app.Service
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import li.songe.gkd.META
import li.songe.gkd.PrivateCapabilities
import li.songe.gkd.service.HttpService
import li.songe.gkd.service.OverlayWindowService
import li.songe.gkd.service.TrackService
import li.songe.gkd.MainActivity
import li.songe.gkd.app
import li.songe.gkd.isActivityVisible
import li.songe.gkd.permission.canWriteExternalStorage
import li.songe.gkd.permission.foregroundServiceSpecialUseState
import li.songe.gkd.permission.notificationState
import li.songe.gkd.permission.requiredPermission
import java.io.File
import kotlin.reflect.KClass

fun MainActivity.shareFile(file: File, title: String) {
    val uri = FileProvider.getUriForFile(
        app, "${app.packageName}.provider", file
    )
    val intent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_STREAM, uri)
        type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    tryStartActivity(
        Intent.createChooser(
            intent, title
        )
    )
}

suspend fun MainActivity.saveFileToDownloads(file: File) {
    if (AndroidTarget.Q) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        withContext(Dispatchers.IO) {
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("创建URI失败")
            contentResolver.openOutputStream(uri)?.use { outputStream ->
                outputStream.write(file.readBytes())
                outputStream.flush()
            }
        }
    } else {
        requiredPermission(this, canWriteExternalStorage)
        val targetFile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            file.name
        )
        targetFile.writeBytes(file.readBytes())
    }
    toast("已保存 ${file.name} 到下载")
}

fun Context.tryStartActivity(intent: Intent) {
    try {
        startActivity(intent)
    } catch (e: Exception) {
        if (PrivateCapabilities.SENSITIVE_LOGGING) e.printStackTrace()
        LogUtils.d("tryStartActivity", e)
        toast("跳转失败\n" + (e.message ?: e.stackTraceToString()))
    }
}

fun openWeChatScaner() {
    val intent = app.packageManager.getLaunchIntentForPackage("com.tencent.mm")?.apply {
        putExtra("LauncherUI.From.Scaner.Shortcut", true)
    }
    if (intent == null) {
        toast("请检查微信是否安装或禁用")
        return
    }
    app.tryStartActivity(intent)
}

fun openA11ySettings() {
    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
    app.tryStartActivity(intent)
}

fun openAppDetailsSettings() {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = "package:${app.packageName}".toUri()
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    app.tryStartActivity(intent)
}

fun openUri(uri: String) {
    val u = try {
        uri.toUri()
    } catch (e: Exception) {
        if (PrivateCapabilities.SENSITIVE_LOGGING) e.printStackTrace()
        toast("非法链接")
        return
    }
    openUri(u)
}

fun openUri(uri: Uri) {
    val intent = Intent(Intent.ACTION_VIEW, uri)
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    app.tryStartActivity(intent)
}

fun openApp(appId: String) {
    val intent = app.packageManager.getLaunchIntentForPackage(appId)
    if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.tryStartActivity(intent)
    } else {
        toast("请检查此应用是否安装或禁用")
    }
}

fun <T : Service> stopServiceByClass(clazz: KClass<T>) {
    val intent = Intent(app, clazz.java)
    app.stopService(intent)
}

fun <T : Service> startForegroundServiceByClass(clazz: KClass<T>) {
    if ((!PrivateCapabilities.OVERLAY && (OverlayWindowService::class.java.isAssignableFrom(clazz.java) || clazz == TrackService::class)) ||
        (!PrivateCapabilities.HTTP_DEBUG && clazz == HttpService::class)) {
        toast("私有离线版已禁用：诊断服务")
        return
    }
    if (!notificationState.checkOrToast()) return
    if (!foregroundServiceSpecialUseState.checkOrToast()) return
    val intent = Intent(app, clazz.java)
    try {
        app.startForegroundService(intent)
    } catch (e: Throwable) {
        LogUtils.d(e)
        val prefix = if (isActivityVisible) "" else "${META.appName}: "
        toast("${prefix}启动服务失败: ${e.message}", forced = true)
    }
}

val Intent.extraCptName: ComponentName?
    get() = if (AndroidTarget.TIRAMISU) {
        getParcelableExtra(Intent.EXTRA_COMPONENT_NAME, ComponentName::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(Intent.EXTRA_COMPONENT_NAME) as? ComponentName?
    }
