package li.songe.gkd.ui.component

// Private derivative notice, 2026-10-07; see LICENSE and PRIVATE_FORK.md.
import androidx.activity.compose.LocalActivity
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import li.songe.gkd.MainActivity
import li.songe.gkd.PrivateForkInfo
import li.songe.gkd.ui.share.LocalMainViewModel

/** Informational acknowledgement, not acceptance of the upstream service's agreements. */
@Composable
fun TermsAcceptDialog() {
    val mainVm = LocalMainViewModel.current
    val context = LocalActivity.current as MainActivity
    var step by rememberSaveable { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = {},
        title = { Text(if (step == 0) "私人修改版说明" else "无障碍与使用范围") },
        text = {
            Text(
                modifier = Modifier.fillMaxWidth(),
                text = if (step == 0) {
                    PrivateForkInfo.NOTICE + "\n\n本安装包附带对应源码与修改说明。目前仍在验证，尚未完成真实应用适配。"
                } else {
                    PrivateForkInfo.PRIVACY + "\n\n" + PrivateForkInfo.SCOPE +
                        "\n\n主开关默认关闭。系统无障碍权限需要你手动开启；继续阅读不会授予权限。"
                },
            )
        },
        confirmButton = {
            TextButton(onClick = {
                if (step == 0) step = 1 else mainVm.termsAcceptedFlow.value = true
            }) { Text(if (step == 0) "继续阅读" else "我已了解") }
        },
        dismissButton = { TextButton(onClick = { context.finish() }) { Text("退出") } },
    )
}
