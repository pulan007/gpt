/*
 * Private offline-profile modifications, 2026-10-07.
 * Derived from GKD (https://github.com/gkd-kit/gkd), upstream 5a00f844.
 * Copyright belongs to the respective GKD contributors. GPL-3.0; see LICENSE.
 */
package li.songe.gkd

/** Build-time boundaries: imported preferences cannot enable these capabilities. */
object PrivateCapabilities {
    const val SNAPSHOTS = false
    const val SCREENSHOTS = false
    const val HTTP_DEBUG = false
    const val EXTERNAL_COMMANDS = false
    const val EXTERNAL_IMPORTS = false
    const val SHIZUKU = false
    const val SECURE_SETTINGS_WRITES = false
    const val POWER_EXEMPTION = false
    const val OVERLAY = false
    const val APP_INVENTORY = false
    const val AUTOMATIC_ACTION_FEEDBACK = false
    const val APP_UPDATES = false
    const val SUBSCRIPTION_UPDATES = false
    const val SENSITIVE_LOGGING = false
    const val ACTIVITY_HISTORY = false
    const val PRIVILEGED_AUTOMATION = false

    fun requireEnabled(enabled: Boolean, feature: String) {
        if (!enabled) throw PrivateCapabilityDisabledException(feature)
    }
}

class PrivateCapabilityDisabledException(feature: String) :
    IllegalStateException("私有离线版已禁用：$feature")
