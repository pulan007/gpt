package li.songe.gkd.util

const val FILE_SHORT_URL = "https://f.gkd.li/"
const val IMPORT_SHORT_URL = "https://i.gkd.li/i/"

const val SERVER_SCRIPT_URL =
    "https://registry.npmmirror.com/@gkd-kit/config/latest/files/dist/server.js"

const val REPOSITORY_URL = "https://github.com/gkd-kit/gkd"
const val ISSUES_URL = "${REPOSITORY_URL}/issues"

const val HOME_PAGE_URL = "https://gkd.li"

const val LOCAL_SUBS_ID = -2L
const val LOCAL_HTTP_SUBS_ID = -1L
val LOCAL_SUBS_IDS = arrayOf(LOCAL_SUBS_ID, LOCAL_HTTP_SUBS_ID)

const val EMPTY_RULE_TIP = "暂无规则"

object ShortUrlSet {
    const val URL1 = "https://gkd.li?r=1"
    const val URL2 = "https://gkd.li?r=2"
    const val URL3 = "https://gkd.li?r=3"
    const val URL4 = "https://gkd.li?r=4"
    const val URL5 = "https://gkd.li?r=5"
    const val URL6 = "https://gkd.li?r=6"
    const val URL10 = "https://gkd.li?r=10"
    const val URL11 = "https://gkd.li?r=11"
    const val URL12 = "https://gkd.li?r=12"
    const val URL13 = "https://gkd.li?r=13"
    const val URL14 = "https://gkd.li?r=14"
    const val URL15 = "https://gkd.li?r=15"
}

const val shizukuAppId = "moe.shizuku.privileged.api"

const val PLAY_STORE_URL = "https://play.google.com/store/apps/details?id=li.songe.gkd"

const val systemUiAppId = "com.android.systemui"
