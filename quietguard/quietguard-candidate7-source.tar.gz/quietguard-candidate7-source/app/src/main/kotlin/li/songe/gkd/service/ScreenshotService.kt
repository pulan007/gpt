// Private offline-profile modifications, 2026-10-07; GKD GPL-3.0, see LICENSE.
package li.songe.gkd.service

import android.app.Service
import android.content.Intent
import coil3.Bitmap
import li.songe.gkd.PrivateCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import li.songe.gkd.app
import li.songe.gkd.notif.StopServiceReceiver
import li.songe.gkd.notif.screenshotNotif
import li.songe.gkd.util.DefaultSimpleLifeImpl
import li.songe.gkd.util.LogUtils
import li.songe.gkd.util.OnSimpleLife
import li.songe.gkd.util.ScreenshotUtil
import li.songe.gkd.util.componentName
import li.songe.gkd.util.stopServiceByClass
import li.songe.gkd.util.toast

class ScreenshotService : Service(), OnSimpleLife by DefaultSimpleLifeImpl() {
    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        if (!PrivateCapabilities.SCREENSHOTS) {
            stopSelf()
            return
        }
        onCreated()
    }
    override fun onDestroy() {
        if (PrivateCapabilities.SCREENSHOTS) onDestroyed()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!PrivateCapabilities.SCREENSHOTS) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            return super.onStartCommand(intent, flags, startId)
        } finally {
            intent?.let {
                screenshotUtil?.destroy()
                screenshotUtil = ScreenshotUtil(this, intent)
                LogUtils.d("screenshot restart")
            }
        }
    }

    private var screenshotUtil: ScreenshotUtil? = null

    init {
        useLogLifecycle()
        useAliveFlow(isRunning)
        useAliveToast("截屏服务")
        StopServiceReceiver.autoRegister()
        onCreated { screenshotNotif.notifyService() }
        onCreated { instance = this }
        onDestroyed {
            screenshotUtil?.destroy()
            instance = null
        }
    }

    companion object {
        private var instance: ScreenshotService? = null
        val isRunning = MutableStateFlow(false)
        suspend fun screenshot(): Bitmap? {
            PrivateCapabilities.requireEnabled(PrivateCapabilities.SCREENSHOTS, "屏幕截图")
            if (!isRunning.value) return null
            return withTimeoutOrNull(5_000) {
                instance?.screenshotUtil?.execute()
            }
        }

        fun start(intent: Intent) {
            if (!PrivateCapabilities.SCREENSHOTS) {
                toast("私有离线版已禁用：屏幕截图")
                return
            }
            intent.component = ScreenshotService::class.componentName
            app.startForegroundService(intent)
        }

        fun stop() = stopServiceByClass(ScreenshotService::class)
    }
}
