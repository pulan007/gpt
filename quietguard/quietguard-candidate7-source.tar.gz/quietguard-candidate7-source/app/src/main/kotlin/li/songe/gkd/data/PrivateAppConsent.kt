package li.songe.gkd.data

// Private derivative, 2026-10-07. GPL-3.0; see LICENSE.
import android.content.Context
import li.songe.gkd.PrivateAutomationControl
import li.songe.gkd.app

/** Dedicated private preferences are not part of GKD import/export or subscription data. */
internal object PrivateAppConsent {
    private val preferences by lazy {
        app.getSharedPreferences("private_reviewed_app_opt_in_v1", Context.MODE_PRIVATE)
    }
    private val policy by lazy {
        PrivateAppOptInPolicy(
            revisionFor = ReviewedRuleCatalog::consentRevision,
            read = { preferences.getString(it, null) },
            write = { key, value -> preferences.edit().apply {
                if (value == null) remove(key) else putString(key, value)
            }.apply() },
            invalidate = PrivateAutomationControl::invalidate,
        )
    }
    fun isEnabled(packageName: String): Boolean = policy.isEnabled(packageName)
    fun isEnabled(entry: ReviewedRuleEntry): Boolean = isEnabled(entry.packageName)
    fun setEnabled(packageName: String, enabled: Boolean): Boolean = policy.setEnabled(packageName, enabled)
}
