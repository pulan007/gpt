/* Private-fork scheduling additions, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.asContextElement
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Admission happens before dispatch. One active ticket and one replaceable mailbox. */
internal class LatestWork<T>(private val merge: (T, T) -> T = { _, newest -> newest }) {
    class Ticket<T> internal constructor(val value: T)
    private var active: Ticket<T>? = null
    private var pending: T? = null

    @Synchronized
    fun offer(value: T, keepPending: Boolean = true): Ticket<T>? {
        if (active != null) {
            if (keepPending) pending = pending?.let { merge(it, value) } ?: value
            return null
        }
        return Ticket(value).also { active = it }
    }

    /** Called by job completion, including cancellation before the job body starts. */
    @Synchronized
    fun complete(ticket: Ticket<T>): Ticket<T>? {
        if (active !== ticket) return null
        val next = pending
        pending = null
        active = next?.let { Ticket(it) }
        return active
    }
}

/** Preserve GKD's sameAs grouping as a bounded metadata summary, without framework events. */
internal data class EventBatch<T>(val latest: T, val previous: T? = null, val mixed: Boolean = false) {
    fun merge(next: EventBatch<T>, same: (T, T) -> Boolean): EventBatch<T> = EventBatch(
        latest = next.latest,
        previous = next.previous ?: latest,
        mixed = mixed || next.mixed || !same(latest, next.latest),
    )

    fun sources(): List<T>? = if (mixed) null else listOfNotNull(previous, latest)
}

/** A 300 ms follow-up chain cannot renew its own absolute monotonic deadline. */
internal class FollowUpBudget(
    private val now: () -> Long,
    private val durationMs: Long = 3_000,
    private val maxAttempts: Int = 10,
) {
    private var startedAt: Long? = null
    private var attempts = 0
    private var scheduled: Any? = null

    @Synchronized
    fun reset() {
        startedAt = now()
        attempts = if (scheduled == null) 0 else 1
    }

    @Synchronized
    fun isOpen(): Boolean {
        val start = startedAt ?: return false
        return now() - start in 0 until durationMs
    }

    @Synchronized
    fun reserve(delayMs: Long): Any? {
        val start = startedAt ?: return null
        val elapsed = now() - start
        if (scheduled != null || elapsed < 0 || elapsed + delayMs >= durationMs || attempts >= maxAttempts) return null
        attempts++
        return Any().also { scheduled = it }
    }

    @Synchronized
    fun release(token: Any): Boolean {
        if (scheduled !== token) return false
        scheduled = null
        return isOpen()
    }
}

/**
 * Process-wide in the engine. Neither a cancelled waiter nor its service owns this lease.
 * Only the thread actually executing the read releases it, after the call returns.
 * No queue is accumulated while an uninterruptible Binder call is stuck.
 */
internal class PhysicalReadOwner(private val now: () -> Long, private val executor: Executor) {
    private val occupied = AtomicReference<Any?>(null)
    private val currentOwner = ThreadLocal<Any?>()

    /** Covers the complete query, including source/refresh/selector/action IPC. */
    suspend fun <T> withOwnership(block: suspend () -> T): T? {
        val token = Any()
        if (!occupied.compareAndSet(null, token)) return null
        try {
            // Restored across suspension; unrelated work on the same thread cannot borrow it.
            return withContext(currentOwner.asContextElement(token)) { block() }
        } finally {
            // Cancellation cannot execute this until a blocked synchronous call actually returns.
            occupied.compareAndSet(token, null)
        }
    }

    fun <T> read(
        maxAgeMs: Long,
        isCurrent: () -> Boolean,
        discard: (T) -> Unit = {},
        block: () -> T?,
    ): T? {
        val inherited = currentOwner.get()?.takeIf { occupied.get() === it }
        val token = inherited ?: Any()
        if (inherited == null && !occupied.compareAndSet(null, token)) return null
        val startedAt = now()
        try {
            if (!isCurrent()) return null
            val result = block()
            if (now() - startedAt in 0 until maxAgeMs && isCurrent()) return result
            result?.let(discard)
            return null
        } finally {
            if (inherited == null) occupied.compareAndSet(token, null)
        }
    }

    suspend fun <T> readAsync(
        maxAgeMs: Long,
        isCurrent: () -> Boolean,
        discard: (T) -> Unit = {},
        block: () -> T?,
    ): T? = suspendCancellableCoroutine { waiter ->
        val token = Any()
        if (!occupied.compareAndSet(null, token)) {
            waiter.resume(null)
            return@suspendCancellableCoroutine
        }
        val startedAt = now()
        try {
            executor.execute {
                val result = try {
                    if (waiter.isActive && now() - startedAt in 0 until maxAgeMs && isCurrent()) block() else null
                } catch (_: Exception) {
                    null
                } finally {
                    // In particular, never move this release into invokeOnCancellation.
                    occupied.compareAndSet(token, null)
                }
                if (waiter.isActive && now() - startedAt in 0 until maxAgeMs && isCurrent()) {
                    waiter.resume(result, onCancellation = { _, value, _ -> value?.let(discard) })
                } else {
                    result?.let(discard)
                    if (waiter.isActive) waiter.resume(null)
                }
            }
        } catch (_: Exception) {
            // Submission failed before any physical work started.
            occupied.compareAndSet(token, null)
            if (waiter.isActive) waiter.resume(null)
        }
    }
}
