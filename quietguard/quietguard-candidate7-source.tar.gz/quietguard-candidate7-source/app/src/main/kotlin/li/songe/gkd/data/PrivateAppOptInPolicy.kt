package li.songe.gkd.data

// Private derivative, 2026-10-07. GPL-3.0; see LICENSE.
/** State is bound to the entire reviewed app scope, not an imported enable flag. */
internal class PrivateAppOptInPolicy(
    private val revisionFor: (String) -> String?,
    private val read: (String) -> String?,
    private val write: (String, String?) -> Unit,
    private val invalidate: () -> Unit,
) {
    fun isEnabled(packageName: String): Boolean {
        val expected = revisionFor(packageName) ?: return false
        return read(packageName) == expected
    }

    fun setEnabled(packageName: String, enabled: Boolean): Boolean {
        invalidate()
        if (!enabled) {
            write(packageName, null)
            return true
        }
        val revision = revisionFor(packageName) ?: return false
        write(packageName, revision)
        return true
    }
}
