// Private-fork addition, 2026-10-07. GNU GPL v3; see LICENSE.
package li.songe.gkd.data

/** Pure action-boundary checks, not a complete rule/target safety decision. */
internal object PrivateActionPolicy {
    fun allowsAction(action: String?, hasPosition: Boolean, hasSwipe: Boolean): Boolean =
        action == "clickNode" && !hasPosition && !hasSwipe

    fun allowsNode(
        isVisibleToUser: Boolean,
        isEnabled: Boolean,
        isClickable: Boolean,
        isPassword: Boolean,
        isEditable: Boolean,
    ): Boolean = isVisibleToUser && isEnabled && isClickable && !isPassword && !isEditable
}
