// OWNED DEMO TEST ONLY. Never merge into the shipped production source. GPL-3.0.
package li.songe.gkd.data

import java.util.Collections

/** Exactly one immutable, compiled fixture for the separately verified owned demo APK. */
internal object ReviewedRuleCatalogSource {
    val entries: List<ReviewedRuleEntry> = Collections.unmodifiableList(listOf(
        ReviewedRuleEntry(
            packageName = "dev.quietguard.rebuilt.demo",
            versionCode = 1L,
            currentSignerSha256 = setOf("b7586a75f0d181dc5ce7a849052fe7183c6604da773f413663ac7d6899cd1e19"),
            activityName = "dev.quietguard.rebuilt.demo.VerifiedAdActivity",
            groupKey = 9001,
            ruleKey = 1,
            ruleSha256 = "ec0fe28aba50d4a9553c2f94f8800f4007d8031a0837d2c9e61af5ed4454d445",
            groupSha256 = "076eb38072b7e3a61206ae7ad178ca9a7efa59df5e6c3dc128293ea732b9c0d3",
            targetSelector = "[id='dev.quietguard.rebuilt.demo:id/ad_close'][visibleToUser=true][clickable=true][editable=false]",
            requiredContextSelectors = listOf(
                "[id='dev.quietguard.rebuilt.demo:id/verified_ad_root'][visibleToUser=true]",
                "[id='dev.quietguard.rebuilt.demo:id/verified_ad_marker'][visibleToUser=true]",
            ),
            // Real demo resource used by payment/login/permission/reward and other negative scenes.
            forbiddenContextSelectors = listOf("[id='dev.quietguard.rebuilt.demo:id/scenario_status']"),
            purpose = ReviewedRulePurpose.AD_DISMISS,
        ),
    ))
}
