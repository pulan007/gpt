/* TEST ONLY: bounded in-memory diagnostics, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

import java.util.Collections

/** Compiled only into the explicitly opted-in ownedFixture debug source set. */
object FixtureAdmissionTrace {
    const val ENABLED = true
    private const val CAPACITY = 128
    private val rows = arrayOfNulls<LongArray>(CAPACITY)
    private var next = 0
    private var size = 0
    private var sequence = 0L
    private var eventSequence = 0L

    @Synchronized
    internal fun nextEventId(): Long = ++eventSequence

    @Synchronized
    internal fun record(point: AdmissionTracePoint, eventId: Long,
                        a: Long = 0, b: Long = 0, c: Long = 0, d: Long = 0) {
        rows[next] = longArrayOf(++sequence, eventId, point.code, a, b, c, d)
        next = (next + 1) % CAPACITY
        if (size < CAPACITY) size++
    }

    /** Detached chronological scalar rows: sequence, event ID, point code, a, b, c, d. */
    @JvmStatic
    fun snapshot(): List<LongArray> = synchronized(this) {
        Collections.unmodifiableList(List(size) { offset ->
            rows[(next - size + offset + CAPACITY) % CAPACITY]!!.copyOf()
        })
    }
}
