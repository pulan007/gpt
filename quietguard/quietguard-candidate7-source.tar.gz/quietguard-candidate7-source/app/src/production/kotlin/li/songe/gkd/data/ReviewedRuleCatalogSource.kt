// Isolated fixture checkout only. GPL-3.0; see LICENSE.
package li.songe.gkd.data

/** Gkd and play builds have no compiled rules, including no owned-demo rule. */
internal object ReviewedRuleCatalogSource {
    val entries: List<ReviewedRuleEntry> = emptyList()
}
