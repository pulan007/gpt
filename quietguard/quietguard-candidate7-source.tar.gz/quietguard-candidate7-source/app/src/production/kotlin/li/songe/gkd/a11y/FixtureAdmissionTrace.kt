/* Production source-set diagnostic no-op, 2026-10-07. GPL-3.0; see LICENSE. */
package li.songe.gkd.a11y

/** gkd/play have no diagnostic ring, event counter, screen data, or output sink. */
object FixtureAdmissionTrace {
    const val ENABLED = false
    internal fun nextEventId(): Long = 0L
    @Suppress("UNUSED_PARAMETER")
    internal fun record(point: AdmissionTracePoint, eventId: Long,
                        a: Long = 0, b: Long = 0, c: Long = 0, d: Long = 0) = Unit
    @JvmStatic
    fun snapshot(): List<LongArray> = emptyList()
}
