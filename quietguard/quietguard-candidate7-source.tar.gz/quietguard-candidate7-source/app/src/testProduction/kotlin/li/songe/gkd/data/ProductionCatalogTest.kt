// Production-provider test only. GPL-3.0; see LICENSE.
package li.songe.gkd.data

import org.junit.Assert.*
import org.junit.Test

class ProductionCatalogTest {
    @Test fun productionHasNoSupportedAppsOrRules() {
        assertTrue(ReviewedRuleCatalog.isEmpty)
        assertEquals(0, ReviewedRuleCatalog.supportedAppCount)
        assertEquals(0, ReviewedRuleCatalog.reviewedRuleCount)
        assertTrue(ReviewedRuleCatalog.supportedPackageNames.isEmpty())
        assertFalse(ReviewedRuleCatalog.supportsPackage("example.reviewfixture"))
        assertNull(ReviewedRuleCatalog.consentRevision("example.reviewfixture"))
    }

}
