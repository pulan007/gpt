package android.app;

import android.os.Binder;
import android.os.IBinder;

/**
 * @noinspection unused
 */
public interface ITaskStackListener {
    abstract class Stub extends Binder implements ITaskStackListener {
        public static ITaskStackListener asInterface(IBinder obj) {
            throw new RuntimeException();
        }
    }

    // 应用->桌面不会回调，分屏下切换窗口不会回调，但从最近任务界面移除窗口会回调
    void onTaskStackChanged();

    // https://diff.songe.li/i/ITaskStackListener.onTaskMovedToFront
    // android8 - android9
    void onTaskMovedToFront(int taskId);

    // android10+
    void onTaskMovedToFront(ActivityManager.RunningTaskInfo taskInfo);
}
