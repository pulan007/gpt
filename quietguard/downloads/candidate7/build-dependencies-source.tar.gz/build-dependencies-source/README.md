# QuietGuard candidate7: pinned dependency build sources

Build-only adapter prepared 2026-10-08 because this execution environment could not connect to JitPack (HTTP CONNECT 403). These are local rebuilds of the exact upstream tags required by the unchanged application, **not claimed byte-identical to JitPack binaries**.

`PROVENANCE.json` records upstream repositories, tags/versions and full Git commits. Original library implementations, resources, consumer ProGuard files and copyright headers are retained. Existing upstream LICENSE files are retained; the Callbacks 1.0.0 tag contained no separate LICENSE file. No license text was invented for it.

Build adaptations:

- Replace legacy library/root Gradle DSL with a small AGP 9.2.1 build using SDK 37 / Build Tools 37.0.0 and JDK 21. Original Gradle files are retained as `upstream-*.txt`.
- Move legacy Manifest package attributes to the Android namespace DSL; all other Manifest content is preserved.
- Keep Java/Kotlin JVM target 1.8, minimum SDK values, consumer ProGuard rules, original Maven coordinates/versions and relevant transitive dependencies.
- Use AGP built-in Kotlin and standard release AAR Maven publication. The adapter preserves implementation code; it does not add runtime behavior or permissions. Standard AGP AAR metadata differs from upstream legacy packaging.

From this directory, with Gradle 9.5.1 installed:

    gradle publishToMavenLocal --no-daemon --max-workers=4

Then build the separately provided unchanged candidate7 application source. Its existing `mavenLocal()` repository resolves these artifacts. Use the same local Maven directory in both builds. Do not place keystores, passwords or environment configuration in either source tree.

No caches, APKs, private signing keys, user data or test snapshots are included in this source archive.
